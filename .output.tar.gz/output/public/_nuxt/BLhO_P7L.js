import{_ as t,a as o,t as r,o as a}from"./Dy-FeGlE.js";const n={};function s(e,c){return a(),o("div",null,[r(e.$slots,"default")])}const _=t(n,[["render",s]]);export{_ as default};
