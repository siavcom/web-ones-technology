class I{async Init(r,t){}}export{I};
