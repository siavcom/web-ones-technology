import { d as defineEventHandler, r as readBody } from './index.mjs';
import fs__default from 'fs';
import { exec } from 'child_process';
import '../runtime.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'ipx';

const callServer = defineEventHandler(async (event) => {
  const path = "/sistemas/web-ones/public";
  const body = await readBody(event);
  const call = body.call;
  let data;
  let nameFile = "";
  switch (call) {
    case "leeEmpresas":
      data = fs__default.readFileSync(path + "/Empresas.json");
      body.data = data;
      return data;
    case "readFile":
      nameFile = body.nameFile.trim();
      try {
        const contents = fs__default.readFileSync(path + nameFile);
        body.data = data;
        return data;
      } catch (error) {
        body.data = null;
      }
      return;
    case "imgBase64":
      nameFile = body.nameFile.trim();
      const tipArchivo = nameFile.trim().slice(-3);
      try {
        const contents = fs__default.readFileSync(path + nameFile, { encoding: "base64" });
        data = `data:image/${tipArchivo};base64,` + contents;
        body.data = data;
        return data;
      } catch (error) {
        body.data = null;
      }
      return;
    case "print":
      const Fs = fs__default;
      const datos = body.data;
      let buffDatos = "";
      for (let i = 0; datos.length > i; i++) {
        for (const dato in datos[i]) {
          const caracter = String.fromCharCode(datos[i][dato]);
          buffDatos = buffDatos + caracter;
        }
      }
      const file = "/tmp/ticketBascula.txt";
      Fs.writeFile(file, buffDatos, function(err) {
        if (err) {
          return console.log(err);
        }
        exec(
          "lp -d Epson-TM-Impact-Receipt " + file,
          function(err2) {
            if (err2) {
              return console.log(err2);
            } else {
              exec("rm " + file);
              return;
            }
          }
        );
      });
      break;
  }
  return null;
});

export { callServer as default };
//# sourceMappingURL=callServer.mjs.map
