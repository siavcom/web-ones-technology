//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imprimeformatos
// Class : Imprime
// Description : Componente Imprime
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMPRIMEFORMATOS } from "@/classes/imprimeformatos";

import { IMPRIMEFORMATOS } from "@/classes/imprimeformatos";
//imports

export class Imprime extends IMPRIMEFORMATOS {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "imprimeformatos";

    this.style.backgroundColor = '234,234,234';
    this.prop.Caption = "\<Imprime";
    this.style.height = '60px';
    //LineSlant=760;
    this.prop.Name = "Imprime";
    this.prop.TabIndex = 45;
    this.prop.ToolTipText = "Imprime en un formato predefinido";
    this.style.top = '585px';
    this.style.width = '60px';
    this.style.zIndex = '124';

    //propiedades
  }
  override async click() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_lla1_doc.sta_doc != 'X') {
      this.Form.grabar()
    } // End If 
    ó
    MessageBox('Impresión del documento ')

    super.vmo_doc()
  }   // Fin Procedure


  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.Cancela_docto.keyPress(nKeyCode, nShiftAltCtrl)
  }   // Fin Procedure



  // Evento   :When
  // Objeto  :Imprime
  // Tipo   :Buttom
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (await this.Form.rev_per('IPR')) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}