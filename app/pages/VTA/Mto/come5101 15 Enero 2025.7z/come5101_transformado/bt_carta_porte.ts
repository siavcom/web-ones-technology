//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : carta_porte
// Description : Componente carta_porte
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class bt_carta_porte extends IMGBUTTON {
  //public
  constructor() {
    super();

    this.prop.Caption = "Carta porte";
    this.prop.Disabled = true;
    this.prop.Position = 'footer'
    this.prop.Image = '/Iconos/svg/camion-003.png';

    //propiedades
  }
  override async click() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_lla1_doc.sta_doc != 'T') {
      this.Form.prop.Visible = false
      this.Form.WindowState = 1
      const router = useRouter();
      router.push({ name: 'logistica/dist1111', params: { Param1: vi_lla1_doc.tdo_tdo, Param2: vi_lla1_doc.ndo_doc } })

      this.Form.prop.Visible = true
      this.Form.WindowState = 0
    } // End If 

    this.prop.Disabled = true
  }   // Fin Procedure



  //IF  cometdo.dba_tdo='TRC' OR  cometdo.dba_tdo='TRM'  OR  cometdo.dba_tdo='TC4' OR 
  //cometdo.dba_tdo='TM4' OR cometdo.dba_tdo='CFC' OR cometdo.dba_tdo='T43' OR  cometdo.dba_tdo='M43'
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (cometdo.tip_cfd == 'T' || (cometdo.tip_cfd == 'I' && cometdo.dba_tdo == 'CFC')) {
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}