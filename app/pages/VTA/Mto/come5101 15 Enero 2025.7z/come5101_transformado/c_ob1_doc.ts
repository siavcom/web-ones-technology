//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : c_ob1_doc
// Description : Componente c_ob1_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class c_ob1_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.ControlSource = "vi_lla1_doc.ob1_doc";
    this.prop.Name = "c_ob1_doc";
    this.style.width = '297px';

    //propiedades
  }

  // Evento   :When
  // Objeto  :Observaciones
  override async when() {
    if (await this.Form.rev_per('OBS')) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure

  //metodo
}