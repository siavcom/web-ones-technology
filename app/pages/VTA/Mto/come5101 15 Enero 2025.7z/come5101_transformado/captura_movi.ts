//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Grid
// Class : captura_movi
// Description : Componente captura_movi
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { GRID } from "@/classes/Grid";

import { GRID } from "@/classes/Grid";
import { c_can_mov } from './captura_movi/c_can_mov';
import { c_cen_mov } from './captura_movi/c_cen_mov';
import { c_cla_isu } from './captura_movi/c_cla_isu';
import { c_des_isu } from './captura_movi/c_des_isu';
import { c_des_mov } from './captura_movi/c_des_mov';
import { c_dpe_mov } from './captura_movi/c_dpe_mov';
import { c_fec_mov } from './captura_movi/c_fec_mov';
import { c_fme_mov } from './captura_movi/c_fme_mov';
import { c_mpe_mov } from './captura_movi/c_mpe_mov';
import { c_npe_mov } from './captura_movi/c_npe_mov';
import { c_obs_mov } from './captura_movi/c_obs_mov';
import { c_ped_ped } from './captura_movi/c_ped_ped';
import { c_pve_mov } from './captura_movi/c_pve_mov';
import { c_ser_mov } from './captura_movi/c_ser_mov';
import { c_tba_tba } from './captura_movi/c_tba_tba';
import { c_uni_mov } from './captura_movi/c_uni_mov';
//imports

export class captura_movi extends GRID {
  public c_can_mov = new c_can_mov()
  public c_cen_mov = new c_cen_mov()
  public c_cla_isu = new c_cla_isu()
  public c_des_isu = new c_des_isu()
  public c_des_mov = new c_des_mov()
  public c_dpe_mov = new c_dpe_mov()
  public c_fec_mov = new c_fec_mov()
  public c_fme_mov = new c_fme_mov()
  public c_mpe_mov = new c_mpe_mov()
  public c_npe_mov = new c_npe_mov()
  public c_obs_mov = new c_obs_mov()
  public c_ped_ped = new c_ped_ped()
  public c_pve_mov = new c_pve_mov()
  public c_ser_mov = new c_ser_mov()
  public c_tba_tba = new c_tba_tba()
  public c_uni_mov = new c_uni_mov()
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Grid";


    this.prop.AllowAddNew = false;
    this.prop.ColumnCount = 16;
    this.Comment = "Objeto de catura de detalle de un documento";
    this.style.height = '129px';
    //LineSlant=12;
    this.style.mousePointer = '2';
    this.prop.Name = "captura_movi";
    this.nom_tab = ('COMEMOV');
    this.Panel = 1;
    this.prop.RecordSource = "vi_cap_comemov";
    this.RecordSourceType = 1;
    this.prop.ScrollBars = 3;
    this.prop.TabIndex = 41;
    this.style.top = '268px';
    this.style.width = '997px';
    this.style.zIndex = '81';
    this.Column1.style.backgroundColor = '255,255,255';
    this.Column1.Bound = false;
    this.Column1.prop.ColumnOrder = 1;
    this.Column1.prop.ControlSource = "";
    this.Column1.prop.Name = "c_dpe_mov";
    this.Column1.Sparse = false;
    this.Column1.style.width = '25';
    this.Column2.style.alignment = '7';
    this.Column2.style.backgroundColor = '255,255,255';
    this.Column2.Bound = false;
    this.Column2.prop.ColumnOrder = 2;
    this.Column2.prop.ControlSource = "";
    this.Column2.prop.Name = "c_npe_mov";
    this.Column2.prop.ReadOnly = false;
    this.Column2.Sparse = false;
    this.Column2.style.width = '59';
    this.Column3.style.backgroundColor = '255,255,255';
    this.Column3.Bound = false;
    this.Column3.prop.ColumnOrder = 3;
    this.Column3.prop.ControlSource = "";
    this.Column3.prop.Name = "c_mpe_mov";
    this.Column3.Sparse = false;
    this.Column3.style.width = '26';
    this.Column4.style.backgroundColor = '255,255,255';
    this.Column4.Bound = false;
    this.Column4.prop.ColumnOrder = 5;
    this.Column4.prop.ControlSource = "";
    this.Column4.prop.Name = "c_cla_isu";
    this.Column4.Sparse = false;
    this.Column4.style.width = '131';
    this.Column5.style.backgroundColor = '255,255,255';
    this.Column5.Bound = false;
    this.Column5.prop.ColumnOrder = 7;
    this.Column5.prop.ControlSource = "";
    this.Column5.prop.Name = "c_ser_mov";
    this.Column5.Sparse = false;
    this.Column5.style.width = '84';
    this.Column6.style.backgroundColor = '255,255,255';
    this.Column6.Bound = false;
    this.Column6.prop.ColumnOrder = 8;
    this.Column6.prop.ControlSource = "";
    this.Column6.prop.Name = "c_ped_ped";
    this.Column6.Sparse = false;
    this.Column6.style.width = '89';
    this.Column7.style.backgroundColor = '255,255,255';
    this.Column7.Bound = false;
    this.Column7.prop.ColumnOrder = 9;
    this.Column7.prop.ControlSource = "";
    this.Column7.prop.Name = "c_can_mov";
    this.Column7.Sparse = false;
    this.Column7.style.width = '75';
    this.Column8.style.backgroundColor = '255,255,255';
    this.Column8.Bound = false;
    this.Column8.prop.ColumnOrder = 10;
    this.Column8.prop.ControlSource = "";
    this.Column8.CurrentControl = "uni_mov";
    this.Column8.prop.Name = "c_uni_mov";
    this.Column8.Sparse = false;
    this.Column8.style.width = '46';
    this.Column9.style.backgroundColor = '255,255,255';
    this.Column9.Bound = false;
    this.Column9.prop.ColumnOrder = 11;
    this.Column9.prop.ControlSource = "";
    this.Column9.prop.Name = "c_pve_mov";
    this.Column9.Sparse = false;
    this.Column9.style.width = '76';
    this.Column10.style.backgroundColor = '255,255,255';
    this.Column10.Bound = false;
    this.Column10.prop.ColumnOrder = 12;
    this.Column10.prop.ControlSource = "";
    this.Column10.prop.Name = "c_des_mov";
    this.Column10.Sparse = false;
    this.Column10.style.width = '39';
    this.Column11.style.backgroundColor = '255,255,255';
    this.Column11.Bound = false;
    this.Column11.prop.ColumnOrder = 13;
    this.Column11.prop.ControlSource = "";
    this.Column11.prop.Name = "c_fec_mov";
    this.Column11.Sparse = false;
    this.Column12.style.backgroundColor = '255,255,255';
    this.Column12.Bound = false;
    this.Column12.prop.ColumnOrder = 14;
    this.Column12.prop.ControlSource = "";
    this.Column12.prop.Name = "c_fme_mov";
    this.Column12.Sparse = false;
    this.Column13.style.alignment = '7';
    this.Column13.style.backgroundColor = '255,255,255';
    this.Column13.Bound = false;
    this.Column13.prop.ColumnOrder = 6;
    this.Column13.prop.ControlSource = "";
    this.Column13.prop.Name = "c_des_isu";
    this.Column13.Sparse = false;
    this.Column13.style.width = '236';
    this.Column14.style.backgroundColor = '255,255,255';
    this.Column14.Bound = false;
    this.Column14.prop.ColumnOrder = 15;
    this.Column14.prop.ControlSource = "";
    this.Column14.prop.Name = "c_cen_mov";
    this.Column14.Sparse = false;
    this.Column14.style.width = '66';
    this.Column15.style.backgroundColor = '255,255,255';
    this.Column15.Bound = false;
    this.Column15.prop.ColumnOrder = 4;
    this.Column15.prop.ControlSource = "";
    this.Column15.prop.Name = "c_tba_tba";
    this.Column15.Sparse = false;
    this.Column15.style.width = '111';
    this.Column16.style.backgroundColor = '255,255,255';
    this.Column16.Bound = false;
    this.Column16.prop.Name = "c_obs_mov";
    this.Column16.Sparse = false;
    this.Column16.style.width = '111';

    //propiedades
  }
  async AfterRowColChange(nColIndex) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    super.vmo_doc()
    const vi_cap_comemov = await select('vi_cap_comemov')
    // si se incerto un nuevo renglon pero es mayor a los
    // renglones permitidos deshace el renglon

    if (await recNo() < 0 && await recCount() > cometdo.nmo_tdo) {
      await tableRevert()

      this.Form.MessageBox('No se permiten mas movimientos')
      this.columns(1).controls(2).setFocus()
    } // End If 

    this.Form.d_mov_mov.refresh
    this.Form.d_exi_pro.refresh
  }   // Fin Procedure
  //thisform.d_des_isu.refresh



  // evento  :grabar
  // objeto  :captura_movi
  // tipo   :grid
  // comentarios :este metodo grabara un renglon del grid
  async grabar(sw_rel, sw_bor) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_lla1_doc.sta_doc == 'T') {
      const vi_cap_comemov = await select('vi_cap_comemov')

      await tableRevert()

      return

    } // End If 

    if (PARAMETERS() == 1) {
      let sw_bor = false
    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')ó

    if (this.Form.sw_cie_per) {
      // si es un documento anterior al ultimo cierre
      return true

    } // End If 

    let reg_act = await recNo()
    // registro actual
    if (!this.sw_nue) {
      // si el registro no es nuevo
      let est_cam = getfldstate(-1)
      // obtiene la cadena de estatus de camposó
      let est_com = replicateString('1', len(est_cam))
      // estatus a comparar
      if (len(est_cam) == 0 || est_cam == est_com) {
        // si el estatus de todos los campos es = 1
        return true
        // sale sin actualizar

      } // End If 

    } // End If 

    est_cam = getfldstate(-1)
    // obtiene la cadena de estatus de campos
    if (LineSlant(est_cam, 1) > '2') {
      // si es un movimiento nuevo
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set mov_mov=?  where recno=${Recno} `, [this.Form.det_mov + 1])

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')
    //   && grabamos los d atos nuevos de la vista scatter memo to val_nue

    m = appendM(m, await scatter())// scatter 

    m.key_pri = vi_cap_comemov.key_pri
    let des_mov1 = vi_cap_comemov.des_mov
    const vi_lla1_mov = await select('vi_lla1_mov')ó
    // vista de actualizacion

    await useNodata('vi_lla1_mov') // use vi_lla1_mov vi_lla1_mov nodata
    // la inicializamos

    await appendBlank()

    let sw_del = false
    //if deleted('tabla') .or. reccount('tabla')=0    && si esta borrado el registro
    // append blank      && aumenta uno nuevo
    //endif
    // sw de borradoó
    if (LineSlant(est_cam, 1) > '2') {
      // si es un registro nuevo
      await gatherFrom(m)
      // grabamos de la variables de memoria

    } else {
      //   insert into tabla from array val_nue && incertamos los datos a la tabla de actualización

      //VFP  val_nue val_nue

      const vi_cap_comemov = await select('vi_cap_comemov')
      // seleccionamos la vista de captura de movimientos

      if (!deleted()) {
        // si no esta borrado el registro
        const val_nue = await scatter()// scatter 
        // Guardamos todos los datos nuevos a un óreglo

        await tableRevert()

        // deshacemos los cambios en la vista de captura
        m = appendM(m, await scatter())// scatter 
        // grabamos los datos viejos a memoria

        const vi_lla1_mov = await select('vi_lla1_mov')
        // seleccionamos vista de actualización

        await gatherFrom(m)
        // grabamos los datos viejos

        await tableUpdate()

        // actualizamos la tabla para borrar estatus de valores cambiados
        const vi_cap_comemov = await select('vi_cap_comemov')

        await gatherFrom(val_nue)
        // regresamos los datos nuevos a la vista de captura

        m = appendM(m, await scatter())// scatter 
        // leemos los datos nuevoa a memoria

        const vi_lla1_mov = await select('vi_lla1_mov')

        await gatherFrom(m)
        // grabamos los datos nuevos de la memoria en la tabla de actualizacion

        let est2_cam = getfldstate(-1)
        // Inicio replace VFP
        //   gather from val_nue memo  && grabamos los datos nuevos en la tabla de actualizacion
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set timestamp=?  where recno=${Recno} `, [vi_cap_comemov.timestamp])
        ó
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set key_pri=?  where recno=${Recno} `, [vi_cap_comemov.key_pri])

      } else {

        sw_del = true
        const vi_lla1_mov = await select('vi_lla1_mov')
        // seleccionamos tabla de grabación

        await tableUpdate()

        await gatherFrom(m)
        // grabamos sus datos nuevos

        await deleteLocalSql()
        // marcamos como registro borrado

      } // End If 

    } // End If 

    if (await recNo('vi_cap_comemov') > this.ulr_act) {
      // si no esta asignado el ultimo renglon de actualización
      this.ulr_act = await recNo('vi_cap_comemov')
    } // End If 

    this.Form.style.mousePointer = 11
    let sw_nue_mv = false
    if (await recNo() < 0) {
      sw_nue_mv = true
    } // End If 

    if (Public.value.ndb_emp == 3) {
      // si es Sybase
      await SQLExec("create table #control (tdo_tdo char(2),ndo_doc numeric (6),mov_mov numeric (3))")

    } // End If 

    let res_gra = gra_reg(this.nom_tab)
    // graba registro
    this.Form.style.mousePointer = 0
    if (res_gra) {
      // si hubo actualización
      if (sw_nue_mv) {
        // si el movimiento era nuevo
        this.Form.dpe_mov = vi_cap_comemov.dpe_movó
        // asignamos cual es el ultimo pedido capturado
        this.Form.npe_mov = vi_cap_comemov.npe_mov
        this.Form.mpe_mov = vi_cap_comemov.mpe_mov
      } // End If 

      if (this.Form.det_mov < vi_cap_comemov.mov_mov) {
        this.Form.det_mov = vi_cap_comemov.mov_mov
      } // End If 

      const vi_lla1_mov = await select('vi_lla1_mov')

      m = appendM(m, await scatter())// scatter 
      // leemos los datos actualizados

      const vi_cap_comemov = await select('vi_cap_comemov')
      // actualizamos el dato del saldo del docto del renglon

      await goto(reg_act)
      // se posiciona en el registro actual


      // grabamos los datos de control de actualizaciones
      if (!sw_del) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.key_pri=?  where recno=${Recno} `, [m.key_pri])

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.timestamp=?  where recno=${Recno} `, [m.timestamp])

      } // End If 

      await tableUpdate()
      ó
      // actualiza datos en la tabla de captura
      if (!deleted()) {
        // si no fue un borrado de registro
        if (await recNo() > this.ulr_act) {
          // si el renglon es mayor a la ultima actualziación
          this.ulr_act = await recNo()
        } // End If 

        this.renglon = await recNo()
        // indicamos que el utimo renglon capturado es este
      } // End If 

      let ins_sql = "select imp_doc,im0_doc,im1_doc,im2_doc,im3_doc,im4_doc,im5_doc,TIMESTAMP  from man_comedoc where tdo_tdo='" + this.Form.tdo_tdo.prop.Value + "' and ndo_doc=" + str(this.Form.ndo_doc.prop.Value)
      // nos traemos los totales del documento
      // ins_sql="select imp_doc,im1_doc,im2_doc,im3_doc,TIMESTAMP  from man_comedoc where tdo_tdo='"+
      //thisform.tdo_tdo.value+
      //"' and ndo_doc="+str(thisform.ndo_doc.value)
      const vi_lla1_doc = await select('vi_lla1_doc')

      m = appendM(m, await scatter())// scatter 

        = iif(await SQLExec(ins_sql, 'sqlresult') > 0, true, err_sql())
      const sqlresult = await select('sqlresult')

      m = appendM(m, await scatter())// scatter 

      if (await recCount() > 0) {
        this.Form.d_imp_doc.prop.Value = imp_doc
        // asigna valores a los totales del documento
        this.Form.d_im0_doc.prop.Value = im0_doc
        this.Form.d_im1_doc.prop.Value = im1_doc
        this.Form.d_im2_doc.prop.Value = im2_doc
        this.Form.d_im3_doc.prop.Value = im3_doc
        this.Form.d_im4_doc.prop.Value = im4_doc
        this.Form.d_im5_doc.prop.Value = im5_doc
        this.Form.d_imp_doc.refresh
        this.Form.d_im0_doc.refresh
        this.Form.d_im1_doc.refresh
        this.Form.d_im2_doc.refresh
        this.Form.d_im3_doc.refresh
        this.Form.d_im4_doc.refresh
        this.Form.d_im5_doc.refresh
        this.Form.d_tot_doc.prop.Value = imp_doc + im0_doc + im1_doc + im2_doc + im3_doc + im4_doc + im5_doc
        this.Form.d_tot_doc.refresh
        this.Form.d_mov_mov.refresh
      } // End If 

      releaseUse() // use 

      const vi_lla1_doc = await select('vi_lla1_doc')
      // actualiza los datos de la vistas

      await gatherFrom(m)

      await tableUpdate()

      const vi_cap_comemov = await select('vi_cap_comemov')

      this.Form.refresh
      // wait window 'movimiento='+str(vi_cap_comemov.mov_mov)
      // actualizamos los datos del documento

      //    thisform.sw_aut=.f.    && tumbamos la autorización
      // actualiza la descripcion de paso del detalle ya que la borra
      if (allTrim(vi_cap_comemov.dse_mov) > ' ') {
        // si hay descripcion secundaria la muestra
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.des_isu=?  where recno=${Recno} `, [vi_cap_comemov.dse_mov])

      } // End If 

      return true

    } // End If 

    return false

  }   // Fin Procedure



  // Evento  : Ins_renglon
  // Objeto  : tab_cap
  // Tipo   : metodo
  // Comentarios : Este metodo insertarí¡ un nuevo renglon
  async ins_renglon() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    await select(this.prop.RecordSource)

    this.Form.prop.key = 0
    this.sw_ins = true

    //goto bottom
    if (await recNo() > 0) {
      =this.Form.ins_movimiento()
      // Inicio replace VFP
      //   append blank
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set key_pri=?  where recno=${Recno} `, [-1])

    } // End If 

    await goto('BOTTOM')

    for (let i = 1; i < this.prop.ColumnCount; i++) {
      // Rutinas de validación apagadas
      this.columns(i).controls(2).prop.Valid = false
    } // End For; 

    this.sw_nue = true
    // Ponemos el Switch de registro nuevo
    return
    //key=0

  }   // Fin Procedure


  async lee_detalle() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.detalle()
  }   // Fin Procedure



  // Evento   :When
  // Objeto  :captura_movi
  // Tipo   :Grid
  // Comentarios :Verifica permisos
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_lla1_doc.sta_doc == 'X') {
      return false

    } // End If 

    if (this.Form.grabar()) {
      const vi_cap_comemov = await select('vi_cap_comemov')

      if (await recCount('vi_cap_comemov') == 0) {
  // si no tiene movimientos capturados
        =this.Form.detalle()
      } // End If 

      if (vi_lla1_doc.sta_doc == 'T') {
        const vi_cap_comemov = await select('vi_cap_comemov')

        await goto('TOP')

      } // End If 

      if (await this.Form.rev_per('MOV', true)) {
        // manda revizar permisos
        return true

      } // End If 

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}