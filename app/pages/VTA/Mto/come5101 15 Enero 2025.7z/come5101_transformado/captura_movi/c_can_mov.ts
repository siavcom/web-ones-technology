//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_can_mov
// Description : Componente c_can_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_can_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_cap_comemov.can_mov";
    this.prop.ColumnTextLabel = "Cantidad";
    //propiedades
  }

  override async init() {
    await super.init();
    this.prop.InputMask = ('9999,999.' + replicateString('9', Public.value.dci_pge));
    this.prop.Decimals = Public.value.dci_pge
  }

  // evento   :gotfocus
  // objeto  :can_mov
  // tipo   :cuadro de texto
  // comentarios :calcula la existencia si es un producto
  override async gotFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await currentValue('*', 'vi_cap_comemov')
    const cometdo = await currentValue('*', 'cometdo')
    // si es una entrada o no es un producto no calcula existencia
    if (cometdo.inv_tdo == 'E' || vi_cap_comemov.tin_tti != 'P') {
      return

    } // End If 

    if ((vi_cap_comemov.pim_pro == 1 || vi_cap_comemov.sse_pro == 'S') && (cometdo.inv_tdo == 'E' || cometdo.inv_tdo == 'S')) {
      return

    } // End If 
    m = vi_cap_comemov

    let fec_con = m.fec_mov
    // fecha de consulta+"'"
    m.ped_ped = iif(vi_cap_comemov.pim_pro == 1 && (cometdo.inv_tdo == 'E' || cometdo.inv_tdo == 'S'), vi_cap_comemov.ped_ped, "null")
    m.ser_mov = iif(vi_cap_comemov.sse_pro == 'SL' && (cometdo.inv_tdo == 'E' || cometdo.inv_tdo == 'S'), vi_cap_comemov.ser_mov, "null")
    m.alm_mov = iif(cometdo.inv_tdo == 'ESP', vi_cap_comemov.alm_tda, "null")
    m.cod_nom = iif(cometdo.cop_nom == 'C' && cometdo.inv_tdo == 'S', vi_lla1_doc.cod_nom, 'null')

    // calcula existencia
    // si hay un producto ofertado y tiene control de cantidad y es salida
    if (cometdo.inv_tdo == 'S' && nvl(vi_cap_comemov.sw_tca, 0) == 1 && vi_cap_comemov.cof_tca > 0) {
      if (Public.value.ine_pge == 'N') {
        if (vi_cap_comemov.cof_tca - vi_cap_comemov.cve_tca < this.Form.d_exi_pro.prop.Value) {
          this.Form.d_exi_pro.prop.Value = vi_cap_comemov.cof_tca - vi_cap_comemov.cve_tca
        } // End If 

      } else {

        this.Form.d_exi_pro.prop.Value = vi_cap_comemov.cof_tca - vi_cap_comemov.cve_tca
      } // End If 

    } // End If 

    return

  }   // Fin Procedure



  // evento   :valid
  // objeto  :can_mov
  // tipo   :cuadro de texto
  // comentarios :si es un producto con número de serie y es una entrada o salida
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result


    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    if (this.prop.Value <= 0) {
      // si el valor es menor a cero
      return false
      ó
    } // End If 


    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 

    if (this.prop.Value != await oldValue(this.prop.Name)) {
      this.prop.Valid = false
    } // End If 

    m = await currentValue('*', 'vi_cap_comemov')

    // si es un producto reviza su existencia

    m = appendM(m, await scatter())// scatter 

    const fac_isu = []

    fac_isu[1] = 1
    fac_isu[2] = m.fa2_isu
    fac_isu[3] = m.fa3_isu
    const vi_cap_comemov = await select('vi_cap_comemov')
    // si es un movimiento nuevo y pertenece a un pedido

    if ((this.Form.prop.Valid == 'VE' || this.Form.prop.Valid == 'CO' || this.Form.prop.Valid == 'PG') && this.Parent.c_dpe_mov.dpe_mov.prop.Value != '  ' && await recNo() < 0) {
      let por_ent = (vi_ver_npe.can_mov - vi_ver_npe.cen_mov)
        // calcula cantidad por entregar del pedido
        * fac_isu(vi_ver_npe.med_mov)
      if (por_ent - (this.prop.Value * fac_isu(vi_cap_comemov.med_mov))) {
        <0
      if (this.Form.prop.Valid == 'PG') {
          this.Form.MessageBox('Cantidad mayor al lo que resta de la autorización ', 16, 'Error', 3600)
          this.prop.Valid = false
          return false

        } else {

          this.Form.MessageBox('Cantidad mayor al lo que resta del pedido ', 16, 'Error', 3600)
          if (this.Form.max_ped == 1) {
            return false

          } // End If 

        } // End If 

      } // End If 

    } // End If 

    if (cometdo.inv_tdo != 'S' && this.Form.prop.Valid != 'VE') {
      // si no es una venta y no es salidaó
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.can_mov=?  where recno=${Recno} `, [this.prop.Value])

      this.Parent.Parent.c_uni_mov.uni_mov.prop.Valid = false
      // apagamos validacion de unidad
      this.prop.Valid = false
      // Se manda validar
      return this.Parent.Parent.c_uni_mov.uni_mov.valid()

    } // End If 
    //   this.tag='1'    14/May/2012
    //   this.parent.parent.rev_val()
    //   return .t.


    // si es un movimiento de venta y no pertenece a un pedido
    if ((this.Form.prop.Valid == 'VE') && this.Parent.c_dpe_mov.dpe_mov.prop.Value == '  ') {

      // si tiene descuentos
      // if .not. eof('vi_lla1_tdf')   -- Ver 2014
      // si es mayor o igual a la cantidad para asignar descuento
      if (vi_cap_comemov.can_tdf > 0) {

        //    if this.value//fac_isu(vi_cap_comemov.med_mov)>=vi_lla1_tdf.can_tdf
        if (this.prop.Value * fac_isu(vi_cap_comemov.med_mov) >= vi_cap_comemov.can_tdf) {
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set de5_mov=?  where recno=${Recno} `, [vi_cap_comemov.de5_tdf])

        } else {

          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set de5_mov=?  where recno=${Recno} `, [0])

        } // End If 

        // calcula el descuento total
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [round(100 - ((100 - de1_mov) * ((100 - de2_mov) / 100) * ((100 - de3_mov) / 100) * ((100 - de4_mov) / 100) * ((100 - de5_mov) / 100)), 2)])

      } // End If 
      //    this.parent.parent.c_des_mov.des_mov.value=round(100-((100-de1_mov)//
      //((100-de2_mov)/100)//
      //((100-de3_mov)/100)//
      //((100-de4_mov)/100)//
      //((100-de5_mov)/100)),3)

    } // End If 

    this.Parent.Parent.c_uni_mov.uni_mov.prop.Valid = false
    // 16/ene/2009   estaba comentado todo esto 11/Abr/2012
    // En caso que la validación sea verdadera se debe de apagar la validacion
    // de la unidad
    //this.Parent.Parent.c_uni_mov.uni_mov.tag='0'
    //this.parent.parent.rev_val()
    // apagamos validacion de unidad
    this.prop.Valid = false
    // Se manda validar
    let res_val = this.Parent.Parent.c_uni_mov.uni_mov.valid()
    if (res_val) {
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.can_mov=?  where recno=${Recno} `, [this.prop.Value])

      if (this.Form.prop.Valid == 'PP') {
        // si es un pedido a proveedores
        res_val = this.Parent.Parent.c_fec_mov.fec_mov.valid()
      } // End If 

    } // End If 

    this.prop.Valid = true
    // por mientras
    return res_val

  }   // Fin Procedure
  // return .t.



  // evento   :when
  // objeto  :can_mov
  // tipo   :cuadro de texto
  // comentarios :si es un producto con número de serie y es una entrada o salida
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    if ((this.Form.prop.Valid == 'PC' || this.Form.prop.Valid == 'PP') && (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) && vi_cap_comemov.dpa_isu == 1) {
      // .and. cometdo.cop_nom$'cp'
      const router = useRouter();
      router.push({ name: 'formas\dse_mov' })

      if (allTrim(vi_cap_comemov.dse_mov) > ' ') {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.des_isu=?  where recno=${Recno} `, [vi_cap_comemov.dse_mov])

      } // End If 

    } // End If 
    //!//  this.tag='0'



    // si no es validado correctamente
    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
      return false
      //!//     IF key<>15
      //!//        KEYBOARD '{BACKTAB}'
      //!//     endif

    } // End If 


    //!// if (vi_lla1_doc.cop_nom='C' or vi_lla1_doc.cop_nom='P') and recno('vi_cap_comemov')>0 and recno('vi_lla1_tca')>0 and vi_lla1_tca.cla_isu<>vi_cap_comemov.cla_isu
    //!//    thisform.obten_precio
    //!//    select vi_lla1_tca
    //!//    scatter MEMVAR memo
    //!// endif
    //!//
    // Si es producto con numero de serie no permite cambiar la cantidad
    if (vi_cap_comemov.tin_tti == 'P' && vi_cap_comemov.sse_pro == 'S' && cometdo.inv_tdo$'ES') {
      this.prop.Valid = true
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

    return

  }   // Fin Procedure


  //metodo
}