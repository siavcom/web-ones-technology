//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_cla_isu
// Description : Componente c_cla_isu
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_cla_isu extends COLUMN {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_cap_comemov.cla_isu";
    this.prop.InputMask = (Public.value.ima_pge);
    //LineSlant=41;
    this.prop.Name = "c_cla_isu";

    this.prop.ColumnTextLabel = "Clave";


  }

  // evento   :click
  // objeto  :keypress
  // tipo   :buttom
  // comentarios :crea el objeto de bus_nom
  override async keyPress(nkeycode, nshiftaltctrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    let des_cla = this.prop.Value
    // desde donde tomara el insumo
    this.Form.prop.key = nkeycode
    if ((this.Form.prop.key > 0 && char(this.Form.prop.key) == '?') || ((this.Form.prop.key == 13 || this.Form.prop.key == 9) && (this.prop.Value == transform(space(30), Public.value.ima_pge) || this.prop.Value == space(30)))) {
      // consulta de insumos
      //VFP  "" "" clear
      // limpia el teclado

      if (this.Form.prop.Valid != 'PG' && this.Form.prop.Valid != 'AE') {
        //thisform.pga_pga.Value=SPACE(12)
        const router = useRouter();
        router.push({ name: 'formas\con_isu', params: { Param1: 'cla_isu' } })// tom.cla_isu

      } else {

        const router = useRouter();
        router.push({ name: 'formas\con_isu_eno', params: { Param1: 'cla_isu', Param2: vi_lla1_tba.pga_pga } })// tom.cla_isu

      } // End If 

      this.keyPress(0)
      this.prop.Value = m.cla_isu
    } // End If 

    if (this.Form.prop.key == 10) {
      // si da un crt enter
      des_cla = this.prop.Value
      let valor = this.prop.Value
      let pos = rat(' ', rTrim(this.prop.Value))
      if (pos > 0) {
        des_cla = LineSlant(des_cla, pos - 1)
      } else {

        des_cla = this.prop.Value
      } // End If 

      if (len(rTrim(des_cla)) < 2) {
        return

      } // End If 

      let has_cla = LineSlant(rTrim(des_cla) + replicateString('Z', 30), 30)
      let ins_sql = "select cla_isu,des_isu,un1_isu,sku_isu from vcome3201 where cla_isu>='" + des_cla + "' and cla_isu<='" + has_cla + "' and est_isu='A' "
      =iif(await SQLExec(ins_sql) > 0, 0, err_sql())
      if (await recCount() == 0) {
        this.Form.MessageBox('No hay claves')
        this.Form.prop.key = 0
        if (Public.value.ndb_emp == 2) {
          // si es interbase
          // sqlcommit ( Public.value.num_dbs ) 

          await SQLExec("commit work;")

        } // End If 

        const vi_cap_comemov = await select('vi_cap_comemov')

        return

      } // End If 

      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // sqlcommit ( Public.value.num_dbs ) 

        await SQLExec("commit work;")

      } // End If 

      //VFP  windows windows lista from 0 , 4 to 17 , 100 title 'Catí¡logo ' in desktop panel grow zoom style.font "arial" , 9

      //VFP  fields fields cla_isu :h = 'Clave' , des_isu :h = 'Descripción' , un1_isu :h = 'Unidad ' , sku_isu :h = 'SKU ' noappend noedit nodelete last window lista

      m.cla_isu = cla_isu
      this.keyPress(0)
      //VFP  '' '' clear
      // limpia el teclado

      this.prop.Value = m.cla_isu
    } // End If 

    return

  }   // Fin Procedure

  // evento   :valid
  // objeto  :cla_isu
  // tipo   :cuadro de texto
  // comentarios :verifica si existe el documento de pedido
  // Ultima modificacion     29/jun/2016
  // 17/Jul/2016 Fdo.Cuadras.- Se redondea el precio de venta a decimales de captura
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const fac_isu = new Array(3)
    const pve_isu1 = new Array(5)
    const uni_isu1 = new Array(3)
    const vmo_doc1 = new Array(5)
    const vi_lla1_doc = await select('vi_lla1_doc')

    m = appendM(m, await scatter())// scatter 

    const vi_cap_comemov = await select('vi_cap_comemov')

    m.cla_isu = vi_cap_comemov.cla_isu
    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      Return.T.
  } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')
    // si res=1 no sucedio nada
    // si no cambio de valor

    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      // 24/Abr/2015 se quila la lectura del insumo
      return true
      // .and. vi_lla1_isu.cla_isu=vi_cap_comemov.cla_isu and 
      //  vi_lla1_pro.cla_isu=vi_cap_comemov.cla_isu AND RECNO('vi_cap_comemov')>0

    } // End If 

    this.prop.Valid = false
    if (res == -2 && this.prop.Value == await oldValue(this.prop.Name)) {
      // 24/Abril/2015 regresa un -2 cuando registro nuevo
      return true

    } // End If 

    if (char(this.Form.prop.key) == '?' || this.Form.prop.key == 10 || ((this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 0) && (this.prop.Value == Transform(space(30), Public.value.ima_pge) || this.prop.Value == space(30)))) {
      //.or. key=0
      if (this.prop.Value == Transform(space(30), Public.value.ima_pge)) {
        this.prop.Valid = false
      } // End If 

      return true

    } // End If 


    //// Revisar si cuando viende ya de un pedido y se cambio la clave, revisar la funcion oldval
    // si cambio de clave
    if (await recNo('vi_cap_comemov') < 1 || vi_cap_comemov.cla_isu != await oldValue('vi_cap_comemov.cla_isu')) {
      this.prop.Valid = false
      // apagamos validaciones
      if (this.Form.prop.Valid != 'PC' && this.Form.prop.Valid != 'PP' && this.Form.prop.Valid != 'PG') {
        this.Parent.Parent.c_ser_mov.ser_mov.prop.Valid = false
        this.Parent.Parent.c_ped_ped.ped_ped.prop.Valid = false
      } // End If 

      this.Parent.Parent.c_can_mov.can_mov.prop.Valid = false
      this.Parent.Parent.c_uni_mov.uni_mov.prop.Valid = false
      this.Parent.Parent.c_pve_mov.pve_mov.prop.Valid = false
      if (this.Form.prop.Valid != 'IN') {
        this.Parent.Parent.c_des_mov.des_mov.prop.Valid = false
      } // End If 

      if (!this.Form.obten_precio()) {
        // obtiene el precio del cliente o proveedor
        this.Form.MessageBox('No existe la clave', 16, '', 5000)
        return false

      } // End If 

      let sw_sal = true
      if (await recNo('vi_cap_comemov') > 0) {
        // si no es un registro nuevo
        if (this.Form.prop.Valid != 'PC' && this.Form.prop.Valid != 'PP' && this.Form.prop.Valid != 'PG') {
          sw_sal = this.Parent.Parent.c_ser_mov.ser_mov.valid()
          sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_ped_ped.ped_ped.valid())
        } // End If 

        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_can_mov.can_mov.valid())
        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_uni_mov.uni_mov.valid())
        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_pve_mov.pve_mov.valid())
      } // End If 

      if (!sw_sal) {
        return false

      } // End If 

    } // End If 

    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :cla_isu
  // tipo   :textbox
  // comentarios :reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    if (vi_cap_comemov.dpe_mov > '   ') {
    } // End If 
    // RETURN this.valid()
    //RETURN .f.

    if (this.Form.prop.Valid == 'C0' || this.Form.prop.Valid == 'VE') {
      this.Form.captura_movi.c_npe_mov.npe_mov.prop.Valid = true
      this.Form.captura_movi.c_mpe_mov.mpe_mov.prop.Valid = true
      this.Form.captura_movi.c_dpe_mov.dpe_mov.prop.Valid = true
    } // End If 

    if (await this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

  }   // Fin Procedure


  //metodo
}