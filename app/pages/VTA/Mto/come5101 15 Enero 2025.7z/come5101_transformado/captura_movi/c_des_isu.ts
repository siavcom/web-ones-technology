//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_des_isu
// Description : Componente c_des_isu
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_des_isu extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_cap_comemov.des_isu";
    this.prop.ColumnTextLabel = "Descripción";

    //propiedades
  }

  //metodo
}