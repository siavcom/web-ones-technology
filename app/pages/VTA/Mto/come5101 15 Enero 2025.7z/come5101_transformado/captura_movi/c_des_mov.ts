//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_des_mov
// Description : Componente c_des_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_des_mov extends COLUMN {
  //public
  constructor() {
    super();

    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_cap_comemov.des_mov";
    //LineSlant=39;
    this.prop.Name = "c_des_mov";
    this.prop.Style = 0;
    this.style.top = '46px';
    this.prop.Value = 0;

    this.style.backgroundColor = '234,234,234';
    this.prop.ColumnTextLabel = "Descto.";
    this.style.fontSize = '8px';

    //propiedades
  }

  override async init() {
    this.prop.InputMask = "999.99";
    this.prop.Decimals = 2
  }


  // Evento   :KeyPress
  // Objeto  :des_mov
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nKeyCode
    if (this.Form.prop.key == 77.or.this.Form.prop.key == 109) {
      // captura descuentos en cascada
      const router = useRouter();
      router.push({ name: 'formas\des_mov' })// todes_tot

      this.prop.Value = des_tot
      // finaliza el descuento total
      this.prop.Valid = false
      this.valid
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [des_tot])

    } // End If 
    //    this.valid

  }   // Fin Procedure



  // evento   :valid
  // objeto  :des_mov
  // tipo   :cuadro de texto
  // comentarios :
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    if (this.Form.prop.key == 77 || this.Form.prop.key == 109) {
      // si se van a captura descuentos en cascada
      return

    } // End If 

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If í
    í

    // si se dio directo el descuento y no hay descuentos en
    // cascada
    if (vi_cap_comemov.des_mov > 0 && vi_cap_comemov.de2_mov == 0 && vi_cap_comemov.de3_mov == 0 && vi_cap_comemov.de4_mov == 0 && vi_cap_comemov.de5_mov == 0) {
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de1_mov=?  where recno=${Recno} `, [vi_cap_comemov.des_mov])

    } // End If 

    let des_tot = ROUND(100 - ((100 - vi_cap_comemov.de1_mov) * ((100 - vi_cap_comemov.de2_mov) / 100) * ((100 - vi_cap_comemov.de3_mov) / 100) * ((100 - vi_cap_comemov.de4_mov) / 100) * ((100 - vi_cap_comemov.de5_mov) / 100)), 2)
    if (des_tot < 0 || des_tot > 100) {
      this.Form.MessageBox('No se permite un descuento mayor al 100% o en negativo', 16, 'Advertencia', 5000)
      this.prop.Valid = false
      return false

    } // End If 


    //if round(this.value,3)<>des_tot && habÃ­a descuentos en cascada y se capturo nuevo
    if (ROUND(vi_cap_comemov.des_mov, 2) != des_tot) {
      // habÃ­a descuentos en cascada y se capturo nuevo
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de1_mov=?  where recno=${Recno} `, [this.prop.Value])
      // descuento

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de2_mov=?  where recno=${Recno} `, [0])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de3_mov=?  where recno=${Recno} `, [0])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de4_mov=?  where recno=${Recno} `, [0])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.de5_mov=?  where recno=${Recno} `, [0])

    } // End If 

    des_tot = 100 - ((100 - vi_cap_comemov.de1_mov) * ((100 - vi_cap_comemov.de2_mov) / 100) * ((100 - vi_cap_comemov.de3_mov) / 100) * ((100 - vi_cap_comemov.de4_mov) / 100) * ((100 - vi_cap_comemov.de5_mov) / 100))
    // Inicio replace VFP
    //IF des_tot<0 OR des_tot>100
    //   thisform.messagebox('No se permite un descuento mayor al 100% o en negativo',16,'Advertencia',50000)
    //   RETURN .f.
    //endif
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [des_tot])

    this.prop.Value = des_tot

    this.prop.Valid = true
    // reviza el precio minimo de venta
    this.Parent.parent.rev_val()
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :des_mov
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_nom = await select('vi_lla1_nom')

    m = appendM(m, await scatter())// scatter 

    const vi_lla1_doc = await select('vi_lla1_doc')

    m = appendM(m, await scatter())// scatter 

    const vi_cap_comemov = await select('vi_cap_comemov')

    m = appendM(m, await scatter())// scatter 
    // leemos variables



    //!// 24/Abr/2015 --Se quita la lectura del insumo
    //!// if vi_lla1_isu.cla_isu#vi_cap_comemov.cla_isu  or 
    //    (vi_lla1_pro.cla_isu#vi_cap_comemov.cla_isu .and. vi_lla1_isu.tin_tti='P')
    //!//  this.parent.parent.c_cla_isu.cla_isu.valid
    //!// endif
    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
      return false
      //!//     IF key<>15
      //!//        KEYBOARD '{BACKTAB}'
      //!//     endif

    } // End If 


    // si ya es un producto ya capturado anteriormente revizamos precios por contrato
    //  21/may/2007 se quito .- and (recno('vi_lla1_tca')<1 or vi_lla1_tca.cla_isu<>vi_cap_comemov.cla_isu) and (m.cop_nom='c' or m.cop_nom='p')
    //!// if (m.cop_nom='C' or m.cop_nom='P') and recno('vi_cap_comemov')>0 and recno('vi_lla1_tca')>0 and vi_lla1_tca.cla_isu<>vi_cap_comemov.cla_isu
    //!// //   thisform.obten_precio
    //!//  //  select vi_lla1_tca
    //!//  //  scatter MEMVAR memo
    //!//  endif
    // y tambien reviza si es un precio por contrato
    //if reccount('vi_lla1_tca')>0  &&&and vi_lla1_tca.ppa_tca>0 and vi_lla1_tca.fvi_tca>=thisform.fec_doc.value
    if (m.sw_tca == 1) {
      this.prop.Valid = true
      //  this.gotfocus
      this.valid
      return false

    } // End If 


    ////////////////////////////
    if (await this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      return true

    } // End If 

    this.gotFocus()
    this.valid
    return false

  }   // Fin Procedure


  //metodo
}