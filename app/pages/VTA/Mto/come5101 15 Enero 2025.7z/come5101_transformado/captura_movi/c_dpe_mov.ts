//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : editBox
// Class : c_dpe_mov
// Description : Componente c_dpe_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_dpe_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_cap_comemov.dpe_mov";
    this.prop.ReadOnly = false;
    this.prop.ColumnTextLabel = "Pedido";
    //propiedades
  }

  // Evento   :Click
  // Objeto  :keyPress
  // Tipo   :TextBox
  // Comentarios :Busca los pedidos activos del cliente o proveedor
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeyCode
    const vi_cap_comemov = await select('vi_cap_comemov')

    m = appendM(m, await scatter())// scatter 

    if (this.Form.prop.key > 0 && char(this.Form.prop.key) == '?') {
      // consulta pedidos activos
      //VFP  "" "" clear

      switch (true) {
        case vi_lla1_doc.cop_nom == 'C':
          let alm_pdo = vi_lla1_doc.als_doc
          break
        case vi_lla1_doc.cop_nom == 'P':
          alm_pdo = 'null'
      } // End case 

      =con_pdo_sur(iif(this.Form.prop.Valid == 'PG', 'T', vi_lla1_doc.cop_nom), iif(this.Form.prop.Valid == 'PG', this.Form.tba_tba.prop.Value, vi_lla1_doc.cod_nom), alm_pdo, @m.dpe_mov, @m.npe_mov, @m.mpe_mov, @m.can_mov)
      // =con_pdo_sur(IIF(thisform.tag='PG','T',vi_lla1_doc.cop_nom),IIF(thisform.tag='PG',thisform.tba_tba.value,vi_lla1_doc.cod_nom),iif(vi_lla1_doc.cop_nom='C',
      //vi_lla1_doc.als_doc,vi_lla1_doc.ale_doc),
      //@m.dpe_mov,@m.npe_mov,@m.mpe_mov,@m.can_mov)
      // ,thisform.doc_per 9/Ags/2023 si agrega documentos permitidos en la consulta
      const vi_cap_comemov = await select('vi_cap_comemov')

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set dpe_mov=?  where recno=${Recno} `, [m.dpe_mov])
      // asignamos el pedido escogido

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set npe_mov=?  where recno=${Recno} `, [m.npe_mov])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set mpe_mov=?  where recno=${Recno} `, [m.mpe_mov])
      // valida el pedido

      this.Form.dpe_mov = m.dpe_mov
      this.Form.npe_mov = m.npe_mov
      this.Form.mpe_mov = 0
      this.Parent.c_mpe_mov.mpe_mov.valid()
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set can_mov=?  where recno=${Recno} `, [m.can_mov])

      this.keyPress(0)
      //VFP  '' '' clear
      // limpia el teclado

    } // End If 

    return

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :dpe_mov
  // Tipo   :Cuadro de texto
  // Comentarios :Verifica si existe el documento de pedido
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    if (this.Form.prop.key == 27) {
      return true

    } // End If 


    // si era un dato ya capturado y no cambio en nada
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 

    if (!this.prop.Value == '  ') {
      // si contiene algun valor
      const vi_lla1_tdo = await select('vi_lla1_tdo')

      m.tdo_tdo = this.prop.Value
      await use('vi_lla1_tdo', m) // use vi_lla1_tdo vi_lla1_tdo

      if (await recCount() == 0 || (inv_tdo != 'P' && at(tdo_tdo, this.Form.doc_sur) == 0) || cop_nom != cometdo.cop_nom) {
        this.Form.MessageBox('Documento a surtir invalido')
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.dpe_mov')
        } // End If 

        this.prop.Valid = false
        return false

      } // End If 

      const vi_cap_comemov = await select('vi_cap_comemov')

    } // End If 

    this.prop.Valid = true
    // dato valido
    if (this.prop.Value != '  ') {
      this.Form.dpe_mov = this.prop.Value
      if (vi_cap_comemov.npe_mov != 0) {
      } // End If 
      //  this.parent.parent.c_mpe_mov.mpe_mov.valid

    } else {

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.npe_mov=?  where recno=${Recno} `, [0])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.mpe_mov=?  where recno=${Recno} `, [0])

      this.Parent.c_npe_mov.npe_mov.prop.Valid = true
      this.Parent.c_mpe_mov.mpe_mov.prop.Valid = true
    } // End If 

    this.Parent.parent.rev_val()
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :dpe_mov
  // tipo   :textbox
  // comentarios :reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    this.Refresh

    //!// IF (cometdo.cop_nom='C' AND  cometdo.inv_tdo<>'S') OR (cometdo.cop_nom='P' AND  cometdo.inv_tdo<>'E')
    //!//    this.tag='1'
    //!//    this.Parent.Parent.c_npe_mov.npe_mov.Tag='1'
    //!//    this.Parent.Parent.c_mpe_mov.mpe_mov.Tag='1'
    //!//  //  this.Parent.Parent.pri_col=1
    //!//  //  this.valid
    //!//    this.Parent.Parent.pri_col=4
    //!//    return .f.
    //!// endif
    //!// this.Parent.Parent.pri_col=1
    if (this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      if (await recNo() < 0 && this.Form.dpe_mov != '  ') {
        // asigna el ultimo documento de pedido que se capturo
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.dpe_mov=? , vi_cap_comemov.npe_mov=?  where recno=${Recno} `, [this.Form.dpe_mov, this.Form.npe_mov])

        this.Refresh
      } // End If 

      this.prop.Valid = true
      return true
      // this.parent.parent.pri_col=1 &&//////////////////////////////////////////////////

    } else {

      this.prop.Valid = true
      // aumente esto 16/may/2005
      this.Form.prop.key = 0
      //!//  If Recno('vi_cap_comemov')>0 && 11/Ene/2018
      //!//   If Len(Alltrim(This.Value))>0  && si el movimiento no es nuevo
      //!//    This.Valid
      //!//   Endif
      //!//  Endif
      this.valid
      // 11/Ene/2018
      return false
      // this.parent.parent.pri_col=4
      //!//  this.Parent.Parent.c_npe_mov.npe_mov.Tag='1'
      //!//  this.Parent.Parent.c_mpe_mov.mpe_mov.Tag='1'

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}