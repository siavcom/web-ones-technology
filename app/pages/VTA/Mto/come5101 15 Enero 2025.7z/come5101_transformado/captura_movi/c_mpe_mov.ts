//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_mpe_mov
// Description : Componente c_mpe_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_mpe_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.ColumnTextLabel = "Detalle";
    this.prop.ControlSource = "vi_cap_comemov.mpe_mov";
    this.prop.Decimals = 0
    this.prop.Max = "9999"
    //propiedades
  }

  // evento   :valid
  // objeto  :dpe_mov
  // tipo   :cuadro de texto
  // comentarios :verifica si existe el documento de pedido
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    const vmo_doc1 = new Array(5)
    const med_isu = new Array(3)
    m = appendM(m, await scatter())// scatter 

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return true
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 


    // si no ha cambiado algun valor
    // y ya ha leido el pedido original
    if (await recNo('vi_ver_npe') > 0 && this.Parent.c_dpe_mov.dpe_mov.prop.Value == await oldValue('vi_cap_comemov.dpe_mov') && this.Parent.c_npe_mov.npe_mov.prop.Value == await oldValue('vi_cap_comemov.npe_mov') && this.prop.Value == await oldValue('vi_cap_comemov.mpe_mov')) {
      this.prop.Valid = true
      return true

    } // End If ó

    this.prop.Valid = false
    let sw_sur = false
    // switch de pedido surtido

    // si hay datos completos de pedidos
    if (vi_cap_comemov.dpe_mov != '  ' || vi_cap_comemov.mpe_mov != 0) {
      m.tdo_tdo = vi_cap_comemov.dpe_mov
      // asignamos los valores del pedido
      m.ndo_doc = vi_cap_comemov.npe_mov
      m.mov_mov = vi_cap_comemov.mpe_mov
      // this.value
      const vi_ver_npe = await select('vi_ver_npe')
      // seleccionamos la vista de verificación de pedido

      await use('vi_ver_npe', m) // use vi_ver_npe vi_ver_npe
      // verifica si existe el pedido

      if (await recCount() == 0) {
        this.Form.MessageBox('No existe el movimiento del documento a surtir', 16, 'Error', 3600)
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.mpe_mov')
        } // End If 

        return false

      } // End If 

      m = appendM(m, await scatter())// scatter 
      // nos traemos sus datos

      const vi_cap_comemov = await select('vi_cap_comemov')

      if (this.Form.prop.Valid != 'PG' && allTrim(m.cod_nom) != allTrim(this.Form.cod_nom.prop.Value)) {
        // revisamos codigo
        this.Form.MessageBox('No pertenece al mismo cliente o proveedor', 16, 'Error', 3600)
        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.mpe_mov')
        } // End If 
        ó
        return false

      } else {

      } // End If 
      //!//     IF vi_ver_npe.tba_tba#vi_cap_comemov.tba_tba
      //!//      thisform.messagebox('Este movimiento no pertenece al mismo trabajador',16,'Error',3600)
      //!//      if recno()>0       && si no es un registro nuevo
      //!//       this.value=oldval('vi_cap_comemov.mpe_mov')
      //!//      endif
      //!//      return .f.
      //!//   endif


      // revizamos si el pedido ya esta surtido
      // if m.can_mov-m.cen_mov+iif(recno()>0,oldval('vi_cap_comemov.can_mov'),0)<=0
      if (m.can_mov - vi_ver_npe.cen_mov + iif(await recNo() > 0, await oldValue('vi_cap_comemov.can_mov'), 0) <= 0) {
        if (this.Form.prop.Valid != 'PG' && this.Form.MessageBox('Pedido ya surtido. tomamos datos del pedido ', 4 + 32) != 6) {
          if (await recNo() > 0) {
            // si no es un registro nuevo
            this.prop.Value = await oldValue('vi_cap_comemov.mpe_mov')
          } // End If ó

          return false

        } else {

          if (this.Form.prop.Valid == 'PG') {
            this.Form.MessageBox('Esta autorización ya estí¡ surtida', 16, 'Error', 3600)
            if (await recNo() > 0) {
              // si no es un registro nuevo
              this.prop.Value = await oldValue('vi_cap_comemov.mpe_mov')
            } // End If 

            return false

          } // End If 

        } // End If 

        m.dpe_mov = '  '
        m.npe_mov = 0
        m.npe_mov = 0
        this.Parent.c_dpe_mov.dpe_mov.prop.Value = '  '
        this.Parent.c_npe_mov.npe_mov.prop.Value = 0
        this.prop.Value = 0
        sw_sur = true
        // pedido ya surtido
      } // End If 


      // si el almacen es diferente al que se pidio
      if (this.Form.prop.Valid != 'PG' && len(allTrim(m.alm_tda)) > 1 && m.alm_tda != vi_cap_comemov.alm_tda && vi_cap_comemov.alm_tda != '  ') {
        if (this.Form.MessageBox("El pedido pertence a otro almacen. procedemos con la asignación del pedido", 4 + 32) != 6) {
          return false

        } // End If 

      } // End If 

      this.Parent.c_cla_isu.cla_isu.prop.Value = m.cla_isu
      const vi_cap_comemov = await select('vi_cap_comemov')
      // valida el insumo

      m = appendM(m, await scatter())// scatter 
      // retornamos valores originales

      if (!this.Parent.c_cla_isu.cla_isu.valid()) {
        return false

      } // End If 

      vmo_doc1(1) = 1
      // asignamos valores de las monedas
      vmo_doc1(2) = vi_lla1_doc.vm2_doc
      vmo_doc1(3) = vi_lla1_doc.vm3_doc
      vmo_doc1(4) = vi_lla1_doc.vm4_doc
      vmo_doc1(5) = vi_lla1_doc.vm5_doc
      const vi_cap_comemov = await select('vi_cap_comemov')
      //   select vi_lla1_isu       && obtenemos la unidad del pedido
      // validamos para llenar todos los campos de vi_cap_comemov

      med_isu(1) = vi_cap_comemov.un1_isu
      med_isu(2) = vi_cap_comemov.un2_isu
      med_isu(3) = vi_cap_comemov.un3_isu
      const vi_cap_comemov = await select('vi_cap_comemov')

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set med_mov=?  where recno=${Recno} `, [vi_ver_npe.med_mov])
      // asignamos su unidad

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set de1_mov=?  where recno=${Recno} `, [vi_ver_npe.de1_mov])
      // asignamos descuentos

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set de2_mov=?  where recno=${Recno} `, [vi_ver_npe.de2_mov])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set de3_mov=?  where recno=${Recno} `, [vi_ver_npe.de3_mov])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set de4_mov=?  where recno=${Recno} `, [vi_ver_npe.de4_mov])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set de5_mov=?  where recno=${Recno} `, [vi_ver_npe.de5_mov])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set dse_mov=?  where recno=${Recno} `, [vi_ver_npe.dse_mov])
      // descripcion de paso

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set des_isu=?  where recno=${Recno} `, [' '])
      // descripcion del insumo

      // Inicio replace VFP
      // asigna el trabajador
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.tba_tba=?  where recno=${Recno} `, [vi_ver_npe.tba_tba])

      // Inicio replace VFP
      // this.parent.parent.c_can_mov.can_mov.value=vi_ver_npe.can_mov-vi_ver_npe.cen_mov
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set can_mov=?  where recno=${Recno} `, [vi_ver_npe.can_mov - vi_ver_npe.cen_mov])

      // Inicio replace VFP
      // calcula precio de venta
      // this.parent.parent.c_pve_mov.pve_mov.value=vi_ver_npe.pve_mov//vmo_doc1(vi_ver_npe.mon_doc)/
      //vmo_doc1(vi_lla1_doc.mon_doc)
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set pve_mov=?  where recno=${Recno} `, [vi_ver_npe.pve_mov * vmo_doc1(vi_ver_npe.mon_doc) / vmo_doc1(vi_lla1_doc.mon_doc)])

      this.Parent.c_pve_mov.pve_mov.prop.Valid = true
      // Inicio replace VFP
      // asigna espacios a pedimento
      // this.parent.parent.c_ped_ped.ped_ped.value=space(len(this.parent.parent.c_ped_ped.ped_ped.value))
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set ped_ped=?  where recno=${Recno} `, [space(12)])

      // Inicio replace VFP
      // asigna medida
      // this.parent.parent.c_uni_mov.uni_mov.value=med_isu(med_mov)
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [med_isu(med_mov)])

      // Inicio replace VFP
      // asigna espacios a número de serie
      // this.parent.parent.c_ser_mov.ser_mov.value=space(len(this.parent.parent.c_ser_mov.ser_mov.value))
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set ser_mov=?  where recno=${Recno} `, [space(12)])

      // Inicio replace VFP
      // calcula el desuento total
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set des_mov=?  where recno=${Recno} `, [ROUND(100 - ((100 - de1_mov) * ((100 - de2_mov) / 100) * ((100 - de3_mov) / 100) * ((100 - de4_mov) / 100) * ((100 - de5_mov) / 100)), 2)])

      this.Parent.c_dpe_mov.dpe_mov.prop.Valid = true
      this.Parent.c_npe_mov.npe_mov.prop.Valid = true
      this.prop.Valid = true
      // dato valido
      this.Parent.c_cla_isu.cla_isu.prop.Valid = false
      // apagamos las demas validaciones
      this.Parent.c_can_mov.can_mov.prop.Valid = false
      if (this.Form.prop.Valid != 'PG') {
        this.Parent.c_ped_ped.ped_ped.prop.Valid = false
        this.Parent.c_ser_mov.ser_mov.prop.Valid = false
        this.Parent.c_pve_mov.pve_mov.prop.Valid = false
        this.Parent.c_uni_mov.uni_mov.prop.Valid = false
      } else {

        this.Parent.c_pve_mov.pve_mov.prop.Valid = true
        this.Parent.c_uni_mov.uni_mov.prop.Valid = true
      } // End If 

    } // End If 

    if (!sw_sur) {
      this.Parent.parent.rev_val()
    } // End If 

    if (this.Form.mpe_mov < this.prop.Value) {
      this.Form.mpe_mov = this.prop.Value
    } // End If 

    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :mpe_doc
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')



    //!// if this.readonly
    //!//  return .f.
    //!// endif
    if (len(allTrim(this.Parent.c_dpe_mov.dpe_mov.prop.Value)) == 0) {
      this.prop.Valid = true
      return false

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    if (await recNo() < 0 && this.prop.Value == 0) {
      // si el movimiento es nuevo
      this.prop.Value = this.Form.mpe_mov + 1
    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}