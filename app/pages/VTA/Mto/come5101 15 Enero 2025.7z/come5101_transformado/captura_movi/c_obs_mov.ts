//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_obs_mov
// Description : Componente c_obs_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_obs_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "textarea";
    this.prop.ColumnTextLabel = "Observaciones";
    this.prop.ControlSource = "vi_cap_comemov.obs_mov";
    //propiedades
  }
  override async when() {
    super.when()
    this.prop.Valid = true
  }   // Fin Procedure

  //metodo
}