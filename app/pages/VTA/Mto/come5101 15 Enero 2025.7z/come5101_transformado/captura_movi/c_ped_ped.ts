//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_ped_ped
// Description : Componente c_ped_ped
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_ped_ped extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "t_textbox";


    this.style.backgroundColor = '234,234,234';
    this.prop.ColumnTextLabel = "Pedimento";
    this.style.fontSize = '8px';
    this.prop.Name = "c_ped_ped";

    this.style.alignment = '0';
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_cap_comemov.ped_ped";
    this.prop.InputMask = (replicateString('X', 15));
    //LineSlant=28;
    this.Seconds = 0;
    this.style.top = '27px';
    this.style.width = '2px';

    //propiedades
  }
  ó
  // Evento   :init
  // Objeto  :c_ped_ped
  // Tipo   :ComboBox
  // Comentarios :Dependiendo de la versión deshabilita el control
  override async init() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (tip_ver == 'L') {
      this.prop.Visible = false
      this.style.width = 0
    } // End If 

  }   // Fin Procedure



  // Evento   :keyPress
  // Objeto  :ped_ped
  // Tipo   :text
  // Comentarios :Busca los pedimentos activos de un producto
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeyCode
    if (this.Form.prop.key > 0 && char(this.Form.prop.key) == '?') {
      // consulta pedimentos activos
      //VFP  "" "" clear

      this.prop.Value = con_exi_ped(vi_cap_comemov.cla_isu, vi_cap_comemov.fec_mov, vi_cap_comemov.alm_tda)
      this.keyPress(0)
      //VFP  '' '' clear
      // limpia el teclado

    } // End If 

    return

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :ped_ped
  // Tipo   :Cuadro de texto
  // Comentarios :Verifica si existe el pedimento aduanal
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      Return.T.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    if (char(this.Form.prop.key) == '?') {
      return true

    } // End If 


    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return trueó

    } // End If 

    if (vi_cap_comemov.pim_pro == 0 || !cometdo.inv_tdo$'ES') {
      this.prop.Valid = true
      return true

    } // End If ó

    m = appendM(m, await scatter())// scatter 

    this.prop.Valid = false
    //select(0)

    let ins_sql = "SET datestyle = 'ISO,dmy' "

    // si es un documento de importacion
    if (this.prop.Value == space(15) && vi_lla1_tdo.afi_tdo == 1) {
      this.Form.MessageBox('No se permiten datos en blanco')
      return false

    } // End If 
    ó
    if (this.prop.Value != space(15)) {
      // si se capturo un pedimento
      const vi_lla1_ped = await select('vi_lla1_ped')
      // reviza si hay pedimento de importación

      m.ped_ped = this.prop.Value
      await use('vi_lla1_ped', m) // use vi_lla1_ped vi_lla1_ped

      if (await recCount() == 0) {
        ó
        const vi_cap_comemov = await select('vi_cap_comemov')

        this.Form.MessageBox('No existe el pedimento de importación')
        if (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) {
          return false

        } // End If 

        return true

      } // End If 

      m.afi_tdo = 0
      if (!cometdo.tra_tdo == 1) {
        // si no es un traspaso
        m.ped_ped = this.prop.Value
        // pedimento
      } else {

        const vi_lla1_tdo = await select('vi_lla1_tdo')
        // reviza si el traspaso hace una entrada de importación

        m.tdo_tdo = cometdo.ptr_tdo
        await use('vi_lla1_tdo', m) // use vi_lla1_tdo vi_lla1_tdo

        m = appendM(m, await scatter())// scatter 

        const vi_cap_comemov = await select('vi_cap_comemov')

        if (m.afi_tdo == 1) {
          // si es una entrada de importación
          m.ped_ped = "null"
          // pedimento null porque se sacara de un almacen no de venta
        } else {

          m.ped_ped = this.prop.Value
          // pedimento
        } // End If 

      } // End If 

    } else {

      m.ped_ped = space(15)
      // pedimento
    } // End If 

    let fec_con = m.fec_mov
    // fecha de consulta
    m.ped_ped = iif(vi_cap_comemov.pim_pro == 1, vi_cap_comemov.ped_ped, "null")
    m.ser_mov = iif(vi_cap_comemov.sse_pro$'SL', vi_cap_comemov.ser_mov, "null")
    m.alm_mov = iif(cometdo.inv_tdo$'ES', vi_cap_comemov.alm_tda, 'null')
    m.cod_nom = iif(cometdo.cop_nom == 'C'.And.cometdo.inv_tdo == 'S', vi_lla1_doc.cod_nom, 'null')
    m.exi_pro = cal_exi_gen(m.cla_isu, m.fec_mov, m.alm_mov, m.ped_ped, m.ser_mov, m.cod_nom)
    // calcula existencia por pedimento
    if (cometdo.inv_tdo == 'E') {
      // si es una entrada
      this.prop.Valid = true
      this.Parent.Parent.rev_val()
      return true

    } else {

      if (m.exi_pro <= 0) {
        this.Form.MessageBox('No hay existencia suficiente en el pedimento')
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('ped_ped')
        } // End If 
        ó
        if (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) {
          return false

        } // End If 

        return true

      } // End If 

    } // End If 

    this.prop.Valid = true
    const vi_cap_comemov = await select('vi_cap_comemov')

    this.Parent.Parent.rev_val()
    // Inicio replace VFP
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set vi_cap_comemov.exi_alm=?  where ócno=${Recno} `, [m.exi_pro])

    this.Form.d_exi_pro.refresh
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :ped_ped
  // tipo   :cuadro de texto
  // comentarios :si es un producto con número de serie y es una entrada o salida
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')


    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
      return false

    } // End If 


    //!//  24/Abr/2015 --Se quita la lectura del insumo
    //!//           && si no se han leido los datos del insumo
    //!// if vi_lla1_isu.cla_isu#vi_cap_comemov.cla_isu  or (vi_lla1_isu.tin_tti='P' .and. vi_lla1_pro.cla_isu#vi_cap_comemov.cla_isu)
    //!//  this.parent.parent.c_cla_isu.cla_isu.valid
    //!// endif
    // si no hay validación del insumo
    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
      this.Parent.parent.activatecell(this.Parent.parent.ActiveRow, this.Parent.parent.ActiveColumn - 1)
      return false

    } // End If 

    if (vi_cap_comemov.tin_tti != 'P') {
      // si no es un producto
      this.prop.Valid = true
      return false

    } // End If 

    if ((vi_cap_comemov.sse_pro == 'S' || vi_cap_comemov.sse_pro == 'L') && cometdo.inv_tdo == 'S') {
      // si es un producto con número de serie o lote
      this.prop.Valid = true
      return false

    } // End If 


    // si hay pedimento aduanal predeterminado (entrada de importación)
    if (len(rTrim(vi_lla1_doc.ped_ped)) > 0) {
      this.prop.Value = vi_lla1_doc.ped_ped
      const router = useRouter();
      router.push({ name: 'formas\ped_mov' })

      this.prop.Valid = false
      this.valid
      return false

    } // End If 


    // si es un producto con número de serie o lote
    // y no tiene serie o lote
    if (vi_cap_comemov.sse_pro$'SL' && this.Parent.c_ser_mov.ser_mov.prop.Valid == false) {
      this.Parent.c_sse_pro.sse_pro.setFocus()
    } // End If 


    // si es un producto con número de serie
    // y es importado
    // se trae el pedimento aduanal
    if (vi_cap_comemov.sse_pro == 'S' && vi_cap_comemov.pim_pro == 1) {
      let ins_sql = upper("select ped_ped from man_comemov where ser_mov='" + this.Parent.c_ser_mov.ser_mov.prop.Value + "' AND PED_PED>' ' AND SPI_MOV<>'D' ")
        = iif(await SQLExec(ins_sql) > 0, true, err_sql())
      // nos traemos los datos mas nuevos
      if (await recNo() > 0) {
        m = appendM(m, await scatter())// scatter 

      } else {

        releaseUse() // use 

        this.Form.MessageBox('No existe pedimento para este producto')
        m.exi_pro = 0
        if (Public.value.ndb_emp == 2) {
          // si es interbase
          // sqlcommit ( Public.value.num_dbs ) 

          await SQLExec("commit work;")

        } // End If 

        const vi_cap_comemov = await select('vi_cap_comemov')

        this.prop.Valid = false
        return false

      } // End If 

      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // sqlcommit ( Public.value.num_dbs ) 

        await SQLExec("commit work;")

      } // End If 

    } // End If 


    // habilitar solo cuando sea una entrada o salida
    // y si es un producto importado
    if (vi_cap_comemov.pim_pro == 1 && cometdo.inv_tdo$'ES') {
      switch (true) {
        case cometdo.inv_tdo == 'E':
          // es entrada
          Result = await localAlaSql(`INSERT INTO consulta select ave_tda from cometda_ent where alm_tda = vi_lla1_doc.ale_doc AND ave_tda = 1`)

          break
        case cometdo.inv_tdo == 'S' && !cometdo.tra_tdo == 1:
          // es salida y no es un traspaso
          Result = await localAlaSql(`INSERT INTO consulta select ave_tda from cometda_sal where alm_tda = vi_lla1_doc.als_doc AND ave_tda = 1`)

          break
        case cometdo.inv_tdo == 'S' && cometdo.tra_tdo == 1:
          // es salida y es un traspaso
          Result = await localAlaSql(`INSERT INTO consulta select ave_tda from cometda_ent where alm_tda = vi_lla1_doc.ale_doc AND ave_tda = 1`)

      } // End case 

      const consulta = await select('consulta')

      if (await recCount() > 0) {
        releaseUse() // use 

        if (await this.Form.rev_per(this.prop.Name, true)) {
          // manda revizar permisos
          return true

        } else {

          this.gotFocus()
          this.valid
          return false

        } // End If 

      } // End If 

      releaseUse() // use 

    } // End If 

    this.prop.Valid = true
    return false

  }   // Fin Procedure


  //metodo
}