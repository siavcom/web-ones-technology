//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : editBox
// Class : c_tba_tba
// Description : Componente c_tba_tba
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_tba_tba extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "editBox";

    this.prop.Type = 'text';
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_cap_comemov.tba_tba";
    //LineSlant=52;
    this.prop.Name = "c_tba_tba";
    this.style.top = '30px';

    //propiedades
  }

  // Evento   :KeyPress
  // Objeto  :tba_tba
  // Tipo   :Text
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeycode
    m.cod_nom = ''
    if (char(this.Form.prop.key) == '?' || ((this.Form.prop.key == 13 || this.Form.prop.key == 9) && this.prop.Value == '      ')) {
      // consulta de nombres
      //VFP  "" "" clear

      m.pga_pga = vi_lla1_doc.pga_pga
      const router = useRouter();
      router.push({ name: 'formas\con_TBA', params: { Param1: m.pga_pga, Param2: 'TBA_TBA' } })// tom.tba_tba

      this.prop.Value = m.tba_tba
      //VFP  chr chr ( 127 ) + m.tba_tba
      ó
    } // End If 

    return

  }   // Fin Procedure



  // evento   :valid
  // objeto  :tba_tab
  // tipo   :cuadro de texto
  // comentarios :es la validación de codigo del cliente o proveedor
  override async valid(par_val) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      Return.T.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    if (char(this.Form.prop.key) == '?') {
      return true

    } // End If 


    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 

    if (this.prop.Value == space(12)) {
      // si pidio ayuda
      this.prop.Valid = true
      return true

    } // End If 

    if (char(this.Form.prop.key) == '?') {
      // si pidio ayuda
      this.prop.Valid = false
      return true

    } // End If 

    m.tba_tba = this.prop.Value
    const vi_lla1_tba = await select('vi_lla1_tba')
    // lee los datos generales del trabajador

    await requery()

    if (await recCount() == 0) {
      this.Form.MessageBox('No existe trabajador', 16, 'Error', 3000)
      return false

    } // End If 

    m = appendM(m, await scatter())// scatter 

    MessageBox(vi_lla1_tba.nom_tba)

    m.pga_pga = allTrim(this.Form.pga_pga.prop.Value)
    // si cambio de codigo o es un codigo nuevo o es un documento que tiene
    if (this.Form.tba_tba.prop.Value != this.prop.Value) {
      // si es entrga no es  a un supervisor
      if (LineSlant(vi_lla1_tba.pga_pga, len(allTrim(m.pga_pga))) != m.pga_pga) {
        this.Form.MessageBox('Trabajador fuera de area', 16, 'Error', 3000)
        return false

      } // End If 

    } // End If 

    m.cop_nom = 'T'
    m.cod_nom = this.prop.Value
    const vi_cap_comemen = await select('vi_cap_comemen')

    await requery()

    // lee mensajes del trabajador
    // VFP SCAN 
    while (!eof()) {
      this.Form.MessageBox('Mensaje No ' + str(num_men, 2) + ' :' + men_men)
      skip()
    } // End while 

    await goto('TOP')

    if (m.est_tba == 'B') {
      let men_blo = 'Trabajador bloqueado, ' + char(13)ó
      this.Form.MessageBox(men_blo)
      this.prop.Valid = false
      return false

    } // End If 

    if (this.Form.tba_tba.prop.Value != this.prop.Value) {
      // si no es entrga a un supervisor pone le presupuesto de gasto de trabajador
      m.pga_pga = vi_lla1_tba.pga_pga
    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    // Inicio replace VFP
    //replace pga_pga WITH m.pga_pga
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set pga_pga=?  where recno=${Recno} `, [m.pga_pga])

    this.prop.Valid = true
    // damos por bueno el dato
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :tba_tba
  // Tipo   :Cuadro de texto
  // Comentarios :
  // si proviene de una autorización
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_cap_comemov.dpe_mov > '   ') {
      this.valid
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}