//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_combobox
// Class : c_uni_mov
// Description : Componente c_uni_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_uni_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "t_combobox";


    this.style.backgroundColor = '234,234,234';
    this.prop.ColumnTextLabel = "Uni.";
    this.style.fontSize = '8px';
    this.prop.Name = "c_uni_mov";

    this.style.alignment = '2';
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_cap_comemov.uni_mov";
    this.prop.Format = "K";
    this.prop.InputMask = "XXXX";
    //LineSlant=24;
    this.style.top = '27px';

    this.prop.ColumnCount = 2;
    this.prop.ControlSource = "vi_cap_comemov.uni_mov";
    this.DragMode = 0;
    //LineSlant=21;
    this.prop.Name = "uni_mov_ant";
    this.prop.RowSource = "";
    this.prop.RowSourceType = 0;
    this.style.top = '30px';

    //propiedades
  }

  // evento   :keypress
  // objeto  :uni_mov
  // tipo   :cuadro de texto
  // comentarios :
  override async keyPress(nkeycode, nshiftaltctrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const uni_isu = new Array(3)
    // private i 

    if (nkeycode < 32) {

      return

    } // End If 

    this.Form.prop.key = nkeycode
    let nkeycode = 0
    const vi_cap_comemov = await select('vi_cap_comemov')

    m = appendM(m, await scatter())// scatter 

    uni_isu(1) = m.un1_isu
    //// 23/Abr/2015 se quita las lecturas de los insumos
    //!// select vi_lla1_isu          && si no ha leido los datos del insumo
    //!// if reccount('vi_lla1_isu')=0 .or. vi_lla1_isu.cla_isu#this.parent.parent.c_cla_isu.cla_isu.value
    //!//  select vi_cap_comemov          && leemos datos
    //!//  scatter MEMVAR memo
    //!//  select vi_lla1_isu
    //!//  use vi_lla1_isu
    //!//  scatter MEMVAR memo
    //!//  select vi_lla1_pro
    //!//  use vi_lla1_pro
    //!// else
    //!//  scatter MEMVAR memo
    //!// endif
    // asignamos unidades
    uni_isu(2) = m.un2_isu
    uni_isu(3) = m.un3_isu
    const vi_cap_comemov = await select('vi_cap_comemov')
    //!// uni_isu(1)=LEFT(vi_cap_comemov.uni_mov,3)          && asignamos unidades
    //!// uni_isu(2)=SUBSTR(vi_cap_comemov.uni_mov,5,3)
    //!// uni_isu(3)=SUBSTR(vi_cap_comemov.uni_mov,9,3)

    let uni_ant = uni_mov
    // asigna unidad anterior
    if (this.Form.prop.key == 32) {
      // selecciona siguiente unidad si da
      for (let uni = 1; uni < 3; uni++) {
        // barra espaciadora
        if (allTrim(uni_isu(uni)) == allTrim(uni_ant)) {
          // asignamos medidas
          if (allTrim(uni_mov) != allTrim(uni_isu(iif(uni == 3, 1, uni + 1)))) {
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [uni_isu(iif(uni == 3, 1, uni + 1))])


            //    this.value=          uni_isu(iif(uni=3,1,uni+1))
          } // End If 

          brake
        } // End If 

      } // End For; 

    } else {

      let letra = upper(char(this.Form.prop.key))
      // deciframos letra
      switch (true) {
        case letra == LineSlant(m.un1_isu, 1) && allTrim(uni_mov) != allTrim(uni_isu(1)):
          // si da una letra
          // reviza si la primera letra es la misma y es difernte el valor
          this.prop.Value = uni_isu(1)
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [uni_isu(1)])

          break
        case letra == LineSlant(m.un2_isu, 1) && allTrim(uni_mov) != allTrim(uni_isu(2)):
          this.prop.Value = uni_isu(2)
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [uni_isu(2)])

          break
        case letra == LineSlant(m.un3_isu, 1) && allTrim(uni_mov) != allTrim(uni_isu(3)):
          this.prop.Value = uni_isu(3)
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [uni_isu(3)])

          break      default:             //VFP  '' '' clear
        // limpia el teclado

      } // End case 

    } // End If 

    if (uni_mov == '   ') {
      // si la medida es 0 o la unidad a nada
      this.prop.Value = uni_isu(1)
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set uni_mov=?  where recno=${Recno} `, [uni_isu(1)])
      // asigna como unidad principal

    } // End If 

    if (this.prop.Value != uni_mov) {
      this.prop.Value = uni_mov
    } // End If 

    //VFP  chr chr ( 5 )

    return

  }   // Fin Procedure



  // evento   :valid
  // objeto  :uni_mov
  // tipo   :cuadro de texto
  // comentarios :se utilizan dos variables para la medida del producto
  //    a) uni_mov .-esta variable es tipo char y nos muestra la medida con tres letras
  //     ejemplo: pza, caj, lit etc.
  //    b) med_mov .-esta variable es de tipo numerica y nos indica cual el el número de
  //        medida que le corresponde ejemplo: cuando es 1 el la primer medida
  //                   : cuando es 2 es la segunda medida
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const uni_isu = new Array(3)
    const fac_isu = new Array(3)
    const pve_isu = new Array(5)
    const vi_cap_comemov = await select('vi_cap_comemov')

    if (await recCount('vi_cap_comemov') == 0) {
      return true

    } // End If 

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
  } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')
    // si no cambio de valor

    m = appendM(m, await scatter())// scatter 

    if (this.prop.Valid == true && this.Parent.c_can_mov.can_mov.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name) && this.Parent.c_can_mov.can_mov.prop.Value == await oldValue('can_mov')) {
      return true
      ó
    } // End If 

    uni_isu(1) = m.un1_isu
    // asignamos unidades
    uni_isu(2) = m.un2_isu
    uni_isu(3) = m.un3_isu
    fac_isu(1) = 1
    // asignamos factores de unidades
    fac_isu(2) = m.fa2_isu
    fac_isu(3) = m.fa3_isu
    let num_uni = 0
    let med_ant = vi_cap_comemov.med_mov
    // medida anterior
    const vi_cap_comemov = await select('vi_cap_comemov')

    if (med_mov == 0) {
      // si no tiene asignada medida
      let uni_mov = uni_isu(1)
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [1])

      let med_mov = 1
      med_ant = 1
    } // End If 

    for (let i = 1; i < 3; i++) {
      // reviza unidad por unidad para definir
      if (uni_mov ==== uni_isu(i)) {
        // la medida
        if (med_mov != i) {
          // si la medida es diferente
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set med_mov=?  where recno=${Recno} `, [i])

        } // End If 

      } // End If 

    } // End For; 


    // si descarga de un pedido
    if ((this.Form.prop.Valid == 'VE' || this.Form.prop.Valid == 'CO' || this.Form.prop.Valid == 'PG') && this.Parent.c_dpe_mov.dpe_mov.prop.Value != '  ' && await recNo() < 0) {
      let por_ent = (vi_ver_npe.can_mov - vi_ver_npe.cen_mov)
        // calcula cantidad por entregar del pedido
        * fac_isu(vi_ver_npe.med_mov)
      if (por_ent - (this.Parent.c_can_mov.can_mov.prop.Value * fac_isu(vi_cap_comemov.med_mov))) {
        <0
    } // End If 

    } // End If 


    //  Nueva validación puesta el  16/Ene/2009
    // si es una salida
    // si es un producto ofertado
    // si no permite inventario en negativo
    // o es un producto con numero de serie o lote
    // o es un producto importado
    if (cometdo.inv_tdo == 'S' && vi_cap_comemov.tin_tti == 'P' && (Public.value.ine_pge == 'N' || vi_cap_comemov.sse_pro$'SL' || vi_cap_comemov.pim_pro == 1 || (NVL(vi_cap_comemov.sw_tca, 0) == 1 && vi_cap_comemov.cof_tca > 0))) {
      if (this.Form.cal_exi == 'SI' && vi_cap_comemov.can_mov * fac_isu(med_mov) - iif(await recNo('vi_cap_comemov') > 0, vi_cap_comemov.can_mov * await oldValue('med_mov'), 0) > vi_cap_comemov.exi_alm) {
        this.Form.MessageBox('Cantidad inví¡lida, rebasa existencia')
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          await tableRevert()

        } // End If 

        this.prop.Valid = false
        if (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) {
          return false

        } // End If 

        return true

      } // End If 

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    if (MED_MOV == 0) {
      return

    } // End If 

    if (med_ant != med_mov) {
      // si cambio de unidad
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.pve_mov=?  where recno=${Recno} `, [ROUND(vi_cap_comemov.pve_mov / fac_isu(med_ant) * fac_isu(med_mov), Public.value.dcp_pge)])

      this.Parent.c_pve_mov.pve_mov.prop.Valid = true
    } // End If 


    // si es un movimiento de venta y no pertenece a un pedido
    if ((this.Form.prop.Valid == 'VE') && this.Parent.c_dpe_mov.dpe_mov.prop.Value == '  ') {

      // si tiene descuentos
      // si es mayor o igual a la cantidad para asignar descuento
      if (vi_cap_comemov.can_tdf > 0 && vi_cap_comemov.can_mov * fac_isu(vi_cap_comemov.med_mov) >= vi_cap_comemov.can_tdf) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set de5_mov=?  where recno=${Recno} `, [vi_cap_comemov.de5_tdf])

      } else {

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set de5_mov=?  where recno=${Recno} `, [0])

      } // End If 

      // calcula el descuento total
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [round(100 - ((100 - de1_mov) * ((100 - m.de2_mov) / 100) * ((100 - m.de3_mov) / 100) * ((100 - m.de4_mov) / 100) * ((100 - m.de5_mov) / 100)), 2)])

    } // End If 

    this.prop.Valid = true
    this.Parent.c_can_mov.can_mov.prop.Valid = true
    // 11/Abr/2012  como se valida en par la cantidad con la unidad
    this.Parent.parent.rev_val()
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :uni_mov
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')


    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
      return false

    } // End If 

    if (vi_cap_comemov.tin_tti == 'P' && vi_cap_comemov.sse_pro == 'S' && cometdo.inv_tdo$'ES') {
      this.prop.Valid = true
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

  }   // Fin Procedure


  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    const vi_cap_comemov = await select('vi_cap_comemov')

    if (await recCount('vi_cap_comemov') == 0) {
      return true

    } // End If 

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')
    // si no cambio de valor

    m = appendM(m, await scatter())// scatter 

    if (this.prop.Valid == true && this.Parent.c_can_mov.can_mov.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name) && this.Parent.c_can_mov.can_mov.prop.Value == await oldValue('can_mov')) {
      return true

    } // End If 

    switch (true) {
      case this.prop.Value == vi_cap_comemov.un1_isu && vi_cap_comemov.med_mov != 1:
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [1])

        break
      case this.prop.Value == vi_cap_comemov.un2_isu && vi_cap_comemov.med_mov != 2:
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [2])

        break
      case this.prop.Value == vi_cap_comemov.un3_isu && vi_cap_comemov.med_mov != 3:
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [3])

        break      default:                   // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [1])

    } // End case 

    this.Parent.c_can_mov.can_mov.prop.Valid = true
  }   // Fin Procedure


  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    let num_ele = this.ListCount
    for (let i = num_ele; i < 1; i--) {

      this.RemoveListItem(i)
    } // End For; 

    for (i = 1; i < 3; i++) {
      switch (true) {
        case i == 1:
          let des_med = vi_cap_comemov.un1_isu
          //substr(vi_cap_comemov.uni_mov,(i*6)-5,3)
          break
        case i == 2:
          des_med = vi_cap_comemov.un2_isu
          break
        case i == 3:
          des_med = vi_cap_comemov.un3_isu
      } // End case 

      if (len(allTrim(des_med)) > 0) {

        this.AddItem(des_med)
      } else {
        //         this.DisplayValue=des_med


        return

      } // End If 

    } // End For; 


  }   // Fin Procedure


  //metodo
}