//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : tab_xml
// Class : captura_xml
// Description : Componente captura_xml
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { TAB_XML } from "@/classes/tab_xml";

import { TAB_XML } from "@/classes/tab_xml";
//imports

export class captura_xml extends TAB_XML {
//public
 	constructor() {
     super();
     this.prop.BaseClass = "tab_xml";
     
    this.style.height='93px';
//LineSlant=23;
    this.prop.Name="captura_xml";
    this.prop.TabIndex=117;
    this.style.top='464px';
    this.style.width='541px';
    this.style.zIndex='111';
    this.var_dxm.Header1.prop.Name="Header1";
    this.var_dxm.prop.Name="var_dxm";
    this.var_dxm.var_dxm.prop.Name="var_dxm";
    this.des_dxm.des_dxm.prop.Name="des_dxm";
    this.des_dxm.Header1.prop.Name="Header1";
    this.des_dxm.prop.Name="des_dxm";
    this.val_dxm.Header1.prop.Name="Header1";
    this.val_dxm.prop.Name="val_dxm";
    this.val_dxm.val_dxm.prop.Name="val_dxm";
    this.val_dxm.val_dxm1.prop.Name="val_dxm1";

     //propiedades
     }
       // manda grabar los campos xml
override async valid(){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (  ! this.Form.sw_nue){  // hay campos xml
      if (  ! this.val_dxm.val_dxm.valid()){
        return false

      } // End If 

      this.Form.captura_xml.graba_xml('COMEDOC',vi_lla1_doc.key_pri)
    } // End If 

  }   // Fin Procedure
//metodo
}