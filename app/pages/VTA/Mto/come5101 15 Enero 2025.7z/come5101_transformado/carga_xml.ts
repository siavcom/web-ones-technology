//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : carga_xml
// Description : Componente carga_xml
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class carga_xml extends IMGBUTTON {
  //public
  constructor() {
    super();


    this.style.backgroundColor = '234,234,234';
    this.prop.Caption = "Carga XML";
    this.prop.Disabled = true;
    this.style.height = '37px';
    //LineSlant=633;
    this.prop.Name = "carga_xml";
    this.prop.TabIndex = 123;
    this.style.top = '599px';
    this.prop.Visible = false;
    this.style.width = '85px';

    //propiedades
  }

  // Evento   :Click
  // Objeto  :Carga xml
  // Tipo   :Buttom
  // Comentarios :
  override async click() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    // SET DATE DMY 

    m.FEC_XML_PVE = iif(await select("PGEXML")
      > 1 && len(FIELD("FEC_XML_PVE", "PGEXML")) > 3, PGEXML.FEC_XML_PVE, "S")
    if (M.FEC_XML_PVE == 'N' && this.Form.MessageBox('Recuerde digitar la fecha del documento antes de cargar el xml, Continuamos?', 4) != 6) {
      return false

    } // End If 

    m.CLA_COMPRA = iif(await select("PGEXML")
      ////VALIDAMOS QUE SE ENCUENTRE REGISTRADA LA CLAVE DE PRODUCTO COMODIN PARA EN CASO DE NO ESTAR REGISTRADA LA CLAVE DE PRODUCTOS EN CLAVES ALTERNAS O INSUMOS
      > 1 && len(FIELD("CLA_COMPRA", "PGEXML")) > 3, PGEXML.CLA_COMPRA, "NO EXISTE")
    if (m.CLA_COMPRA == 'NO EXISTE') {
      this.Form.MessageBox('ESTE PROCESO NO SE PUEDE GENERAR, NO ESTA REGISTRADA EN CAMPOS XML LA CLAVE DEL PRODUCTO COMODIN, PARA EN CASO DE NO TENER CLAVES ALTERNAS REGISTRADAS, SE UTILICE ESTE COMODIN')
      return false

    } // End If 

    m.CLA_ISU = m.CLA_COMPRA
    ////// VALIDA QUE LA CLAVE REGISTRADA EN CAMPOS XML PARA COMODIN, ESTE REGISTRADA EN EL COMEISU
    const VI_LLA1_ISU = await select('VI_LLA1_ISU')

    await requery()

    m = appendM(m, await scatter())// scatter 

    if (await recCount() < 1) {
      this.Form.MessageBox('SU CLAVE COMODIN NO SE ENCUENTRA REGISTRADA EN EL CATALOGO DE PRODUCTOS, REGISTRELA POR FAVOR')
      return false

    } // End If 

    m.FEC_XML_PVE = iif(await select("PGEXML")
      ////// verificacom si tomamos fecha del xml o la digitada,
      > 1 && len(FIELD("FEC_XML_PVE", "PGEXML")) > 3, PGEXML.FEC_XML_PVE, "S")
    await localAlaSql(' CREATE TABLE movimientos (mov_movint,cla_isu CHAR(19),dse_mov CHAR(250),can_mov NUMERIC(14,6),pve_mov NUMERIC(16,6),dto_cfd NUMERIC(16,6),fa1_imp CHAR(10),im1_mov NUMERIC(10,6),public.value.cl1_sat CHAR(3),ba1_mov NUMERIC(16,2),ii1_mov NUMERIC(16,2),fa2_imp CHAR(10),im2_mov NUMERIC(10,6),public.value.cl2_sat CHAR(3),ba2_mov NUMERIC(16,2),ii2_mov NUMERIC(16,2),fa3_imp CHAR(10),im3_mov NUMERIC(10,6),public.value.cl3_sat CHAR(3),ba3_mov NUMERIC(16,2),ii3_mov NUMERIC(16,2),fa4_imp CHAR(10),im4_mov NUMERIC(10,6),public.value.cl4_sat CHAR(3),ba4_mov NUMERIC(16,2),ii4_mov NUMERIC(16,2),fa5_imp CHAR(10),im5_mov NUMERIC(10,6),public.value.cl5_sat CHAR(3),ba5_mov NUMERIC(16,2),ii5_mov NUMERIC(16,2))')
    //// creamos cursor de movimientos para modificacion de clave

    m.FILE_XML = ''
    m.FILE_XML = GETFILE("xml", 'Archivo XML a cargar', 'Aceptar')
    //select(0)

    m.XML_SAT = ''
    m.XML_SAT = FILETOSTR(m.FILE_XML)
    // pasamos el xml a variables
    if (len(allTrim(m.XML_SAT)) < 1) {
      this.Form.MessageBox('Archivo no encontrado')
      this.Form.CARGA_XML.lostFocus
      this.Form.COD_NOM.setFocus()
      return

    } // End If 

    m.XML_CFD = m.XML_SAT
    //// le quitamos informacion que no necesitamos para trabajarlo mejor
    m.XML_SAT = strtran(m.XML_SAT, ' "', '"')
    m.XML_SAT = strtran(m.XML_SAT, ' =', '=')
    m.XML_SAT = allTrim(strtran(m.XML_SAT, '= ', '='))
    if (atc(' certificado="', m.XML_SAT, 1) > 0) {
      m.XML_SAT1 = LineSlant(m.XML_SAT, atc(' certificado="', m.XML_SAT, 1))
      m.XML_SAT2 = right(m.XML_SAT, len(m.XML_SAT) - atc(' certificado="', m.XML_SAT, 1))
      let POS_INI = atc('"', m.XML_SAT2, 2)
      m.XML_SAT = m.XML_SAT1 + 'cerfificado=""' + right(m.XML_SAT2, len(m.XML_SAT2) - POS_INI)
    } // End If 

    if (atc('<cfdi:Addenda>', m.XML_SAT, 1) > 0) {
      m.XML_SAT = LineSlant(m.XML_SAT, atc('<cfdi:Addenda>', m.XML_SAT, 1))
      m.XML_SAT = allTrim(LineSlant(m.XML_SAT, RATC('>', m.XML_SAT, 1)) + '</cfdi:Comprobante>')
    } // End If 

    let DAT_BUS = 'TimbreFiscalDigital'
    ////// obtenems prefijo para ver si es cfd o cfdi
    POS_INI = atc(DAT_BUS, m.XML_SAT, 1)
    if (POS_INI != 0) {

      let PRECFD = 'cfdi:'
    } else {

      PRECFD = ''
    } // End If 

    let LON_TOT = len(m.XML_SAT)
    m.TDO_TDO = this.Form.TDO_TDO.prop.Valueó
    m.NDO_DOC = this.Form.NDO_DOC.prop.Value
    let DAT_SAL = ''
    // identifica tipo de cfd o cfd1
    //////// verifica que no este registrado el uuid en toda la base de datos
    ////
    DAT_BUS = 'UUID'
    // obtiene folio fiscal si es un cfdi (uuid)
    DAT_SAL = OBT_CAM_XML(m.XML_SAT, PRECFD + "Complemento", DAT_BUS)
    if (len(allTrim(DAT_SAL)) > 0) {

      m.UUID = DAT_SAL
      let INS_SQL = "select uuid uuid_reg,man_comedoc.cop_nom,man_comenom.cod_nom,nom_nom,man_comedoc.tdo_tdo as tdo_doc,man_comedoc.ndo_doc as num_doc," + "man_comedoc.cod_nom as cod_doc,man_comexml.tdo_tdo as tdo_xml,man_comexml.ndo_doc as num_xml, " + " man_comedoc.sta_doc sta_doc,man_comexml.sta_doc sta_xml from man_comexml " + " left join man_comedoc on man_comedoc.tdo_tdo=man_comexml.tdo_tdo and man_comedoc.ndo_doc=man_comexml.ndo_doc " + " left join man_comenom on man_comedoc.cop_nom=man_comenom.cop_nom and man_comenom.cod_nom=man_comedoc.cod_nom " + " where uuid='" + m.UUID + "' "
      //select(0)
      // busca donde ubicar el resultado

      let A = INS_SQL
      let RES_SQL = await SQLExec(INS_SQL)
      // ejecuta instrucción SQL


      while (RES_SQL == 0 && this.Form.prop.key != 27) {
        // se repite mientras no hay resultados
        RES_SQL = await SQLExec()

        this.Form.prop.key = INKEY()
      } // End while 

      if (RES_SQL >= 0) {
        const SQLRESULT = await select('SQLRESULT')

        let SW_REGRABAR = 0
        if (await recCount() > 0 && NVL(UUID_REG, ' ') != ' ' && (NVL(tdo_doc, ' ') != ' ' && NVL(sta_doc, 'C') != 'C')) {
          this.Form.MessageBox('XML ya registrado UUID=' + UUID + 'documento: ' + TDO_XML + str(NUM_XML, 8) + ' ' + iif(COP_NOM == 'C', 'cliente: ', 'Proveedor: ') + COD_NOM + NOM_NOM)
          // si hay un error
          return

        } // End If 

        if (await recCount() > 0) {
          M.DOC_ANT = TDO_XML
          M.NUM_ANT = NUM_XML
          SW_REGRABAR = 1
        } // End If 

      } // End If ó

    } else {

      this.Form.MessageBox('XML sin timbre fiscal')
      return false

    } // End If 

    INS_SQL = ''
    //select(0)

    POS_INI = 0
    //////// validamos datos del emisior
    m.DATOXML = m.XML_SAT
    m.RFC_NOM = OBT_CAM_XML(m.DATOXML, PRECFD + "Emisor", "rfc")
    // obtiene rfc del xml
    m.NOM_XML = OBT_CAM_XML(m.DATOXML, PRECFD + "Emisor", "nombre")
    m.RFC_PVE = m.RFC_NOM
    let TIP_AFE = OBT_CAM_XML(m.XML_SAT, PRECFD + "Comprobante", "tipoDeComprobante")
    // obtiene tipo de comprobante del xml para comp.con docto.
    TIP_AFE = upper(TIP_AFE)
    if ((TIP_AFE == 'INGRESO' && COMETDO.COA_TDO != 'A') || (TIP_AFE == 'EGRESO' && COMETDO.COA_TDO != 'C')) {
      this.Form.MessageBox('Tipo de comprobante del XML diferente a tipo de afectación del documento')
      this.Form.CARGA_XML.lostFocus
      this.Form.COD_NOM.setFocus()
      return

    } // End If 

    m.DATOXML = m.XML_SAT
    // verifica que los datos del xml_receptor sean correctos
    m.RFC_CTE = OBT_CAM_XML(m.DATOXML, PRECFD + "Receptor", "rfc")
    // obtiene rfc del xml
    m.NOM_CTE = OBT_CAM_XML(m.DATOXML, PRECFD + "Receptor", "nombre")ó
    // obtiene nombre del xml
    m.RFC_PVE = m.RFC_NOM
    if (upper(allTrim(m.RFC_CTE)) != upper(allTrim(Public.value.rfc_pge))) {
      this.Form.MessageBox('Datos del receptor incorrectos en XML rfc:' + m.RFC_CTE + ' nombre: ' + m.NOM_CTE)
      this.Form.CARGA_XML.lostFocus
      this.Form.COD_NOM.setFocus()
      return

    } // End If 

    DAT_BUS = 'fecha'
    // obtiene fecha de xml
    DAT_SAL = OBT_CAM_XML(m.XML_SAT, PRECFD + "Comprobante", DAT_BUS)
    let FEC_XML = CTOT(substr(DAT_SAL, 9, 2) + '/' + substr(DAT_SAL, 6, 2) + '/' + substr(DAT_SAL, 1, 4))
    if (m.fec_xml_pve == 'S') {
      this.Form.FEC_DOC.prop.Value = FEC_XML
    } // End If 

    m.TDO_TDO = this.Form.TDO_TDO.prop.Value
    m.NDO_DOC = this.Form.NDO_DOC.prop.Value
    m.CFD_XML = FILETOSTR(m.FILE_XML)
    m.COD_DIG = this.Form.COD_NOM.prop.Value
    ////// buscamos codigo de proveedor  por su rfc
    INS_SQL = "select comenom.cod_nom,nom_nom,dir_nom,cfd_xml,comedoc.tdo_tdo as tdo_doc,comedoc.ndo_doc as num_doc," + "comedoc.cod_nom as cod_doc,comexml.tdo_tdo as tdo_xml,comexml.ndo_doc as num_xml,tte_nom as tte_pve, " + " top_nom as top_pve from comenom " + " left outer join comedoc on comedoc.tdo_tdo='" + m.TDO_TDO + "' and comedoc.ndo_doc=" + str(m.NDO_DOC, 8) + " left outer join comexml on comexml.tdo_tdo='" + m.TDO_TDO + "' and comexml.ndo_doc=" + str(m.NDO_DOC, 8) + " where comenom.cop_nom='P' and RTRIM(rfc_nom)='" + allTrim(m.RFC_NOM) + "'" + iif(m.COD_DIG != ' ', " and comenom.cod_nom='" + m.COD_DIG + "'", " ")
    //select(0)
    // busca donde ubicar el resultado

    A = INS_SQL
    RES_SQL = await SQLExec(INS_SQL, 'SQLRESULT')
    // ejecuta instrucción SQL
    ó

    while (RES_SQL == 0 && this.Form.prop.key != 27) {
      // se repite mientras no hay resultados
      RES_SQL = await SQLExec()

      this.Form.prop.key = INKEY()
    } // End while 

    if (RES_SQL < 0) {
      // si hay un error
      if (this.Form.prop.key != 27) {
        =ERR_SQL()
      } // End If 

    } // End If 

    const SQLRESULT = await select('SQLRESULT')

    let TOT_ERR = 0
    let SW_OTRO = 0
    if (await recCount() < 1 && PVE_VAR == 0) {
      this.Form.MessageBox('RFC del proveedor ' + m.RFC_NOM + ' del xml no se encuentra registrado, digite codigo de proveedor')
      return

    } // End If 

    // VFP SCAN 
    while (!eof() && SW_OTRO == 0) {
      // inicia scaneo de documentos
      m = appendM(m, await scatter())// scatter 

      //& asigna valores a variables
      if (m.COD_DIG == ' ') {
        if (this.Form.MessageBox('Razón Social de XML:' + m.NOM_XML + ' codigo localizado: ' + m.COD_NOM + ' se CARGA  a este codigo?', 4 + 256) == 6) {
          SW_OTRO = 1
        } // End If 

      } else {
        ó
        SW_OTRO = 1
      } // End If 

      skip()
    } // End while 

    if (SW_OTRO == 0) {
      this.Form.CARGA_XML.lostFocus
      this.Form.COD_NOM.setFocus()
      return

    } // End If 

    m.IMP_DOC = 0
    m.IM1_DOC = 0
    m.IM2_DOC = 0
    m.IM3_DOC = 0
    m.IM4_DOC = 0
    m.IM5_DOC = 0
    m.IM0_DOC = 0
    m.TOR_DOC = ' '
    m.NOR_DOC = 0
    this.Form.COD_NOM.prop.Value = m.COD_NOM
    this.Form.COD_NOM.REFRESH
    const VI_LLA1_NOM = await select('VI_LLA1_NOM')
    // rellenamos con ceros a la izquierda

    m.COP_NOM = 'P'
    // asignamos si es cliente o proveedoró
    const VI_LLA1_NOM = await select('VI_LLA1_NOM')

    await requery()

    if (await recCount() < 1) {
      // no existe el cliente o proveedor
      this.prop.Valid = false
      this.Form.MessageBox('No existe el código del proveedor')
      return false

    } // End If 

    this.Form.D_NOM_NOM.prop.ReadOnly = true
    m.dpe_mov = ' '
    ////// buscamos pedidos por surtir de ese cliente
    m.npe_mov = 0
    m.mpe_mov = 0
    m.can_mov = 0
    m.alm_pdo = 'NULL'
    let sw_pedsur = this.Form.MessageBox('Buscamos pedidos por surtir?', 4)
    if (sw_pedsur == 6) {
      =con_pdo_sur(m.cop_nom, m.cod_nom, m.alm_pdo, @m.dpe_mov, @m.npe_mov, @m.mpe_mov, @m.can_mov)
      m.tdo_ped = m.dpe_mov
      m.ndo_ped = m.npe_mov
      let are_tra = await select()
      // obtiene la area de trabajo actual

      //select(0)

      switch (true) {
        case Public.value.ndb_emp == 1 || Public.value.ndb_emp == 3:
          // Si es MSSQL o Sybase
          let ins_sql = upper(" exec P_con_pdo_sur '" + m.cop_nom + "','" + m.cod_nom + "',0,'" + m.alm_pdo + "'")
          break
        case Public.value.ndb_emp == 4:
          // Si es PosgreSQL
          ins_sql = upper(" SELECT  CAST(des_tdo as char(20)) as des_tdo,tdo_tdo,ndo_doc,mov_mov,cla_isu,CAST(des_isu as char(60)) as des_isu,por_ent,un1_isu,fec_mov,fme_mov,CAST(des_tda as char(40)) as des_tda,key_pri  FROM P_con_pdo_sur( '" + m.cop_nom + "','" + m.cod_nom + "',0,'" + m.alm_pdo + "')")
      } // End case 

      let a = ins_sql
      if (await SQLExec(ins_sql, 'pedidos') > 0) {
        // ejecuta instrucción SQL
        if (Public.value.ndb_emp == 2) {
          // Sqlcommit ( Public.value.num_dbs ) 

          await SQLExec("commit work;")

        } // End If 

      } // End If 

    } // End If 

    // fin pedidos por surtir

    ////////// fin de otra
    if (this.Form.COD_NOM.prop.Value != VI_LLA1_NOM.COD_NOM) {
      // si ha cambiado el codigo
      this.Form.FVE_DOC.prop.Value = this.Form.FEC_DOC.prop.Value
    } // End If 

    m.FEC_DOC = this.Form.FEC_DOC.prop.Value
    // asignamos fecha de vencimiento del documento si ha cambiado el codigo
    if ((this.Form.prop.Valid + COMETDO.COA_TDO == 'CC' || this.Form.prop.Valid + COMETDO.COA_TDO == 'PA') && this.Form.COD_NOM.prop.Value != VI_LLA1_NOM.COD_NOM) {
      this.Form.FVE_DOC.prop.Value = this.Form.FEC_DOC.prop.Value + VI_LLA1_NOM.DCR_NOM
    } // End If 

    if (VI_LLA1_NOM.MCR_NOM == 0) {
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_nom.mcr_nom=?  where recno=${Recno} `, [1])

    } // End If 

    DAT_SAL = OBT_CAM_XML(m.XML_SAT, PRECFD + "Comprobante", 'Moneda')
    this.Form.MON_DOC.prop.Value = iif(len(allTrim(DAT_SAL)) == 0, Public.value.des_mon1[1], DAT_SAL)
    m.MON_DOC = 1
    for (let IJ = 1; IJ < 5; IJ++) {
      if (allTrim(upper(Public.value.des_mon1[IJ])) == allTrim(upper(DAT_SAL))) {
        m.MON_DOC = IJ
        IJ = 5
      } // End If 

    } // End For; 

    DAT_SAL = OBT_CAM_XML(m.XML_SAT, PRECFD + "Comprobante", 'TipoCambio')
    this.Form.VMO_DOC.prop.Value = iif(len(allTrim(DAT_SAL)) > 0, val(DAT_SAL), 1)
    m.VMO_DOC = this.Form.VMO_DOC.prop.Value
    m.FVE_DOC = this.Form.FVE_DOC.prop.Value
    this.Form.D_NOM_NOM.REFRESH
    this.Form.FVE_DOC.REFRESH
    this.Form.MON_DOC.REFRESH
    const VI_LLA1_NOM = await select('VI_LLA1_NOM')

    m = appendM(m, await scatter())// scatter 


    // seguridad por sucursales
    // si no tiene sucursal el cliente o proveedor
    // si no tiene sucirsal el usuario
    // o es diferente la sucursal del cliente o proveedor
    // a la del usuario
    if (Public.value.sucursal != '   ' && Public.value.sucursal != Public.value.suc_pge && Public.value.suc_pge != '   ') {
      this.Form.MessageBox('Cliente de otra sucursal')
      return false

    } // End If 

    m.TDO_TDO = this.Form.TDO_TDO.prop.Value
    m.NDO_DOC = this.Form.NDO_DOC.prop.Value
    this.Form.FEC_DOC.REFRESH
    this.Form.FVE_DOC.REFRESH
    this.Form.REF_DOC.REFRESH
    m.XML_CONS = ''
    // carga movimientos del xml
    m.XML_CONS = OBT_CAM_XML(m.XML_SAT, PRECFD + "Conceptos")
    const VI_LLA1_TDO = await select('VI_LLA1_TDO')

    await requery()

    m = appendM(m, await scatter())// scatter 

    if (m.INV_TDO == 'E' && this.Form.ALE_DOC.prop.Value == ' ') {
      this.Form.ALE_DOC.prop.Value = 'AP'
      m.ALE_DOC = 'AP'
    } // End If 

    if (m.INV_TDO == 'S' && this.Form.ALS_DOC.prop.Value == ' ') {
      this.Form.ALS_DOC.prop.Value = 'AP'
      m.ALS_DOC = 'AP'
    } // End If 

    m.fec_mov = m.fec_doc
    m.MOV_MOV = 0
    ////DO FORM formas\obt_dat_doc WITH m.fec_mov && SOLICITAMOS FECHA PARA ALMACEN
    //select(0)

    for (let JJ = 1; JJ < 1000; JJ++) {
      POS_INI = 0
      if (atc('<cfdi:Concepto ', m.XML_CONS, JJ) > 0) {
        m.XML_CON = ''
        let POS_ICO = atc('<cfdi:Concepto ', m.XML_CONS, JJ)
        let POS_FCO = atc('</cfdi:Concepto>', m.XML_CONS, JJ)
        ////  USE  VI_LLA1_MOV NODATA
        // posicion final del concepto que se esta leyendo
        m.XML_CON = substr(M.XML_CONS, POS_ICO, POS_FCO - POS_ICO)
        POS_INI = atc('NoIdentificacion=', m.XML_CON)
        m.CLA_XML = ' '
        if (POS_INI > 0) {
          DAT_SAL = ''
          DAT_SAL = substr(m.XML_CON, POS_INI + 18, atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 19)
          m.CLA_XML = DAT_SAL
          m.CLA_ISU = m.CLA_XML
          const VI_LLA1_ISU = await select('VI_LLA1_ISU')

          await requery()

          m = appendM(m, await scatter())// scatter 

          if (await recCount() < 1) {
            m.FTI_CON = ' '
            m.CLA_TCA = m.CLA_XML
            const VI_LLA4_TCA = await select('VI_LLA4_TCA')

            await requery()

            if (await recCount() > 0) {
              m = appendM(m, await scatter())// scatter 

            } // End If 

            const VI_LLA1_ISU = await select('VI_LLA1_ISU')

            await requery()

            if (await recCount() > 0) {
              m = appendM(m, await scatter())// scatter 

            } else {

              m.CLA_ISU = m.CLA_COMPRA
              const VI_LLA1_ISU = await select('VI_LLA1_ISU')

              await requery()

              if (await recCount() < 1) {
                this.Form.MessageBox('Insumo no registrado ' + m.CLA_ISU)
                return false

              } // End If 

            } // End If 

          } // End If 

        } // End If 

        POS_INI = atc('Descripcion=', m.XML_CON)
        m.DSE_MOV = substr(m.XML_CON, (POS_INI + 13), (atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 12))
        POS_INI = atc('Cantidad=', m.XML_CON)
        m.CAN_MOV = val(substr(m.XML_CON, (POS_INI + 10), (atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 9)))
        POS_INI = atc('ValorUnitario=', m.XML_CON)
        m.PVE_MOV = val(substr(m.XML_CON, POS_INI + 15, atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 14))
        POS_INI = atc('Unidad=', m.XML_CON)
        DAT_SAL = substr(m.XML_CON, POS_INI + 8, atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 7)
        m.MED_MOV = 1
        POS_INI = atc('importe=', m.XML_CON)
        let SUM_IMP = val(substr(m.XML_CON, (POS_INI + 9), atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 8))
        let pos_ico = pos_ini + 10
        POS_INI = atc('descuento=', m.XML_CON)
        m.dto_cfd = val(substr(m.XML_CON, (POS_INI + 11), atc('"', right(m.XML_CON, len(m.XML_CON) - POS_INI + 1), 2) - 10))
        m.CLA_XML = ''
        m.MOV_MOV = JJ
        m.II1_MOV = 0
        ////// lectura de impuestos
        m.IM1_MOV = 0
        m.BA1_MOV = 0
        Public.value.cl1_sat = ' '
        m.FA1_IMP = ' '
        m.II2_MOV = 0
        m.IM2_MOV = 0
        m.BA2_MOV = 0
        Public.value.cl2_sat = ' '
        m.FA2_IMP = ' '
        m.II3_MOV = 0
        m.IM3_MOV = 0
        m.BA3_MOV = 0
        Public.value.cl3_sat = ' '
        m.FA3_IMP = ' '
        m.II4_MOV = 0
        m.IM4_MOV = 0
        m.BA4_MOV = 0
        Public.value.cl4_sat = ' '
        m.FA4_IMP = ' '
        m.II5_MOV = 0
        m.IM5_MOV = 0
        m.BA5_MOV = 0
        Public.value.cl5_sat = ' '
        m.FA5_IMP = ' '
        let DDD = atc('<cfdi:Traslados', m.XML_CON)
        let ddd = iif(ddd > 0, ddd, pos_ico)
        m.DAT_IMPTO = substr(m.XML_CON, ddd, POS_FCO - ddd)
        for (let H = 1; H < 5; H++) {
          DDD = atc('<cfdi:Traslado ', m.DAT_IMPTO, H)
          if (DDD > 0) {
            m.TIPIMPTO = 'T'
            POS_INI = atc('Importe=', m.DAT_IMPTO, H)
            m.IMPIMPTO = val(substr(m.DAT_IMPTO, (POS_INI + 9), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 8))
            POS_INI = atc('TipoFactor=', m.DAT_IMPTO, H)
            m.TIPFAC = substr(m.DAT_IMPTO, (POS_INI + 12), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 11)
            POS_INI = atc('TasaOCuota=', m.DAT_IMPTO, H)
            m.TASCUO = val(substr(m.DAT_IMPTO, (POS_INI + 12), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 11))
            POS_INI = atc('Impuesto=', m.DAT_IMPTO, H)
            m.CVEIMP = substr(m.DAT_IMPTO, (POS_INI + 10), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 9)
            POS_INI = atc('Base=', m.DAT_IMPTO, H)
            m.BASE = val(substr(m.DAT_IMPTO, (POS_INI + 6), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 5))
            switch (true) {
              case m.CVEIMP == '002':
                m.II3_MOV = m.IMPIMPTO
                m.IM3_MOV = m.TASCUO * 100
                m.BA3_MOV = m.BASE
                Public.value.cl3_sat = m.CVEIMP
                m.FA3_IMP = m.TIPFAC
                break
              case m.CVEIMP == '003':
                m.II2_MOV = m.IMPIMPTO
                m.IM2_MOV = m.TASCUO * 100
                m.BA2_MOV = m.BASE
                Public.value.cl2_sat = m.CVEIMP
                m.FA2_IMP = m.TIPFAC
            } // End case 

          } else {

            H = 5
          } // End If 

        } // End For; 

        DDD = atc('<cfdi:Retenciones', m.DAT_IMPTO)
        if (DDD > 0) {
          m.DAT_IMPTO = substr(M.DAT_IMPTO, DDD, len(M.DAT_IMPTO - DDD))
          for (H = 1; H < 5; H++) {
            DDD = atc('<cfdi:Retencion ', m.DAT_IMPTO, H)
            if (DDD > 0) {
              m.TIPIMPTO = 'R'
              POS_INI = atc('importe=', m.DAT_IMPTO, H)
              m.IMPIMPTO = val(substr(m.DAT_IMPTO, (POS_INI + 9), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 8))
              POS_INI = atc('TipoFactor=', m.DAT_IMPTO, H)
              m.TIPFAC = substr(m.DAT_IMPTO, (POS_INI + 12), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 11)
              POS_INI = atc('TasaOCuota=', m.DAT_IMPTO, H)
              m.TASCUO = val(substr(m.DAT_IMPTO, (POS_INI + 12), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 11))
              POS_INI = atc('Impuesto=', m.DAT_IMPTO, H)
              m.CVEIMP = substr(m.DAT_IMPTO, (POS_INI + 10), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 9)
              POS_INI = atc('Base=', m.DAT_IMPTO, H)
              m.BASE = val(substr(m.DAT_IMPTO, (POS_INI + 6), atc('"', right(m.DAT_IMPTO, len(m.DAT_IMPTO) - POS_INI + 1), 2) - 5))
              switch (true) {
                case m.CVEIMP == '002':
                  m.II4_MOV = m.IMPIMPTO * -1
                  m.IM4_MOV = (m.TASCUO * 100)
                    * -1
                  m.BA4_MOV = m.BASE
                  Public.value.cl4_sat = m.CVEIMP
                  m.FA4_IMP = m.TIPFAC
                  break
                case m.CVEIMP == '003':
                  m.II1_MOV = m.IMPIMPTO * -1
                  m.IM1_MOV = (m.TASCUO * 100)
                    * -1
                  m.BA1_MOV = m.BASE
                  Public.value.cl1_sat = m.CVEIMP
                  m.FA1_IMP = m.TIPFAC
                  break
                case m.CVEIMP == '001':
                  m.II5_MOV = m.IMPIMPTO * -1
                  m.IM5_MOV = (m.TASCUO * 100)
                    * -1
                  m.BA5_MOV = m.BASE
                  Public.value.cl5_sat = m.CVEIMP
                  m.FA5_IMP = m.TIPFAC
              } // End case 

            } else {

              H = 5
            } // End If 

          } // End For; 

        } // End If 

        await localAlaSql(`INSERT INTO movimientos (mov_mov,cla_isu,dse_mov,can_mov,pve_mov,dto_cfd,fa1_imp,im1_mov,public.value.cl1_sat,ba1_mov,ii1_mov,fa2_imp,im2_mov,public.value.cl2_sat,ba2_mov,ii2_mov,fa3_imp,im3_mov,public.value.cl3_sat,ba3_mov,ii3_mov,fa4_imp,im4_mov,public.value.cl4_sat,ba4_mov,ii4_mov,fa5_imp,im5_mov,public.value.cl5_sat,ba5_mov,ii5_mov) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) `, [m.MOV_MOV, m.CLA_ISU, m.DSE_MOV, m.CAN_MOV, m.PVE_MOV, m.DTO_CFD, M.FA1_IMP, m.IM1_MOV, Public.value.cl1_sat, m.BA1_MOV, m.II1_MOV, m.FA2_IMP, m.IM2_MOV, Public.value.cl2_sat, m.BA2_MOV, m.II2_MOV, m.FA3_IMP, m.IM3_MOV, Public.value.cl3_sat, m.BA3_MOV, m.II3_MOV, M.FA4_IMP, M.IM4_MOV, Public.value.cl4_sat, m.BA4_MOV, m.II4_MOV, m.FA5_IMP, m.IM5_MOV, Public.value.cl5_sat, m.BA5_MOV, m.II5_MOV]) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[m.MOV_MOV,m.CLA_ISU,m.DSE_MOV,m.CAN_MOV,m.PVE_MOV,m.DTO_CFD,M.FA1_IMP,m.IM1_MOV,Public.value.cl1_sat,m.BA1_MOV,m.II1_MOV,m.FA2_IMP,m.IM2_MOV,Public.value.cl2_sat,m.BA2_MOV,m.II2_MOV,m.FA3_IMP,m.IM3_MOV,Public.value.cl3_sat,m.BA3_MOV,m.II3_MOV,M.FA4_IMP,M.IM4_MOV,Public.value.cl4_sat,m.BA4_MOV,m.II4_MOV,m.FA5_IMP,m.IM5_MOV,Public.value.cl5_sat,m.BA5_MOV,m.II5_MOV]`)
        //////// insertamos registro en cursor

      } else {

        JJ = 1000
      } // End If 

    } // End For; 

    const MOVIMIENTOS = await select('MOVIMIENTOS')
    //////////// BROWSE PARA MODIFICAR

    if (await recCount() == 0) {
      this.Form.MessageBox('NO SE ENCONTRARON MIVIMIENTOS ')
      return

    } // End If 

    let SW_LISTO = 0
    let CN_REGS = await recCount()

    while (SW_LISTO < CN_REGS) {
      SW_LISTO = 0
      ////////////////////////////////////////////////
      //VFP  Windows Windows lista_xml From 5 , 1 To 50 , 180 Title 'MOVIMIENTOS DE XML LEIDOS' Panel Grow Zoom Close style.font "Arial" , 9 In Desktop

      //VFP  Fields Fields MOV_MOV :h = 'No. ' :p = '999' , CLA_ISU :h = 'Clave ' , DSE_MOV :h = 'Descripcion' , CAN_MOV :h = 'Cantidad' :P = '9,999,999.9999' , PVE_MOV :h = 'Precio unit.' :P = '9,999,999.9999' , DTO_CFD :h = 'Descuento' :P = '9,999,999.99' , FA1_IMP :h = 'TipoFact 1' , IM1_MOV :h = 'Tasa o cuota' :P = '999.999999' , Public.value.cl1_sat :h = 'Cve.imp.1' , BA1_MOV :h = 'Base impuesto 1' :P = '99,999,999.99' , II1_MOV :h = 'Importe imp. 1' :P = '99,999,999.99' , FA2_IMP :h = 'TipoFact 2' , IM2_MOV :h = 'Tasa o cuota' :P = '999.999999' , Public.value.cl2_sat :h = 'Cve.imp.2' , BA2_MOV :h = 'Base impuesto 2' :P = '99,999,999.99' , II2_MOV :h = 'Importe imp. 2' :P = '99,999,999.99' , FA3_IMP :h = 'TipoFact 3' , IM3_MOV :h = 'Tasa o cuota' :P = '999.999999' , Public.value.cl3_sat :h = 'Cve.imp.3' , BA3_MOV :h = 'Base impuesto 3' :P = '99,999,999.99' , II3_MOV :h = 'Importe imp. 3' :P = '99,999,999.99' , FA4_IMP :h = 'TipoFact 4' , IM4_MOV :h = 'Tasa o cuota' :P = '999.999999' , Public.value.cl4_sat :h = 'Cve.imp.4' , BA4_MOV :h = 'Base impuesto 4' :P = '99,999,999.99' , II4_MOV :h = 'Importe imp. 4' :P = '99,999,999.99' , FA5_IMP :h = 'TipoFact 5' , IM5_MOV :h = 'Tasa o cuota' :P = '999.999999' , Public.value.cl5_sat :h = 'Cve.imp.5' , BA5_MOV :h = 'Base impuesto 5' :P = '99,999,999.99' , II5_MOV :h = 'Importe imp. 5' :P = '99,999,999.99' noappend Window lista_xml

      //VFP  Windows Windows lista_xml
      //         last 
      //

      // Set Deleted On 
      ////////////////////////////////////////

      const MOVIMIENTOS = await select('MOVIMIENTOS')

      await goto('TOP')

      // VFP SCAN 
      while (!eof()) {
        m = appendM(m, await scatter())// scatter 
        const VI_LLA1_ISU = await select('VI_LLA1_ISU')
        await requery()
        if (await recCount() > 0) {
          SW_LISTO = SW_LISTO + 1
        } else {

          this.Form.MessageBox('Insumo no registrado ' + m.CLA_ISU)
        } // End If 

        skip()
      } // End while 

    } // End while 

    let sino = 6
    ////// FIN BROWE MODIFICADO
    let SINO = this.Form.MessageBox('GRABAMOS LOS REGISTROS ?', 4)
    if (SINO == 6) {
      m.ale_doc = this.Form.ale_doc.prop.Value
      ////// GRABAMOS DOCUMENTO
      m.alm_tda = m.ale_doc
      const VI_LLA1_DOC = await select('VI_LLA1_DOC')

      await requery()

      if (await recCount() < 1) {
        // GRABAMOS COMEDOC
        await localAlaSql(`INSERT INTO '+vi_lla1_doc+' FROM ?`, [m])

        if (!GRA_REG()) {

          AERROR(MEN_ERR)
          //          Error al grabar
        } // End If 

      } else {

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set cod_nom=? , fec_doc=? , ale_doc=? , ref_doc=? , sta_doc=? , tcd_tcd=?  where recno=${Recno} `, [M.COD_NOM, M.FEC_DOC, M.ALE_DOC, REF_DOC, 'P', TCD_TCD])

        if (!GRA_REG()) {

          AERROR(MEN_ERR)
          //          Error al grabar
        } // End If 

      } // End If 

      m.CFD_XML = m.XML_CFD

      // graba xml en comexml
      if (SW_REGRABAR == 0) {
        const VI_LLA1_XML = await select('VI_LLA1_XML')

        await requery()

        if (await recCount() < 1) {
          //  GRABAMOS EL XML
          await useNodata('VI_LLA1_XML') // use VI_LLA1_XML VI_LLA1_XML NODATA

          await localAlaSql(`INSERT INTO '+vi_lla1_xml+' FROM ?`, [m])

          if (!GRA_REG()) {

            AERROR(MEN_ERR)
            //          Error al grabar
          } // End If 

        } else {

          await gatherFrom(m)

          if (!GRA_REG()) {

            // graba el registro
            AERROR(MEN_ERR)
            //          Error al grabar
          } // End If 

        } // End If 

      } else {

        M.DOC_ACT = M.TDO_TDO
        M.NUM_ACT = M.NDO_DOC
        M.TDO_TDO = M.DOC_ANT
        M.NDO_DOC = M.NUM_ANT
        const VI_LLA1_XML = await select('VI_LLA1_XML')

        await requery()

        if (await recCount() > 0) {
          //  GRABAMOS EL XML
          // Inicio replace VFP
          Recno = await recNo()ó
          Alias = await alias()
          await localAlaSql(`update ${Alias} set cfd_xml=? , tdo_tdo=? , ndo_doc=?  where recno=${Recno} `, [m.CFD_XML, m.doc_act, m.num_act])

          if (!GRA_REG()) {

            // graba el registro
            AERROR(MEN_ERR)
            //          Error al grabar
          } // End If 

        } // End If 

        M.TDO_TDO = M.DOC_act
        M.NDO_DOC = M.NUM_act
      } // End If 

      m.PED_PED = this.Form.PED_PED.prop.Value
      //////// graba DETALLE DEL DOCUMENTO
      const MOVIMIENTOS = await select('MOVIMIENTOS')

      await goto('TOP')

      // VFP SCAN 
      while (!eof()) {
        m = appendM(m, await scatter())// scatter 
        if (sw_pedsur == 6) {
          const PEDIDOS = await select('PEDIDOS')

          await goto('TOP')

          m.mpe_mov = 0
          // VFP LOCATE FOR upper(CLA_ISU)=upper(allTrim(M.CLA_ISU)) && allTrim(TDO_TDO)=allTrim(M.TDO_PED) && NDO_DOC=M.NDO_PED
          result = await locateFor(` upper(CLA_ISU)=upper(allTrim(M.CLA_ISU)) && allTrim(TDO_TDO)=allTrim(M.TDO_PED) && NDO_DOC=M.NDO_PED`)

          m.mpe_mov = NVL(mov_mov, 0)
          m.dpe_mov = iif(m.mpe_mov == 0, ' ', m.tdo_ped)
          m.npe_mov = iif(m.mpe_mov == 0, 0, m.ndo_ped)
        } // End If 
        await localAlaSql(`INSERT INTO '+vi_lla1_mov+' FROM ?`, [m])
        const VI_LLA1_MOV = await select('VI_LLA1_MOV')
        if (!GRA_REG()) {

          AERROR(MEN_ERR)
          //          Error al grabar
        } // End If 

        skip()
      } // End while 

    } else {

      this.Form.MessageBox('NO SE EFECTUO LA GENERACION DEL DOCUMENTO')
    } // End If 

    this.Form.CARGA_XML.prop.Disabled = true
    this.Form.CARGA_XML.lostFocus
    const VI_LLA1_DOC = await select('VI_LLA1_DOC')

    await requery()

    this.Form.D_TOT_DOC.prop.Value = IMP_DOC + IM0_DOC + IM1_DOC + IM2_DOC + IM3_DOC + IM4_DOC + IM5_DOC
    this.Form.CAPTURA_MOVI.setFocus()
    return

  }   // Fin Procedure


  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.ale_doc.prop.Value <= ' ') {
      this.Form.MessageBox('Favor de elegir almacen de entrada')
      return false

    } // End If 

    if ((cometdo.inv_tdo == 'E' && cometdo.afi_tdo == 1 && cometdo.cop_nom != 'C') && len(allTrim(this.Form.ped_ped.prop.Value)) < 10) {
      this.Form.MessageBox('Como es un documento de importación, debe digitar el numero del pedimento aduanal')
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}