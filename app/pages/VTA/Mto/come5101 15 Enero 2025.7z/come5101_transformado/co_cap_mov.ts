//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : container
// Class : co_cap_mov
// Description : Componente co_cap_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { CONTAINER } from "@/classes/container";

import { CONTAINER } from "@/classes/container";
//imports

export class co_cap_mov extends CONTAINER {
//public
 	constructor() {
     super();
     this.prop.BaseClass = "container";
     

    this.style.backgroundColor='234,234,234';
    this.style.height='135px';
//LineSlant=3;
    this.prop.Name="co_cap_mov";
    this.SpecialEffect=1;
    this.prop.TabIndex=56;
    this.style.top='266px';
    this.style.width='1014px';
    this.style.zIndex='80';

     //propiedades
     }
     //metodo
}