//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_cpo_nom
// Description : Componente d_cpo_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
//imports

export class d_cpo_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_nom.cpo_nom";
    this.prop.Caption = "Codigo postal";

    this.prop.ReadOnly = true;
    this.prop.TabIndex = 16;
    this.prop.ToolTipText = "Codigo postal";
    this.style.width = '69px';

  }

  // Evento   :when
  // Objeto  :d_cop_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}