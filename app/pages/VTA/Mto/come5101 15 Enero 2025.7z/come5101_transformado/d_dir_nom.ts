//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_dir_nom
// Description : Componente d_dir_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_dir_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = 'Dirección'
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_lla1_nom.dir_nom";
    this.style.height = '22px';
    //LineSlant=64;
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Dirección";

    //propiedades
  }
  override async salir() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.MaxLength = len(this.prop.Value)
  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :dir_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :when
  // Objeto  :d_dir_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}