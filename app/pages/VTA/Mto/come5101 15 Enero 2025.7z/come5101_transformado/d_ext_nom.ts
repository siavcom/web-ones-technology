//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_ext_nom
// Description : Componente d_ext_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";



export class d_ext_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'text';
    this.prop.Caption = "Número exterior";

    this.prop.ControlSource = "vi_lla1_nom.ext_nom";
    //LineSlant=433;
    this.prop.Name = "d_ext_nom";
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Número exterior";
    this.prop.Visible = false;

    //propiedades
  }


  // evento   :when
  // objeto  :d_ext_nom
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}