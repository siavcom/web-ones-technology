//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_im1_doc
// Description : Componente d_im1_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_im1_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_lla1_doc.im1_doc";
    this.style.fontSize = '17px';
    this.prop.ReadOnly = true;
    this.style.width = '107px';

    //propiedades
  }
  override async init() {
    this.prop.Caption = Public.value.di1_pge
    this.prop.InputMask = ('999,999,999.' + replicateString('9', Public.value.dcp_pge + 1));
    this.prop.Decimals = Public.value.dcp_pge;
    if (this.prop.Caption.allTrim().length == 0) {
      this.prop.Visible = false
    } // End If 

  }   // Fin Procedure




  //metodo
}