//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_im4_doc
// Description : Componente d_im4_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class d_im4_doc extends COMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_lla1_doc.im4_doc";
    this.style.fontSize = '17px';
    this.prop.ReadOnly = true;
    this.style.width = '107px';


    //propiedades
  }
  override async init() {
    this.prop.Caption = Public.value.di4_pge
    this.prop.Decimals = Public.value.dcp_pge;
    if (this.prop.Caption.allTrim().length == 0) {
      this.prop.Visible = false
    } // End If 

  }   // Fin Procedure




  //metodo
}