//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_int_nom
// Description : Componente d_int_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_int_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Interior";

    this.style.backgroundColor = '255,255,255';
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Interior";
    this.prop.Visible = false;
    this.style.width = '194px';

  }
  // Evento   :when
  // Objeto  :d_int_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false
    } // End If 

    return true
  }   // Fin Procedure

  //metodo
}