//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_nom_nom
// Description : Componente d_nom_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class d_nom_nom extends COMPONENT {
//public
 	constructor() {
     super();
     this.prop.BaseClass = "Component";
     
this.prop.Type='text';
    this.style.backgroundColor='255,255,255';
    this.Comment="";
    this.prop.ControlSource="vi_lla1_nom.nom_nom";
    this.DisabledBackColor=234,234,234;
    this.DisabledForeColor=128,128,128;
    this.style.fontSize='8px';
    this.prop.Format="K";
    this.style.height='22px';
//LineSlant=171;
    this.prop.Name="d_nom_nom";
    this.prop.ReadOnly=true;
    this.prop.TabIndex=6;
    this.style.top='78px';
    this.style.width='650px';
    this.style.zIndex='5';

     //propiedades
     }
       override async salir(){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.MaxLength=len(this.prop.Value)
  }   // Fin Procedure
  // evento   :keypress  // objeto  :busqueda  // tipo   :texbox  // comentarios :
override async keyPress(nkeycode,nshiftaltctrl){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key=nkeycode
    let nkeycode=0
    if ( nkeycode==27){  // si da un "esc" se va al procedimiento de salida
      return 

    } // End If 

    m.cla_isu=0
    if ( this.Form.prop.key>0 && char(this.Form.prop.key)=='?' && cometdo.cop_nom=='C'){  // consulta de nombres
      //VFP  "" "" clear

      const router = useRouter();      router.push({name: 'formas\con_mos' })// tom.key_mos

      if ( m.key_mos>0){
        let ins_sql="select * from man_comemos  where key_pri="+str(m.key_mos)
        =iif(await SQLExec( ins_sql)>0,true,err_sql())
        m.rfi_mos=''
        if ( await recCount()>0){  // si hay datos de mostrador
          m=appendM(m, await scatter())// scatter 

          this.Form.d_dir_nom.prop.Value=m.dir_mos  //    thisform.d_nom_nom.value=m.nom_mos
          if ( this.Form.fac_ele){
            this.Form.d_ext_nom.prop.Value=m.ext_mos
            this.Form.d_int_nom.prop.Value=m.int_mos
          } // End If 

          this.Form.d_col_nom.prop.Value=m.col_mos
          this.Form.d_pob_nom.prop.Value=m.pob_mos
          this.Form.d_edo_edo.prop.Value=m.edo_edo
          this.Form.d_pai_nom.prop.Value=m.pai_mos
          this.Form.d_cpo_nom.prop.Value=m.cpo_mos
          this.Form.d_te1_nom.prop.Value=m.te1_mos
          this.Form.d_rfc_nom.prop.Value=m.rfc_mos
          if ( this.Form.sw_rfi){
            this.Form.d_rfi_nom.prop.Value=m.rfi_mos
          } // End If 

          //VFP  chr chr ( 127 ) + m.nom_mos

        } // End If 

      } // End If 

    } // End If 

    return 

  }   // Fin Procedure
  // Evento   :Valid  // Objeto  :ref_doc  // Tipo   :Cuadro de texto  // Comentarios :
override async valid(sw_rel){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    return true

  }   // Fin Procedure
  // Evento   :when  // Objeto  :nom_nom  // Tipo   :Cuadro de texto  // Comentarios :
override async when(){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if ( this.prop.ReadOnly==true){
      return false

    } // End If 

    return true

  }   // Fin Procedure
//metodo
}