//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_pai_nom
// Description : Componente d_pai_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";
export class d_pai_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ReadOnly = true;
    this.prop.TabIndex = 17;
    this.prop.ToolTipText = "Paí­s";
    //propiedades
  }

  //metodo
}