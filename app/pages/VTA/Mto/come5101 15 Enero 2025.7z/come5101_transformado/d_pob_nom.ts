//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_pob_nom
// Description : Componente d_pob_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class d_pob_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Población";

    this.prop.ControlSource = "vi_lla1_nom.pob_nom";
    //LineSlant=64;
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Población";
    this.style.width = '175px';

    //propiedades
  }

  // Evento   :when
  // Objeto  :d_pob_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}