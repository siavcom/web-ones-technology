//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : coboboxsat
// Class : d_rfi_nom
// Description : Componente d_rfi_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COBOBOXSAT } from "@/classes/coboboxsat";

import { COBOBOXSAT } from "@/classes/Siavcom/coboboxsat";
//imports

export class d_rfi_nom extends COBOBOXSAT {
  //public
  constructor() {
    super();

    this.prop.Captiob = "Regimen fiscal del SAT";
    this.prop.BoundColumn = 1;
    this.prop.ColumnCount = 2;

    this.prop.ColumnWidths = "25,550";
    this.prop.ControlSource = "vi_lla1_nom.rfi_nom";
    this.prop.RowSource = "rfi_nom.cla_sat,des_sat";
    this.prop.ToolTipText = "Regimen fiscal del SAT";
    this.style.width = '169px';

    //propiedades
  }

  // Evento   :When
  // Objeto  :fpa_sat
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    this.prop.Valid = true
    const cometdo = currentValue('*', 'cometdo')
    if (cometdo.tip_cfd == 'NA' || !this.prop.Visible) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}