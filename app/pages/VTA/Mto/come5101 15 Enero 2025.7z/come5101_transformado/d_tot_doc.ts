//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_tot_doc
// Description : Componente d_tot_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class d_tot_doc extends COMPONENT {
    //public
    calculo = computed(async () => {
        const data = await currentValue('*', 'vi_lla1_doc')
        return data?.imp_doc + data?.im0_doc + data?.im1_doc + data?.im2_doc + data?.im3_doc + data?.im4_doc + data?.im5_doc
    })

    constructor() {
        super();
        this.prop.Type = 'number';
        this.prop.Caption = 'Total'
        this.prop.Disabled = false;
        this.style.fontWeight = 'bold';
        this.style.fontFamily = '"Arial"';
        this.style.fontSize = '17px';
        this.prop.ReadOnly = true;
        this.style.width = '219px';
        this.prop.Value = ref(this.calculo)
    }

    override async init() {
        this.prop.InputMask = ('999,999,999.' + replicateString('9', Public.value.dcp_pge + 1));
        this.prop.Decimals = Public.value.dcp_pge;

        this.prop.Caption = Public.value.di0_pge
        if (this.prop.Caption.allTrim().length == 0) {
            this.prop.Visible = false
        } // End If 

    }   // Fin Procedure

    //metodo
}