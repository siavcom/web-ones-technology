//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : fec_doc
// Description : Componente fec_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { currentValue } from "~/composables/0_SqlDb";


export class fec_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'date';
    this.prop.Caption = 'Fecha';
    this.prop.ControlSource = "vi_lla1_doc.fec_doc";
    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "Fecha contable o expedicion";
    this.prop.Value = ('   ');
    this.style.width = '71px';

    //propiedades
  }

  // Evento   :lostFocus
  // Objeto  :fec_doc
  // Tipo   :ComboBox
  // Comentarios : muestra el detalle si es el ultimo campo activo
  // si son autorizaciones extraordinarias
  async lostFocus() {
    if (this.Form.prop.Valid == 'AE' && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when
    } // End If 

    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when
    } // End If 

  }   // Fin Procedure

  // Evento   :Valid
  // Objeto  :fec_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Es la validación de la fecha de expedición del documento
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    const cometdo = await currentValue('*', 'cometdo')
    if (this.Form.sw_nue || (!this.Form.sw_nue && vi_lla1_doc.fec_doc != this.prop.Value)) {

      // calculamos fecha de vencimiento
      if (this.Form.prop.Valid != 'IN' && this.Form.prop.Valid != 'PG' && this.Form.prop.Valid != 'AE') {
        // si no pertenece a un documento de inventario
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.fve_doc=?  where recno=${Recno} `, [vi_lla1_doc.fec_doc])
        // si es un cliente y un cargo o proveedor y abono
        if (cometdo.cop_nom + cometdo.coa_tdo == 'CC' || cometdo.cop_nom + cometdo.coa_tdo == 'PA' || cometdo.cop_nom + cometdo.inv_tdo == 'CP' || cometdo.cop_nom + cometdo.inv_tdo == 'PP') {
          this.Form.fve_doc.prop.Value = this.Form.fec_doc.prop.Value + vi_lla1_nom.dcr_nom
          // calcula la nueva fecha de vencimiento
          if (cometdo.cop_nom + cometdo.coa_tdo == 'CC') {
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_lla1_doc.fip_doc=?  where recno=${Recno} `, [vi_lla1_doc.fve_doc])

          } // End If 

        } // End If 

        this.Form.fve_doc.refresh
      } // End If 

    } // End If 


    // si la fecha es menor al ultimo perido cerrado
    if (this.prop.Value < Public.value.uac_pge) {
      MessageBox('Fecha menor al ultimo cierre')
      return false

    } else {

      this.Form.sw_cie_per = false
    } // End If 

    if (this.prop.Value > cast(Public.value.fpo_pge, 'DATE') + 30) {
      MessageBox('No permite documentos mayores a 30 dias despues de la fecha de proceso ' + cast(Public.value.fpo_pge, 'CHAR'(10)))
      this.prop.Valid = false
      return false

    } // End If 

    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :fec_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    }
    this.prop.Valid = true
    return false


  }   // Fin Procedure


  //metodo
}