//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : fve_doc
// Description : Componente fve_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class fve_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'date';
    this.prop.Caption = 'Fecha de vencimiento';
    this.prop.ControlSource = "vi_lla1_doc.fve_doc";
    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "fecha de vencimiento";
    this.style.width = '71px';

    //propiedades
  }
  async prop.ErrorMessage() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.MessageBox('Fecha menor a fecha de vencimiento')
  }   // Fin Procedure

  // Evento   :lostFocus
  // Objeto  :fve_doc
  // Tipo   :TextBox
  // Comentarios :
  async lostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await select('vi_lla1_doc')óó


    //if (.not. cometdo.inv_tdo$'SEP' Or (thisform.ale_doc.enabled=.f. and thisform.als_doc.enabled=.f.)) .and. (key=9 .or. key=13 .or. key=24)  && si continua la captura ejecuta detalle
    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when()
    } // End If 

  }   // Fin Procedure
  //SELECT vi_cap_comemov


  // Evento   :When
  // Objeto  :fve_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Cuando se permi la captura de la fecha de vencimiento
  override async when() {
    if (this.prop.ReadOnly) {
      return false

    } // End If 

    this.prop.Valid = true
    return await this.Form.rev_per(this.prop.Name)
    // manda revizar permisos

  }   // Fin Procedure


  //metodo
}