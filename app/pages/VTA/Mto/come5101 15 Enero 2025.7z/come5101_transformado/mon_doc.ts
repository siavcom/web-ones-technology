//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : mon_doc
// Description : Componente mon_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";



export class mon_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";
    this.prop.Caption = "Moneda";
    this.prop.ColumnCount = 1;
    this.prop.ControlSource = "vi_lla1_doc.mon_doc";
    this.prop.Disabled = false;
    this.prop.RowSource = "des_mon1";
    this.prop.RowSourceType = 5;
    this.prop.Style = 2;
    this.prop.TabIndex = 24;
    this.prop.ToolTipText = "Moneda";
    this.style.width = '50px';

    //propiedades
  }

  // Evento   :Valid
  // Objeto  :mon_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Es la validación de la moneda del documento
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    // si cambio de moneda o es un documento nuevo

    if (this.Form.sw_nue || this.prop.Value != await oldValue('mon_doc', 'vi_lla1_doc')) {

      // asignamos el valor segun tabla de parametros generales
      //replace mon_doc with this.value
      // asignamos el valor de la moneda
      if (vi_lla1_doc.mon_doc == 0) {
        return false

      } // End If 

      this.Form.vmo_doc.prop.Value = Public.value.val_mon1[vi_lla1_doc.mon_doc]
    } // End If 

    this.Form.vmo_doc.refresh
    if (this.prop.Value == 1) {
      // si la moneda es la principal
      this.Form.vmo_doc.prop.Value = 1
      // le asignamos un valor de 1
    } // End If 

    this.prop.Valid = true
    return true

  }   // Fin Procedure

  // Evento   :When
  // Objeto  :mon_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {

    if (this.Form.sw_mov) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    }
    this.prop.Valid = true
    return false



  }   // Fin Procedure


  //metodo
}