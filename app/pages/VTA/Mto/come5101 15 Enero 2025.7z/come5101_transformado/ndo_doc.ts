//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : ndo_doc
// Description : Componente ndo_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

//imports

export class ndo_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'number';
    this.prop.Format = "K";
    this.style.height = '31px';
    this.prop.InputMask = "999,999,999";
    this.prop.Name = "ndo_doc";
    this.prop.Value = (+0);
    this.prop.DecimalPlaces = 0;
    this.style.fontSize = '17px';
    this.style.width = '140px';
    //propiedades
  }

  // evento   :gotfocus
  // objeto  :ndo_doc
  // tipo   :cuadro de texto
  // comentarios :compone la la llave principal
  override async when() {
    if (this.Form.prop.key == 15) {
      this.prop.ReadOnly = false
    } // End If 

    if (this.prop.ReadOnly == false) {
      // busca el consecutivo del documento
      this.prop.Value = await get_con_doc(this.Form.tdo_tdo.prop.Value)
      // obtenemos el consecutivo del docto
      await select('vi_lla1_nom')


      await deleteLocalSql()

      const vi_lla1_con = await select('vi_lla1_con')

      await useNodata('vi_lla1_con') // use vi_lla1_con vi_lla1_con Nodata

      const vi_lla1_ven = await select('vi_lla1_ven')

      await useNodata('vi_lla1_ven') // use vi_lla1_ven vi_lla1_ven Nodata

      const vi_lla1_doc = await select('vi_lla1_doc')
      // use vi_lla1_nom nodata
      // inicializamos datos

      await useNodata('vi_lla1_doc') // use vi_lla1_doc vi_lla1_doc Nodata

      this.Form.sw_cie_per = false
      this.Form.otro.prop.Disabled = false
      this.Form.cancela_docto.prop.Disabled = true
      this.Form.borra_movto.prop.Disabled = true
      this.Form.paridades.prop.Disabled = true
      // thisform.observaciones.enabled=.f.
      this.Form.dre_doc.prop.Disabled = true
      this.Form.imprime.prop.Disabled = true
      // Thisform.impuestos.Enabled=.F.
      this.Form.carta_porte.prop.Disabled = true
      this.Form.salir.prop.Disabled = false
      this.Form.D_sta_doc.prop.Value = ' '
      this.prop.Valid = false
      this.prop.ReadOnly = false
      this.prop.Valid = false
      this.Form.dpe_mov = '  '
      // If Thisform.Tag#'IN' And Thisform.Tag#'PG' And Thisform.Tag#'AE'     && si la captura es differente a inventario
      //  Thisform.datos_cliente.click(.T.) && activa datos de cliente o proveedor
      // Endif
      // inicializamos el ultimo pedido surtido
      this.Form.npe_mov = 0
      this.Form.mpe_mov = 0
      const cometda_ent = await select('cometda_ent')
      // habilitamos almacenes segun el tipo de documento
      // seleccionamos almacenesó

      await goto('TOP')

      const cometda_sal = await select('cometda_sal')
      // seleccionamos almacenes

      await goto('TOP')

      if (this.Form.sw_xml) {
        this.Form.captura_xml.prop.RecordSource = ''
      } // End If 

      this.Form.D_sta_doc.DisabledBackColor = Rgb(240, 240, 240)
    } // End If 

    return true
    //!// thisform.captura_movi.pri_col=1  && incializamos cual es la primer columna
    //!// IF cometdo.coa_tdo<>'N' AND cometdo.cop_nom<>'N'  AND cometdo.inv_tdo<>'N'  && si afecta a clientes o proveedores pero no es cargo o abono y no afecta inventario
    //!//    thisform.captura_movi.pri_col=4
    //!// endif

  }   // Fin Procedure



  // evento   :valid
  // objeto  :ndo_doc
  // tipo   :cuadro de texto
  // comentarios :es la validación de la llave principal
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Aliasó
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.sw_aut = falseó
    // apagamos switch de autorizado
    if (this.Form.prop.key == 27 || this.Form.prop.key == 15 || this.Form.prop.key == 0) {
      this.prop.Value = 0
      this.prop.Valid = false
      return true

    } // End If 

    if (this.prop.Value <= 0) {
      // checa si el dato es valido
      this.prop.Value = 0
      this.prop.Valid = false
      return false

    } // End If 

    this.Form.sw_mov = false
    // switch de movimientos
    const vi_lla1_doc = await select('vi_lla1_doc')
    // seleccionamos vista de documentos

    m = appendM(m, await scatterBlank())// scatter 
    // ponemos en blanco todos los campos

    m.tdo_tdo = this.Form.tdo_tdo.prop.Value
    // asignamos el tipo de documento
    m.ndo_doc = this.prop.Value
    await use('vi_lla1_doc', m) // use vi_lla1_doc vi_lla1_doc
    // abre la vista

    let swc = false
    // apagamos switch de docuemnto cancelado
    if (vi_lla1_doc.nde_doc > 0) {
      if (vi_lla1_doc.sta_doc == 'C') {
        this.Form.MessageBox('El documento se convirtió al documento :' + vi_lla1_doc.tde_doc + str(vi_lla1_doc.nde_doc), 16, 'Advertencia', 5000)
      } else {

        this.Form.MessageBox('El documento generó el documento :' + vi_lla1_doc.tde_doc + str(vi_lla1_doc.nde_doc), 16, 'Advertencia', 5000)
        if (at(rTrim(vi_lla1_doc.tde_doc), this.Form.doc_blo) > 0) {
          // busca en documentos a bloquear
          let ins_sql = "select key_pri as key_pri from man_comedoc where tdo_tdo='" + rTrim(vi_lla1_doc.tde_doc) + "' and ndo_doc=" + str(vi_lla1_doc.nde_doc)
          =iif(await SQLExec(ins_sql) > 0, 0, err_sql())
          if (await select('sqlresult')
            > 0 && sqlresult.key_pri > 0) {
            this.Form.MessageBox('No es permitido modificar este documento', 16, 'Advertencia', 5000)
            return falseó

          } // End If 

        } // End If 

      } // End If 

    } // End If ó

    if (vi_lla1_doc.sta_doc == 'C') {
      // reviza si el documento esta cancelado
      swc = true
      if (Public.value.log_usu != ('ADMIN     ')) {
        this.Form.MessageBox('El documento esta cancelado')
        this.prop.Value = get_con_doc(this.Form.tdo_tdo.prop.Value)
        // obtenemos el consecutivo del docto
        return false

      } else {

        // si es el administrador del sistema
        if (this.Form.MessageBox("El documento esta cancelado, deseas activarlo", 4 + 32) != 6) {
          this.prop.Value = get_con_doc(this.Form.tdo_tdo.prop.Value)
          return false

        } // End If 

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set sta_doc=?  where recno=${Recno} `, ['P'])

      } // End If 

    } // End If 

    if (vi_lla1_doc.sta_doc == 'X') {
      // Documento con error al timbrar
      this.Form.MessageBox('El documento quedo en proceso de timbrado ')
    } // End If 
    // This.Value=get_con_doc(Thisform.tdo_tdo.Value) && obtenemos el consecutivo del docto
    // Return .F.

    if (vi_lla1_doc.sta_doc == 'N') {
      // Documento con error al timbrar
      this.Form.MessageBox('El documento quedo en proceso de timbrado o cancelación ante el SAT')
      this.prop.Value = get_con_doc(this.Form.tdo_tdo.prop.Value)
      // obtenemos el consecutivo del docto
      return false

    } // End If 


    // si es un documento nuevo o esta cancelado
    if (await recCount() == 0 || swc) {
      //.or. (vi_lla1_doc.imp_doc=0 and vi_lla1_doc.im1_doc=0 and vi_lla1_doc.im2_doc=0 and vi_lla1_doc.im3_doc=0)
      this.Form.tdo_tdo.prop.Valid = true
      // prendemos validación de tipo de documento
      this.Form.ndo_doc.prop.Valid = true
      // y número
      if (await recCount() == 0) {
        const vi_lla1_doc = await select('vi_lla1_doc')

        await appendBlank()

        this.Form.sw_nue = true
        // predemos switch de registro nuevo
      } else {

        this.Form.sw_nue = false
        // apagamos switch de registro nuevo
      } // End If 


      // OBTENEMOS CP DE DODE SE EMITE EL DOCUMENTO
      if (cometdo.unn_unn > '   ') {
        // hay unidad de negocios
        m.unn_unn = cometdo.unn_unn
        const vi_lla1_unn = await select('vi_lla1_unn')

        await requery()

        let cod_pos = cpo_unn
        // tomamos el codigo postal de la unidad de negocios
      } else {

        cod_pos = Public.value.cpo_pge
        // tomamos el codigo postal de parametros generales
      } // End If 

      const pgexml = await select('pgexml')

      Public.value.aju_hor = '+ 0'
      // aqui me quede
      if (await recCount() > 0) {
        try {
          let ins_fox = 'aju=aj_' + cod_pos

            & ins_fox

          Public.value.aju_hor = aju

        }
        catch (error) {

        } // End Try

      } // End If 
      ó
      switch (true) {
        case Public.value.ndb_emp == 1 || Public.value.ndb_emp == 3:
          // si es mssql o Sybase getdate()
          ins_sql = 'select DATEADD(HOUR,' + Public.value.aju_hor + ', getdate()) as fec_act'
          break
        //  =Iif(SQLExec(num_dbs,'select getdate() as fec_act ')>0,0,err_sql())  && obtiene fecha del servidor
        case Public.value.ndb_emp == 2:
  // si es interbase
                =iif(await SQLExec('select fec_act from p_get_fec') > 0, 0, err_sql())
          // obtiene fecha del servidor
          break
        case Public.value.ndb_emp == 4:
          // si es PostgreSQL
          ins_sql = "SELECT  current_timestamp::TIMESTAMP +'" + Public.value.aju_hor + " hr'::INTERVAL AS fec_act"
      } // End case 
  //  =Iif(SQLExec(num_dbs,'SELECT current_timestamp as fec_act ')>0,0,err_sql())  && obtiene fecha del servidor

      =iif(await SQLExec(ins_sql) > 0, 0, err_sql())
      // obtiene fecha del servidor
      m = appendM(m, await scatter())// scatter 

        = iif(await SQLExec('select fpo_pge from man_comepge ') > 0, 0, err_sql())
      // obtiene fecha del servidor
      m = appendM(m, await scatter())// scatter 

      const vi_lla1_doc = await select('vi_lla1_doc')
      // m.fec_act es la fecha regresada del servidor
      // generamos la fecha del documento

      // Inicio replace VFP
      // Replace fec_doc With Ttod(m.fec_act),fel_doc With m.fec_act,fve_doc With Ttod(m.fec_act)
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set fec_doc=? , fel_doc=? , fve_doc=?  where recno=${Recno} `, [Ttod(Public.value.fpo_pge), m.fec_act, Ttod(Public.value.fpo_pge)])

      let hora = right(Ttoc(m.fec_act), 11)
      let sw_pm = iif(right(hora, 2) == 'PM', true, false)
      hora = LineSlant(hora, 8)
      if (sw_pm) {
        hora = str(val(LineSlant(hora, 2)) + 12, 2) + right(hora, 6)
        if (LineSlant(hora, 2) == '24') {
          hora = '12' + right(hora, 6)
        } // End If 

      } else {

        if (LineSlant(hora, 2) == '12') {
          hora = '00' + right(hora, 6)
        } // End If 

      } // End If 

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set hrs_doc=?  where recno=${Recno} `, [hora])


      // Endif
      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // Sqlcommit ( Public.value.num_dbs ) 

        await SQLExec("commit work;")

      } // End If 

      for (const Control of this.Form.Controls) {
        // permitimos captura de todos los datos

        if (substr(Control.prop.Name, 4, 1) == '_' && Control.prop.Name != this.prop.Name && Control.prop.Name != 'tdo_tdo') {
          Control.prop.Valid = iif(Control.prop.Name == 'tcd_tcd', '1', '0')
          // apagamos la validación del los objetos
          if ((Control.prop.BaseClass == 'Textbox' || Control.prop.BaseClass == 'Editbox')) {
            Control.prop.ReadOnly = false
            // permitimos captura de los datos
            Control.prop.Disabled = false
            // permitimos captura de los datos
          } else {

            Control.prop.Disabled = false
            // permitimos captura de los datos
          } // End If 

          if (Control.prop.Name != 'tcd_tcd') {
            Control.Refresh
          } else {

            if (await recCount('vi_cap_cometcd') > 0) {
              Control.Refresh
              this.Form.tcd_tcd.prop.Value = vi_cap_cometcd.tcd_tcd
            } // End If 
            //                  ELSE
            //                     thisform.tcd_tcd.Value='  '

          } // End If 

        } // End If 

      } // End For; 

      this.Form.captura_movi.prop.RecordSource = 'vi_cap_comemov'
      //   thisform.captura_movi.enabled=.f.    && deshabilitamos captura de movimientos
      this.Form.otro.prop.Disabled = false
      this.Form.cancela_docto.prop.Disabled = true
      this.Form.borra_movto.prop.Disabled = true
      this.Form.paridades.prop.Disabled = true
      // thisform.observaciones.enabled=.f.
      this.Form.dre_doc.prop.Disabled = true
      this.Form.imprime.prop.Disabled = true
      // Thisform.impuestos.Enabled=.F.
      this.Form.carta_porte.prop.Disabled = true
      this.Form.salir.prop.Disabled = false
      this.Form.als_doc.prop.RowSource = ''
      // asignacion de almacenes
      // m.tdo_tdo=thisform.tdo_tdo.Value
      this.Form.als_doc.prop.RowSourceType = 0
      this.Form.ale_doc.prop.RowSource = ''
      this.Form.ale_doc.prop.RowSourceType = 0
      ins_sql = 'select man_cometda.* from vi_cap_comedal join man_cometda on man_cometda.alm_tda=vi_cap_comedal.alm_tda where vi_cap_comedal.tdo_tdo=?m.tdo_tdo and vi_cap_comedal.ale_dal=0'
      //////////////////////////////// Almacenes de entrada
      //select(0)

      if (await SQLExec(ins_sql, 'sqlresult') > 0) {

        //!//   If Select('cometda_sal')>0
        //!//    Select cometda_sal
        //!//    Use
        //!//   Endif
        //!//   If Select('cometda_ent')>0
        //!//    Select cometda_ent
        //!//    Use
        //!//   Endif
        if (await recCount() > 0) {
          Result = await localAlaSql(`INSERT INTO cometda_ent select * From sqlresult Order By des_tda NOFILTER`)

        } else {

          Result = await localAlaSql(`INSERT INTO cometda_ent select * From vi_cap_cometda Order By des_tda NOFILTER`)

        } // End If 

      } // End If 

      const cometda_ent = await select('cometda_ent')

      await goto('TOP')

      this.Form.ale_doc.prop.RowSource = 'cometda_ent.des_tda,alm_tda'
      this.Form.ale_doc.prop.RowSourceType = 2
      this.Form.ale_doc.Refresh
      // VFP LOCATE For cometda_ent.alm_tda=Public.value.usu_alm
      result = await locateFor(` cometda_ent.alm_tda=Public.value.usu_alm`)

      if (!found()) {
        await goto('TOP')

        Public.value.usu_alm = cometda_ent.alm_tda
      } // End If 

      ins_sql = 'select man_cometda.* from vi_cap_comedal join man_cometda on man_cometda.alm_tda=vi_cap_comedal.alm_tda where vi_cap_comedal.tdo_tdo=?m.tdo_tdo and vi_cap_comedal.als_dal=0'
      //////////////////////////////// Almacenes de salida
      //select(0)

      if (await SQLExec(ins_sql, 'sqlresult') > 0) {
        if (await recCount() > 0) {
          Result = await localAlaSql(`INSERT INTO cometda_sal select * From sqlresult Order By des_tda NOFILTER`)

        } else {

          Result = await localAlaSql(`INSERT INTO cometda_sal select óFrom vi_cap_cometda Order By des_tda NOFILTER`)

        } // End If 

      } // End If 

      const cometda_sal = await select('cometda_sal')

      await goto('TOP')

      this.Form.als_doc.prop.RowSource = 'cometda_sal.des_tda,alm_tda'
      this.Form.als_doc.prop.RowSourceType = 2
      this.Form.als_doc.Refresh
      // VFP LOCATE For cometda_sal.alm_tda=Public.value.usu_alm
      result = await locateFor(` cometda_sal.alm_tda=Public.value.usu_alm`)

      if (!found()) {
        await goto('TOP')

        Public.value.usu_alm = cometda_sal.alm_tda
      } // End If 

      switch (true) {
        case cometdo.inv_tdo == 'S' && cometdo.tra_tdo == 1:
          // si es un traspaso
          const cometda_sal = await select('cometda_sal')

          await goto('TOP')

          if (len(lTrim(Public.value.usu_alm)) > 0) {
            // VFP LOCATE For cometda_sal.alm_tda=Public.value.usu_alm
            result = await locateFor(` cometda_sal.alm_tda=Public.value.usu_alm`)

            if (found()) {
              this.Form.als_doc.prop.Value = cometda_sal.alm_tda
            } // End If 

          } // End If 

          if (this.Form.als_doc.prop.Value == '  ') {
            const cometda_sal = await select('cometda_sal')

            await goto('TOP')

            this.Form.als_doc.prop.Value = cometda_sal.alm_tda
          } // End If 

          if (this.Form.ale_doc.prop.Value == '  ') {
            const cometda_ent = await select('cometda_ent')

            await goto('TOP')

            this.Form.ale_doc.prop.Value = cometda_ent.alm_tda
          } // End If 

          const vi_lla1_doc = await select('vi_lla1_doc')

          break
        // si es una salida o un pedido de cliente
        case cometdo.inv_tdo == 'S' || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'C'):
          if (len(lTrim(Public.value.usu_alm)) > 0) {
            this.Form.als_doc.prop.Value = Public.value.usu_alm
          } // End If 

          if (this.Form.als_doc.prop.Value == '  ') {
            this.Form.als_doc.prop.Value = cometda_sal.alm_tda
          } // End If 

          break
        // si es una entrada o un pedido de proveedores
        case cometdo.inv_tdo == 'E' || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'P'):
          if (len(lTrim(Public.value.usu_alm)) > 0) {
            this.Form.ale_doc.prop.Value = Public.value.usu_alm
          } // End If 

          if (this.Form.ale_doc.prop.Value == '  ') {
            this.Form.ale_doc.prop.Value = cometda_ent.alm_tda
          } // End If 

      } // End case 

      this.Form.als_doc.Refresh
      this.Form.ale_doc.Refresh
    } else {

      // Si es un documento ya existente
      if (vi_lla1_doc.sta_doc == 'I') {
        // reviza si el documento esta impreso
      } // End If 
      //!//        if thisform.messagebox("El documento esta impreso, deseas continuar",4+32)#6
      //!//            this.value=get_con_doc(thisform.tdo_tdo.value)
      //!//           return .f.
      //!//        endif
      //!//        thisform.D_sta_doc.DisabledBackColor=RGB(128,255,128)

      if (vi_lla1_doc.sta_doc == 'T') {
        // reviza si el documento esta timbrado
      } // End If 
      //!//        if thisform.messagebox("El documento ya esta timbrado, deseas continuar",4+32)#6
      //!//            this.value=get_con_doc(thisform.tdo_tdo.value)
      //!//           return .f.
      //!//        endif

      this.Form.sw_nue = false
      // el documento ya existe
      // apagamos switch de registro nuevo
      m = appendM(m, await scatter())// scatter 

      ó
      // si es un documento de entrada o salida o es de
      // cargo o abono
      if ((cometdo.inv_tdo$'ES' || cometdo.coa_tdo$'CA') && m.fec_doc <= Public.value.uac_pge) {
        this.Form.MessageBox('No se permite la captura o modificación de documentos de periodos anteriores')
        this.Form.sw_cie_per = true
        this.Form.detalle()
      } // End If 

      //select(0)
      // revizamos si tiene movimientos el documento

      ins_sql = "select CAST(count(mov_mov) as int) as num_mov from man_comemov where man_comemov.tdo_tdo='" + this.Form.tdo_tdo.prop.Value + "'" + ' and man_comemov.ndo_doc=' + str(this.Form.ndo_doc.prop.Value)
      =iif(await SQLExec(ins_sql) > 0, true, err_sql())
      m = appendM(m, await scatter())// scatter 

      releaseUse() // use 

      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // Sqlcommit ( Public.value.num_dbs ) 

        await SQLExec("commit work;")

      } // End If 
      //   iif(sqlexec(num_dbs,"commit")>0,.t.,err_sql())

      this.Form.captura_movi.prop.Disabled = false
      // habilitamos captura de movimientos
      if (this.Form.prop.Valid != 'IN' && this.Form.prop.Valid != 'PG' && this.Form.prop.Valid != 'AE') {
        // si la captura es diferente de inventario
        this.Form.cod_nom.Refresh
        //   thisform.cod_nom.value=cod_nom   && asignamos el codigo del cliente o proveedor
        this.Form.cod_nom.valid
        // validamos codigos de clientes o proveedores
        this.Form.con_con.valid
        //     thisform.con_con.Value=con_con
        // validamos consignatario
        if (this.Form.prop.Valid == 'VE' || this.Form.prop.Valid == 'PC') {
          this.Form.ven_ven.valid
          // validamos vendedor
          this.Form.ven_ven.Refresh
          //     thisform.ven_ven.value=ven_ven   && asignamos el vendedor
          // asignamos el vendedor
        } // End If 

      } else {

        if (this.Form.prop.Valid == 'PG' || this.Form.prop.Valid == 'AE') {
          this.Form.tba_tba.Refresh
          this.Form.tba_tba.valid
        } // End If 

      } // End If 

      if (cometdo.tip_cfd != 'NA' && cometdo.tip_cfd != '  ') {
        const vi_lla1_xml = await select('vi_lla1_xml')

        await use('vi_lla1_xml', m) // use vi_lla1_xml vi_lla1_xml

        if (await recCount() > 0 && vi_lla1_doc.sta_doc != vi_lla1_xml.sta_doc) {
          m.sta_doc = vi_lla1_xml.sta_doc
        } // End If 
        //        ins_sql='update man_comedoc set sta_doc=?m.sta_doc where tdo_tdo=?M.tdo_tdo and ndo_doc=?m.ndo_doc'
        //        =Iif(SQLExec(num_dbs,ins_sql)<0,err_sql(),0)
        //       replace vi_lla1_doc.sta_doc WITH m.sta_doc

      } // End If 

      const vi_lla1_doc = await select('vi_lla1_doc')

      this.Form.D_sta_doc.DisabledBackColor = Rgb(0, 255, 255)
      switch (true) {
        case sta_doc == 'C':
          // estatus de docto
          this.Form.D_sta_doc.prop.Value = 'Cancelado'
          this.Form.MessageBox('Documento cancelado')
          if (Public.value.log_usu != ('ADMIN     ')) {
            return

          } // End If 

          this.Form.D_sta_doc.DisabledBackColor = Rgb(255, 0, 0)
          break
        case sta_doc == 'I':
          this.Form.D_sta_doc.prop.Value = 'Impreso'
          break
        case sta_doc == 'T':
          this.Form.D_sta_doc.prop.Value = 'Timbrado'
          this.Form.D_sta_doc.DisabledBackColor = Rgb(255, 255, 0)
          break
        case sta_doc == 'X':
          this.Form.D_sta_doc.prop.Value = 'Proceso Timbrado incompleto'
          this.Form.D_sta_doc.DisabledBackColor = Rgb(255, 0, 0)
          break        default: this.Form.D_sta_doc.prop.Value = 'Proceso'
      } // End case 

      this.Form.otro.prop.Disabled = false
      //habilitamos controles
      if (this.Form.sw_cie_per) {
        this.Form.cancela_docto.prop.Disabled = true
        this.Form.borra_movto.prop.Disabled = true
        this.Form.paridades.prop.Disabled = true
        //     thisform.observaciones.enabled=.f.
        this.Form.dre_doc.prop.Disabled = true
      } else {
        //  Thisform.impuestos.Enabled=.F.

        this.Form.cancela_docto.prop.Disabled = false
        this.Form.borra_movto.prop.Disabled = false
        this.Form.paridades.prop.Disabled = false
        //     thisform.observaciones.enabled=.t.
        this.Form.dre_doc.prop.Disabled = false
      } // End If 
      //  Thisform.impuestos.Enabled=.T.

      this.Form.imprime.prop.Disabled = false
      this.Form.salir.prop.Disabled = false
      const vi_lla1_tdo = await select('vi_lla1_tdo')
      // solo se habilita cuando cliente y es abono

      await use('vi_lla1_tdo', m) // use vi_lla1_tdo vi_lla1_tdo
      // o cuando es proveedor y un cargo


      // predemos switch de movimientos
      // si tiene movimientos
      if (m.num_mov == 0 && m.imp_doc + m.im0_doc + m.im1_doc + m.im2_doc + m.im3_doc + iif(Public.value.sw_imp, m.im4_doc + m.im5_doc, 0) != 0) {
        this.Form.MessageBox('No se permite capturar movimientos en un documento que tenga importes')
        return false

      } // End If 

      this.Form.sw_mov = iif(m.num_mov > 0 || vi_lla1_doc.imp_doc > 0, true, false)
      for (const Control of this.Form.Controls) {

        // recorremos todos los controles
        if (substr(Control.prop.Name, 4, 1) == '_') {
          Control.prop.Valid = true
          // prendemos la validación y revizamos permisos
          if ((Control.prop.BaseClass == 'Textbox' || Control.prop.BaseClass == 'Editbox')) {
            Control.prop.ReadOnly = false
            if ((this.Form.sw_mov && (Control.prop.Name == 'fec_doc' || Control.prop.Name == 'ped_ped'))) {
              Control.prop.ReadOnly = true
              // solo de lectura
            } // End If 

          } else {

            Control.prop.Disabled = false
            // permitimos captura
            if (this.Form.sw_mov) {
              if (Control.prop.Name == 'als_doc' || Control.prop.Name == 'ale_doc') {
                Control.prop.Disabled = true
                // no permitimos captura
              } // End If 

              if (Control.prop.Name == 'mon_doc' && (cometdo.coa_tdo == 'C' || cometdo.coa_tdo == 'A')) {
                Control.prop.Disabled = true
                // no permitimos captura
              } // End If 

            } // End If 

          } // End If 

          if (Control.prop.Name != 'tcd_tcd') {
            Control.Refresh
          } else {

            if (await recCount('vi_cap_cometcd') > 0) {
              Control.Refresh
            } // End If 

          } // End If 

        } // End If 

      } // End For; 

      this.Form.c_ob1_doc.prop.ReadOnly = false
      // thisform.mon_doc.value=vi_lla1_doc.mon_doc
      this.Form.c_ob2_doc.prop.ReadOnly = false
      this.Form.c_ob3_doc.prop.ReadOnly = false
      this.Form.c_ob1_doc.prop.Disabled = false
      this.Form.c_ob2_doc.prop.Disabled = false
      this.Form.c_ob3_doc.prop.Disabled = false
      this.Form.c_ob1_doc.Refresh
      this.Form.c_ob2_doc.Refresh
      this.Form.c_ob3_doc.Refresh
      this.Form.mon_doc.Refresh

      // si es un cliente de mostrador
      // o proveedor varios
      if ((cometdo.coa_tdo == 'C' || cometdo.coa_tdo == 'A') && (vi_lla1_doc.sta_doc == 'T' || vi_lla1_doc.sta_doc == 'I') && ((vi_lla1_nom.cop_nom == 'C' && vi_lla1_nom.cod_nom == Public.value.mos_pge) || (vi_lla1_nom.cop_nom == 'P' && vi_lla1_nom.cod_nom == Public.value.pva_pge) || vi_lla1_tdn.mos_tdn == 1)) {
        this.Form.con_con.prop.ReadOnly = true
        //    (vi_lla1_nom.cop_nom+vi_lla1_nom.cod_nom='C'+m.mos_pge .or. 
        //       vi_lla1_doc.cop_nom+vi_lla1_doc.cod_nom='P'+m.pva_pge)
        if (m.num_mov > 0) {
          // si ya tiene movimientos
          this.Form.d_nom_nom.prop.ReadOnly = true
          // apagamos los datos del cliente
          this.Form.d_dir_nom.prop.ReadOnly = true
          // del mostrador
          this.Form.d_ext_nom.prop.ReadOnly = true
          this.Form.d_int_nom.prop.ReadOnly = true
          this.Form.d_pai_nom.prop.ReadOnly = true
          this.Form.d_col_nom.prop.ReadOnly = true
          this.Form.d_pob_nom.prop.ReadOnly = true
          this.Form.d_cpo_nom.prop.ReadOnly = true
          this.Form.d_rfc_nom.prop.ReadOnly = true
          if (this.Form.sw_rfi) {
            this.Form.d_rfi_nom.prop.Disabled = true
          } // End If 

        } // End If 
        //   thisform.ped_ped.readonly=.t.   && pedimento aduanal

      } else {

        if (this.Form.prop.Valid != 'IN' && this.Form.prop.Valid != 'PG' && this.Form.prop.Valid != 'AE') {
          this.Form.con_con.prop.ReadOnly = false
        } // End If 

      } // End If 

      this.Form.tdo_tdo.prop.Disabled = true
      // deshabilitamos el tipo de documento
      this.prop.ReadOnly = true
      // ponemos el codigo de solo lectura
      this.Form.d_imp_doc.valid
      // calcula total
    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    this.prop.Valid = true
    //thisform.refresh
    // aceptamos como validado
    this.Form.tdo_tdo.prop.Valid = true
    this.Form.captura_movi.prop.Disabled = false
    if (this.Form.sw_xml) {
      // Lee XML utiliza el parametro de mantenimiento
      this.Form.captura_xml.lee_xml('COMEDOC', vi_lla1_doc.tdo_tdo, iif(this.Form.sw_nue, 0, vi_lla1_doc.key_pri))
      // elemento nuevo
    } // End If 

    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :ndo_doc
  // tipo   :cuadro de texto
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly) {
      return false

    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    m = appendM(m, await scatter())// scatter 

    this.prop.Valid = true
    //thisform.refresh
    // aceptamos como validado
    this.Form.tdo_tdo.prop.Valid = true
    const vi_lla1_seg = await select('vi_lla1_seg')

    m.tdo_tdo = (this.Form.tdo_tdo.prop.Value)
    // si no ha leido seguridad o cambio el tipo de docto
    // lee la seguridad
    if (await recCount() == 0 || vi_lla1_seg.tdo_tdo != m.tdo_tdo) {
      await use('vi_lla1_seg', m) // use vi_lla1_seg vi_lla1_seg
      //   m.tdo_tdo=enc_pal(thisform.tdo_tdo.value)        && encriptamos palabra para buscar su registro

      if (await recCount() > 0) {
        m = appendM(m, await scatter())// scatter 

      } else {

        m.per_seg = space(120)
      } // End If 

      for (let i = 1; i < 50; i++) {
        // llenamos variable de nombre de campos
        this.Form.nom_obj(i, 1) = substr(Public.value.cmp_seg, ((i - 1) * 4) + 1, 3)
        this.Form.nom_obj(i, 2) = substr(m.per_seg, i, 1)
      } // End For; 

    } // End If 

    this.Form.la_als_doc.prop.Visible = false
    this.Form.als_doc.prop.Visible = false
    this.Form.la_ale_doc.prop.Visible = false
    this.Form.ale_doc.prop.Visible = false
    switch (true) {
      case cometdo.inv_tdo == 'S' && cometdo.tra_tdo == 1:
        this.Form.als_doc.prop.Visible = true
        this.Form.ale_doc.prop.Visible = true
        this.Form.als_doc.prop.Disabled = false
        this.Form.ale_doc.prop.Disabled = false
        this.Form.la_als_doc.prop.Visible = true
        this.Form.la_ale_doc.prop.Visible = true
        this.Form.ult_ele = 'ale_doc'
        break
      // si es una salida o un pedido de cliente
      case cometdo.inv_tdo == 'S' || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'C'):
        this.Form.als_doc.prop.Visible = true
        this.Form.als_doc.prop.Disabled = false
        this.Form.la_als_doc.prop.Visible = true
        this.Form.ult_ele = 'als_doc'
        break
      // si es una entrada o un pedido de proveedores
      case cometdo.inv_tdo == 'E' || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'P'):
        this.Form.ale_doc.prop.Visible = true
        this.Form.als_doc.prop.Disabled = false
        this.Form.ale_doc.prop.Disabled = false
        this.Form.la_ale_doc.prop.Visible = true
        this.Form.ult_ele = 'ale_doc'
        break
      case cometdo.inv_tdo == 'P' && cometdo.pga_tdo == 1:
        // or (cometdo.inv_tdo='P' and cometdo.cop_nom='P')
        break
      case cometdo.cop_nom == 'C' && (cometdo.tip_cfd == 'I' || cometdo.tip_cfd == 'E'):
             && cometdo.inv_tdo='N'
        this.Form.ult_ele = 'ndr_doc'
        break      default: this.Form.als_doc.prop.Visible = false
        this.Form.la_als_doc.prop.Visible = false
        this.Form.ale_doc.prop.Visible = false
        this.Form.la_ale_doc.prop.Visible = false
        this.Form.ult_ele = 'fve_doc'
      // If cometdo.inv_tdo='E' Or cometdo.inv_tdo='S'
      //  Thisform.la_ped_ped.Visible=.F.
      //  Thisform.ped_ped.Visible=.F.
      // Endif
    } // End case 

    if (cometdo.afi_tdo == 1 && ((cometdo.inv_tdo == 'E') || (cometdo.tra_tdo == 1))) {
      this.Form.ped_ped.prop.Visible = true
      this.Form.la_ped_ped.prop.Visible = true
      this.Form.ped_ped.Refresh
      this.Form.la_ped_ped.Refresh
      this.Form.ult_ele = 'ped_ped'
    } // End If 

    if (cometdo.tip_cfd != 'NA' && cometdo.tip_cfd != '  ' && cometdo.inv_tdo == 'N') {
      this.Form.ult_ele = 'tre_sat'
    } // End If 


    // busca el campo para asignarle su seguridad
    if (Public.value.log_usu == ('ADMIN') || this.Form.sw_aut) {
      // si es el administrador
      return true

    } // End If 

    let pos = ascan(this.Form.nom_obj, upper(LineSlant(this.prop.Name, 3)))
    if (pos > 0) {
      if (this.Form.nom_obj(pos + 1) == '1' || this.Form.nom_obj(pos + 1) == '3') {
        // permite captura
        return true

      } else {

        this.gotFocus()
        this.valid
        return false

      } // End If 

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}