//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : otro
// Description : Componente otro
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class otro extends IMGBUTTON {
  //public
  constructor() {
    super();


    this.style.autoSize = 'false';
    this.style.backgroundColor = '234,234,234';
    this.prop.Caption = "\<Otro";
    this.style.fontSize = '8px';
    this.style.height = '60px';
    //LineSlant=860;
    this.prop.Name = "otro";
    this.prop.Image = distribuidoras\imagenesdist\png48x48\accept.png;
    this.prop.TabIndex = 46;
    this.prop.ToolTipText = "Otro";
    this.style.top = '586px';
    this.style.width = '60px';
    this.style.zIndex = '28';

    //propiedades
  }

  // Evento   :Click
  // Objeto  :otro
  // Tipo   :Commandbuttom
  // Comentarios :
  // switch de release
  override async click(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (sw_rel) {
      // si se llamo del objeto desde release
      return

    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    if (await recCount('vi_lla1_doc') > 0 && await select('vi_cap_comemov')
      > 0 && await recCount('vi_cap_comemov') > 0) {
      this.Form.grabar()
    } // End If 

    this.Form.captura_xml.prop.RecordSource = ''
    if (await recCount('vi_cap_comemov') > 0) {
      // reviza si tiene abierta la vista de captura movimientos
      const vi_cap_comemov = await select('vi_cap_comemov')

      m = appendM(m, await scatterBlank())// scatter 

      this.Form.captura_movi.prop.RecordSource = ''
      // pone en nulos el record source
      this.Form.use('vi_cap_comemov', 'nodata', 'vi_cap_comemov', 'tdo_tdo=?m.tdo_tdo and ndo_doc=?m.ndo_doc', 'MOV_MOV')
      const vi_cap_comemov = await select('vi_cap_comemov')

      this.Form.captura_movi.prop.RecordSource = 'vi_cap_comemov'
      // use vi_cap_comemov nodata     && abre la vista sin datos
      // asignamos la tabla de captura de movimientos
    } // End If 

    if (await select('vi_lla1_tba')
      > 0) {
      const vi_lla1_tba = await select('vi_lla1_tbú)

       await useNodata('vi_lla1_tba') // use vi_lla1_tba vi_lla1_tba nodata
  // se abre la vista con los datos actuales

    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    await useNodata('vi_lla1_doc') // use vi_lla1_doc vi_lla1_doc nodata
    // se abre la vista con los datos actuales

    this.Form.tdo_tdo.prop.Disabled = false
    // tipo de documento ponemos en captura
    this.Form.ndo_doc.prop.ReadOnly = false
    // níºmero de documento ponemos en captura
    this.Form.tdo_tdo.setFocus()
    this.Form.c_ob1_doc.refresh
    this.Form.c_ob2_doc.refresh
    this.Form.c_ob3_doc.refresh
    return

  }   // Fin Procedure


  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.prop.key == 27) {
      this.Form.prop.key = 0
      return

    } // End If 

    if (nkeyCode > 64) {
      // si es mayor que a
      this.Form.Cancela_docto.keyPress(nKeyCode, nShiftAltCtrl)
      return

    } // End If 

    if (nkeyCode == 27) {
      // si da un escape
      this.click
    } // End If 

  }   // Fin Procedure



  // Evento   :lostFocus
  // Objeto  :otro
  // Tipo   :Commandbuttom
  // Comentarios :
  async lostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.key_preview = true
    // indica al evento keypress de la forma que se utilice de nuevo
  }   // Fin Procedure


  //metodo
}