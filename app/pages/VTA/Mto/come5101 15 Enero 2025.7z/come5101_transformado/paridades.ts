//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : paridades
// Description : Componente paridades
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class paridades extends IMGBUTTON {
//public
 	constructor() {
     super();
     

    this.style.autoSize='false';
    this.style.backgroundColor='234,234,234';
    this.prop.Caption="\<Paridades ";
    this.style.fontSize='9px';
    this.style.height='25px';
//LineSlant=433;
    this.prop.Name="paridades";
    this.prop.TabIndex=57;
    this.prop.ToolTipText="Paridades";
    this.style.top='602px';
    this.style.width='67px';
    this.style.zIndex='24';

     //propiedades
     }
       // Evento   :Click  // Objeto  :paridades  // Tipo   :Buttom  // Comentarios :
override async click(){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const router = useRouter();    router.push({name: 'formas\par_doc' })

    const vi_lla1_doc=await select('vi_lla1_doc')

        switch (true) {
      case vi_lla1_doc.mon_doc==1:  // actualiza segun paridad
                  // Inicio replace VFP
      Recno=await recNo()
      Alias=await alias()
await localAlaSql(`update ${Alias} set vi_lla1_doc.vmo_doc=?  where recno=${Recno} `,[1])

      break
      case vi_lla1_doc.mon_doc==2:
                  // Inicio replace VFP
      Recno=await recNo()
      Alias=await alias()
await localAlaSql(`update ${Alias} set vi_lla1_doc.vmo_doc=?  where recno=${Recno} `,[vi_lla1_doc.vm2_doc])

      break
      case vi_lla1_doc.mon_doc==3:
                  // Inicio replace VFP
      Recno=await recNo()
      Alias=await alias()
await localAlaSql(`update ${Alias} set vi_lla1_doc.vmo_doc=?  where recno=${Recno} `,[vi_lla1_doc.vm3_doc])

      break
      case vi_lla1_doc.mon_doc==4:
                  // Inicio replace VFP
      Recno=await recNo()
      Alias=await alias()
await localAlaSql(`update ${Alias} set vi_lla1_doc.vmo_doc=?  where recno=${Recno} `,[vi_lla1_doc.vm4_doc])

      break
      case vi_lla1_doc.mon_doc==5:
                  // Inicio replace VFP
      Recno=await recNo()
      Alias=await alias()
await localAlaSql(`update ${Alias} set vi_lla1_doc.vmo_doc=?  where recno=${Recno} `,[vi_lla1_doc.vm5_doc])

    } // End case 

    =gra_reg()
    return 

  }   // Fin Procedure
  override async keyPress(nKeyCode,nShiftAltCtrl){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.Cancela_docto.keyPress(nKeyCode,nShiftAltCtrl)
  }   // Fin Procedure
  // Evento   :When  // Objeto  :Paridades  // Tipo   :Buttom
override async when(){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if ( this.Form.rev_per('PAR')){  // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure
//metodo
}