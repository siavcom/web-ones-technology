//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : pga_pga
// Description : Componente pga_pga
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";
// Tiene Help hay que implementar

import { currentValue } from "~/composables/0_SqlDb";

export class pga_pga extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Component";

    this.prop.Type = 'text';
    this.prop.Caption = "Presupuesto";

    this.prop.ControlSource = "vi_lla1_doc.pga_pga";
    this.prop.InputMask = (Public.value.ipg_pge);
    //LineSlant=246;
    this.prop.ToolTipText = "partida en el presupuesto de gasto";
    this.style.width = '170px';

    //propiedades
  }


  // Evento   :Valid
  // Objeto  :pga_pga
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result

    m.pga_pga = jus_cer(this.prop.Value, 'E')

    await use('vi_lla1_tpe')

    if (await recCount('vi_lla1_tpe') == 0) {
      this.Form.MessageBox('No existe partida presupuestal', 16, 'Advertencia', 3000)

      return false
    } // End If 
    const vi_lla1_tpe = await currentValue('*', 'vi_lla1_tpe')
    if (vi_lla1_tpe.tba_tba < '0') {
      this.Form.MessageBox('La partida presupuestal no tiene asignado supervisor', 16, 'Advertencia', 3000)
      return false

    } // End If 

    this.Form.tba_tba.prop.Value = vi_lla1_tpe.tba_tba
    // Inicio replace VFP
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set vi_lla1_doc.tba_tba=?  where recno=${Recno} `, [vi_lla1_tpe.tba_tba])

    if (this.Form.tba_tba.valid()) {
      this.prop.Value = m.pga_pga
      //SELECT vi_lla1_tba
      const vi_lla1_doc = await select('vi_lla1_doc')

      this.prop.Valid = true
      return true

    } // End If 

    this.prop.Value = space(12)
    this.prop.Valid = false
    return false

  }   // Fin Procedure

  // Evento   :When
  // Objeto  :pga_pga
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result


    if (this.Form.tba_tba.prop.Value == space(12)) {
      return true

    } // End If 

    return this.Form.sw_nue

  }   // Fin Procedure

  //metodo
}