//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : tcd_tcd
// Description : Componente tcd_tcd
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class tcd_tcd extends COMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";

    this.prop.Multiselect = false;
    this.prop.BoundColumn = 2;
    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "120,20";
    this.prop.ControlSource = "vi_lla1_doc.tcd_tcd";
    this.DisabledBackColor = 234, 234, 234;
    this.DisabledForeColor = 0, 0, 0;
    this.style.height = '24px';
    //LineSlant=369;
    this.prop.Name = "tcd_tcd";
    this.prop.RowSource = "vi_cap_cometcd.des_tcd,tcd_tcd";
    this.prop.RowSourceType = 2;
    this.prop.Style = 2;
    this.prop.TabIndex = 3;
    this.prop.ToolTipText = "Clasificación del documento";
    this.style.top = '53px';
    this.style.width = '222px';
    this.style.zIndex = '79';

    //propiedades
  }

  // Evento   :Valid
  // Objeto  :tcd_tcd
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Resultóó
    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :GotFocues
  // Objeto  :tcd_tcd
  // Tipo   :ComboBox
  // Comentarios :si tiene clasificación de documentos permite escojer clasificación de documentos
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    if (await recCount('vi_cap_cometcd') == 1 && vi_cap_cometcd.tcd_tcd == ' ') {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}