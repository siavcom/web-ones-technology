//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : tdo_tdo
// Description : Componente tdo_tdo
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { currentValue } from "~/composables/0_SqlDb";

export class tdo_tdo extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";
    this.prop.BoundColumn = 2;
    this.prop.ColumnCount = 2;
    this.prop.ColumnWidths = "250,50";
    this.prop.Disabled = false;
    this.prop.RowSource = "cometdo.des_tdo,tdo_tdo";
    this.prop.RowSourceType = 2;
    this.style.fontFamily = 'Arial';
    this.style.fontSize = '17px';

    this.style.width = '214px';


    //propiedades
  }

  // evento   :when
  // objeto  :tdo_tdo
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    await super.when()

    if (this.prop.Visible == true) {
      // si esta activo
      this.Form.sw_aut = false
      // apagamos switch de autorizado
      //inicializamos datos

      await useNodata('vi_lla1_nom') // use vi_lla1_nom vi_lla1_nom nodata

      //     this.Form.otro.prop.Disabled = false
      this.Form.cancela_docto.prop.Disabled = true
      this.Form.borra_movto.prop.Disabled = true
      this.Form.paridades.prop.Disabled = true
      // thisform.observaciones.enabled=.f.
      this.Form.dre_doc.prop.Disabled = true
      this.Form.imprime.prop.Disabled = true
      // thisform.impuestos.enabled=.f.
      this.Form.carta_porte.prop.Disabled = true
      this.Form.salir.prop.Disabled = false
      const cometdo = await currentValue('*', 'cometdo')
      if (cometdo.afi_tdo == 1) {
        this.Form.ped_ped.prop.Visible = false

      } // End If 

      this.Form.d_imp_doc.prop.Value = 0
      //thisform.d_mov_mov.value=1
      this.Form.d_im0_doc.prop.Value = 0
      this.Form.d_im1_doc.prop.Value = 0
      this.Form.d_im2_doc.prop.Value = 0
      this.Form.d_im3_doc.prop.Value = 0
      this.Form.d_im4_doc.prop.Value = 0
      this.Form.d_im5_doc.prop.Value = 0
      this.Form.d_exi_pro.prop.Value = 0
      this.Form.d_tot_doc.prop.Value = 0
      this.Form.carga_xml.prop.Disabled = true


      // if thisform.tag#'IN' AND thisform.tag#'PG' AND thisform.tag#'AE'        && si la captura es differente a inventario
      if (cometdo.cop_nom == 'C' || cometdo.cop_nom == 'P') {
        this.Form.datos_cliente.click(true)
      } // End If 

      if (this.Form.sw_xml) {
        this.Form.captura_xml.prop.RecordSource = ''
      } // End If 

      this.prop.Valid = false
    } // End If 

    return true

  }   // Fin Procedure

  override async valid() {
    await super.valid()
    let m = { ...this.Form.mPublic };  // Inicializamos m

    const cometdo = await currentValue('*', 'cometdo')

    const result = await locateFor(` tdo_tdo=this.prop.Value`)

    m.tdo_tdo = this.prop.Value
    // seleccionamos la tabla de clasificación de documentos
    await requery('vi_cap_cometcd')

    if (await recCount('vi_cap_cometcd') == 0) {
      await appendBlank()

    } // End If 

    this.Form.tcd_tcd.requery()

    this.Form.sw_nue = false
    // se apaga swith de documento nuevo
    let vi_lla1_tdo = await currentValue('*', 'vi_lla1_tdo')

    m.tdo_tdo = this.Form.tdo_tdo.prop.Value
    // asignamos el valor
    // this.Form.ndo_doc.prop.ReadOnly = false
    //this.Form.otro.prop.Disabled = true
    // deshabilitamos para
    //this.Form.salir.prop.Disabled = false
    //this.prop.Valid = true
    m.afi_tdo = 0
    // afectación de importaciones
    if (cometdo.tra_tdo == 1) {
      // si es un traspaso
      m.tdo_tdo = cometdo.ptr_tdo
      // obtiene el documento de traspaso

      await use('vi_lla1_tdo', m) // use vi_lla1_tdo vi_lla1_tdo

      vi_lla1_tdo = await currentValue('*', 'vi_lla1_tdo')
      m.afi_tdo = vi_lla1_tdo.afi_tdo
      // asigna si es una importación
    } // End If 

    m.nom_tab = this.Form.prop.Name
    // buscamos si se calculan existencias segun tipo de documento
    m.par_dxm = this.prop.Value
    m.var_dxm = 'cal_exi'
    const vi_lla1_dxm = await currentValue('*', 'vi_lla1_dxm')

    if (await recCount('vi_lla1_dxm') < 1 || (cometdo.inv_tdo != 'E' && cometdo.cop_nom == 'C')) {
      this.Form.cal_exi = 'SI'
    } // End If 

    if (cometdo.inv_tdo == 'E') {
      this.Form.cal_exi = 'NO'
    } // End If 

    if (await recCount('vi_lla1_dxm') < 1 || m.par_dxm != vi_lla1_dxm.par_dxm) {
      await requery('vi_lla1_dxm')

      if (await recCount('vi_lla1_dxm') > 0) {
        this.Form.cal_exi = allTrim(vi_lla1_dxm.val_dxm)
      } // End If 

    } // End If 


    // 9/Agosto/2023 documentos permitidos en compras o ventas
    if (this.Form.prop.Valid == 'CO' || this.Form.prop.Valid == 'VE') {
      m.par_dxm = this.Form.prop.Valid
      // tipo de captura
      m.var_dxm = this.prop.Value
      await use('vi_lla1_dxm', m)
      const vi_lla1_dxm = await currentValue('*', 'vi_lla1_dxm')

      if (await recCount('vi_lla1_dxm') > 0) {
        this.Form.doc_per = allTrim(vi_lla1_dxm.val_dxm)
      } else {

        this.Form.doc_per = ''
      } // End If 

    } // End If 

    vi_lla1_tdo = await currentValue('*', 'vi_lla1_tdo')
    // .and. cometdo.cop_nom='P'
    if (cometdo.cop_nom == 'C' || cometdo.cop_nom == 'P') {
      //thisform.Tag<>'IN' or
      this.Form.datos_cliente.click(true)
      // muestra datos de clientes
    } // End If 

    if (cometdo.cop_nom == 'C' && (cometdo.tip_cfd == 'T' || cometdo.tip_cfd == 'I' || cometdo.tip_cfd == 'E') && cometdo.inv_tdo != 'P') {
      this.Form.la_tre_sat.prop.Visible = true
      this.Form.tre_sat.prop.Visible = true
    } // End If 

    if (cometdo.cop_nom == 'C' && cometdo.tip_cfd == 'T') {
      this.Form.tdr_doc.prop.Visible = true
      this.Form.ndr_doc.prop.Visible = true
    } // End If 

    return true

  }   // Fin Procedure




  //metodo
}