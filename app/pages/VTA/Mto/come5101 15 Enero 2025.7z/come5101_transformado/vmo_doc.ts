//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : vmo_doc
// Description : Componente vmo_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class vmo_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = 'Paridad';
    this.prop.Type = 'number'
    this.prop.ControlSource = "vi_lla1_doc.vmo_doc";

    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "Paridad con respecto a la moneda principal";
    this.style.width = '76px';

    //propiedades
  }

  // Evento   :Valid
  // Objeto  :vmo_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Es la validación del valor de la moneda
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')

    if (this.prop.Value > 0) {
      switch (true) {
        case this.Form.mon_doc.prop.Value == 2:
          // actualiza segun paridad
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.vm2_doc=?  where recno=${Recno} `, [this.prop.Value])

          break
        case this.Form.mon_doc.prop.Value == 3:
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.vm3_doc=?  where recno=${Recno} `, [this.prop.Value])

          break
        case this.Form.mon_doc.prop.Value == 4:
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.vm4_doc=?  where recno=${Recno} `, [this.prop.Value])

          break
        case this.Form.mon_doc.prop.Value == 5:
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.vm5_doc=?  where recno=${Recno} `, [this.prop.Value])

      } // End case 

      this.prop.Valid = true
      return true

    } // End If 

    this.prop.Valid = false
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :mon_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly || this.Form.sw_mov) {
      return false

    } // End If 
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    if (vi_lla1_doc.mon_doc == 1) {
      this.prop.Valid = true
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    }
    this.prop.Valid = true
    return false

  } // End If 

}   // Fin Procedure


  //metodo
}