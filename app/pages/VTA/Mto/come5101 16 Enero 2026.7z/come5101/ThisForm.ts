//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : captureForm
// Class : Capture Form
// Description : Forma de captura
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////

///////////////////////////////////////
// Base class
///////////////////////////////////////

import { captureForm } from "@/classes/CaptureForm";
import { ale_doc } from './ale_doc';
import { als_doc } from './als_doc';
import { c_ob1_doc } from './c_ob1_doc';
import { c_ob2_doc } from './c_ob2_doc';
import { c_ob3_doc } from './c_ob3_doc';
import { captura_movi } from './captura_movi';
import { cod_nom } from './cod_nom';
import { con_con } from './con_con';
import { d_col_nom } from './d_col_nom';
import { d_cpo_nom } from './d_cpo_nom';
import { d_des_tdn } from './d_des_tdn';
import { d_dir_nom } from './d_dir_nom';
import { d_edo_edo } from './d_edo_edo';
import { d_exi_pro } from './d_exi_pro';
import { d_ext_nom } from './d_ext_nom';
import { d_im0_doc } from './d_im0_doc';
import { d_im1_doc } from './d_im1_doc';
import { d_im2_doc } from './d_im2_doc';
import { d_im3_doc } from './d_im3_doc';
import { d_im4_doc } from './d_im4_doc';
import { d_im5_doc } from './d_im5_doc';
import { d_imp_doc } from './d_imp_doc';
import { d_int_nom } from './d_int_nom';
import { d_lis_nom } from './d_lis_nom';
import { d_mov_mov } from './d_mov_mov';
import { d_noc_con } from './d_noc_con';
import { d_nom_nom } from './d_nom_nom';
import { d_nom_tba } from './d_nom_tba';
import { d_nom_ven } from './d_nom_ven';
import { d_pai_nom } from './d_pai_nom';
import { d_pob_nom } from './d_pob_nom';
import { d_rfc_nom } from './d_rfc_nom';
import { d_rfi_nom } from './d_rfi_nom';
import { d_sta_doc } from './d_sta_doc';
import { d_te1_nom } from './d_te1_nom';
import { d_tot_doc } from './d_tot_doc';
import { bt_dre_doc } from './bt_dre_doc';
import { fec_doc } from './fec_doc';
import { fip_doc } from './fip_doc';
import { fpa_sat } from './fpa_sat';
import { fve_doc } from './fve_doc';
import { Imprime } from './Imprime';

import { mon_doc } from './mon_doc';
import { mpa_sat } from './mpa_sat';
import { ndo_doc } from './ndo_doc';
import { ndr_doc } from './ndr_doc';
import { npa_doc } from './npa_doc';

import { paridades } from './paridades';
import { ped_ped } from './ped_ped';
import { pga_pga } from './pga_pga';
import { ref_doc } from './ref_doc';
import { rpa_doc } from './rpa_doc';
import { tba_tba } from './tba_tba';
import { tcd_tcd } from './tcd_tcd';
import { tdo_tdo } from './tdo_tdo';
import { tdr_doc } from './tdr_doc';
import { Total } from './Total';
import { tpa_doc } from './tpa_doc';
import { tre_sat } from './tre_sat';
import { uso_sat } from './uso_sat';
import { ven_ven } from './ven_ven';
import { vmo_doc } from './vmo_doc';
import { bt_campos_xml } from './bt_campos_xml';
import { bt_carta_porte } from './bt_carta_porte';
import { bt_cancela_docto } from './bt_cancela_docto';
import { bt_autorizacion } from './bt_autorizacion';

const View = {}

export class ThisForm extends captureForm {
  // Datos base del documento
  public tdo_tdo = new tdo_tdo()
  public ndo_doc = new ndo_doc()
  public tcd_tcd = new tcd_tcd()
  public d_sta_doc = new d_sta_doc()
  public ref_doc = new ref_doc()

  // Datos de clientes y proveedores
  public cod_nom = new cod_nom()
  public d_nom_nom = new d_nom_nom()
  public con_con = new con_con()
  public d_noc_con = new d_noc_con()
  public d_dir_nom = new d_dir_nom()
  public d_ext_nom = new d_ext_nom()
  public d_int_nom = new d_int_nom()
  public d_col_nom = new d_col_nom()
  public d_pob_nom = new d_pob_nom()
  public d_edo_edo = new d_edo_edo()
  public d_cpo_nom = new d_cpo_nom()
  public d_pai_nom = new d_pai_nom()
  public d_te1_nom = new d_te1_nom()
  public d_rfc_nom = new d_rfc_nom()
  public d_rfi_nom = new d_rfi_nom() // Regimen fiscal componente siavcom COMBOSAT 
  public d_des_tdn = new d_des_tdn()
  public d_lis_nom = new d_lis_nom()
  public ven_ven = new ven_ven()
  public d_nom_ven = new d_nom_ven()


  // Datos del documento 
  public mon_doc = new mon_doc()
  public vmo_doc = new vmo_doc()
  public fec_doc = new fec_doc()
  public fve_doc = new fve_doc()
  public npa_doc = new npa_doc() // número de parcialidades
  public tpa_doc = new tpa_doc() // tipo de parcialidad
  public rpa_doc = new rpa_doc() // rango de parcialidad
  public fip_doc = new fip_doc() // fecha primer pago
  public tdr_doc = new tdr_doc() // "Tipo de documento origen";
  public ndr_doc = new ndr_doc()
  public als_doc = new als_doc()
  public ale_doc = new ale_doc()
  public ped_ped = new ped_ped()

  // Datos del SAT
  public fpa_sat = new fpa_sat()
  public uso_sat = new uso_sat()
  public mpa_sat = new mpa_sat()
  public tre_sat = new tre_sat()

  // Datos de trabajadores para presupuesto de gasto de proteccion industrial
  public pga_pga = new pga_pga()
  public tba_tba = new tba_tba()
  public d_nom_tba = new d_nom_tba()

  public captura_movi = new captura_movi()


  public c_ob1_doc = new c_ob1_doc()
  public c_ob2_doc = new c_ob2_doc()
  public c_ob3_doc = new c_ob3_doc()

  // Existencia del producto
  public d_mov_mov = new d_mov_mov()
  public d_exi_pro = new d_exi_pro()

  // Impuestos y Total
  public d_imp_doc = new d_imp_doc()
  public d_im0_doc = new d_im0_doc()
  public d_im1_doc = new d_im1_doc()
  public d_im2_doc = new d_im2_doc()
  public d_im3_doc = new d_im3_doc()
  public d_im4_doc = new d_im4_doc()
  public d_im5_doc = new d_im5_doc()

  public d_tot_doc = new d_tot_doc()

  public bt_dre_doc = new bt_dre_doc()
  public bt_autorizacion = new bt_autorizacion()
  public bt_cancela_docto = new bt_cancela_docto()
  public bt_campos_xml = new bt_campos_xml()
  public bt_carta_porte = new bt_carta_porte()

  public Imprime = new Imprime()
  public Label3 = new Label3()

  public otro = new otro()
  public paridades = new paridades()


  public Total = new Total()
  tipoCaptura: string = ''

  constructor() {
    super();
    this.prop.Name = 'Pages/come5101';

    //m: detalle  && Habilita la captura de movimientos del documento
    //m: ins_movimiento  && Inserta un registro en blanco en la tabla en movimeintos
    //m: lee_isu  && Lectura de los datos del insumo
    //m: obten_precio  && Obtiene el precio si hay politica de precios
    //m: rev_per  && Reviza los permisos que tiene los grupos de usuarios en uno de los objetos
    //p: ask_con
    //p: cal_exi
    //p: con_insu  && Consulta de insumos
    //p: det_mov  && Indica el número de talles que lleva
    //p: dia_ped  && SHEL.- dias pedido/30  x P.Reorden del  almacen cal existencia posible a la fecha de entrega
    //p: doc_blo  && Documentos que se bloquean y ya no se pueden volver a generar
    //p: doc_ped  && Docto pedidos donde se valida can maxima pedida
    //p: doc_per  && Docuemntos permitidos
    //p: doc_sur  && Documentos que permiten surtido
    //p: dpe_mov  && Documento del pedido
    //p: exi_alm  && Calculo de existencia por almacen
    //p: fac_ele
    //p: key_preview  && Manejo de key Preview
    //p: max_ped  && Si es = 1 , valida que no se pueda surtir mas de lo que esta en el pedido
    //p: mod_emp
    //p: mpe_mov  && Movimiento dentro del pedido
    //p: mub_tda  && Manejo de ubicaciones
    //p: npe_mov  && Numero de documento de pedido
    //p: sw_aut  && Switrch de autorización
    //p: sw_cie_per
    //p: sw_dre_doc
    //p: sw_mov  && Switch si el docto contiene movimientos
    //p: sw_rfi  && Regimen fiscal
    //p: sw_tca  && Switxh de tabla de claves alternas
    //p: ult_ele  && Ultimo elemento en la capura del header
    //a: nom_obj[50,2]  && Arreglo donde se guardan los nombres de los objetos de captura que llevan permisos
    this.cal_exi = 'S';
    this.det_mov = 0;
    this.dia_ped = 0;
    //prop.DoCreate=true;
    this.doc_blo = '';
    this.doc_ped = '';
    this.doc_per = '';
    this.doc_sur = '';
    this.dpe_mov = '  ';
    this.exi_alm = 'N';
    this.prop.Help_url = "/Archivos/Ventas/Mantenimiento/DOCUMENTOS/documentos.html"
    this.key_preview = true;
    this.max_ped = 0;
    this.mod_emp = '      ';
    this.mpe_mov = 0;
    this.mub_tda = false;
    this.prop.Name = "COME5101";
    this.npe_mov = 0;
    this.sw_cie_per = false;
    this.sw_dre_doc = false;
    this.sw_mov = false;
    this.sw_nue = false;
    this.sw_rfi = false;
    this.sw_tca = false;
    this.sw_xml = false;
    this.ult_ele = 'PED_PED';
    this.prop.Caption = "Captura de documentos de :";

  }

  // Habilita la captura de movimientos del documento
  // Evento   :Click
  // Objeto  :detalle
  // Tipo   :metodo
  // Comentarios : Obtiene el detalle de cada movimeinto
  async detalle(sw_lec: boolean) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.Params.length == 0) {
      let sw_lec = false
    } // End If 

    MessageBox('Leyendo información')

    const med_isu = new Array(3)
    this.Form.prop.key = 0
    for (const Control of this.Form.Controls) {
      // apagamos los controles para no
      // permitir la captura

      if (substr(Control.prop.Name, 4, 1) == '_') {
        if ((Control.prop.BaseClass == 'Textbox' || Control.prop.BaseClass == 'Editbox')) {
          Control.prop.ReadOnly = true
          // solo de lectura
          Control.prop.Disabled = false
        } else {

          Control.prop.Disabled = true
          // no permitimos captura
        } // End If 

        if (Control.prop.Name != 'tcd_tcd') {
          Control.Refresh
        } else {

          if (await recCount('vi_cap_cometcd') > 0) {
            Control.Refresh
          } // End If 

        } // End If 

      } // End If 

    } // End For; 

    // Deshabilitamos borrar
    this.Form.als_doc.prop.Disabled = true
    this.Form.ale_doc.prop.Disabled = true
    const vi_lla1_doc = await currentValue('*', 'vi_cap_comedoc')
    const cometdo = await currentValue('*', 'cometdo')
    // if thisform.tag#'IN' AND thisform.tag#'PG' AND thisform.Tag#'AE'    && si la captura es diferente a inventario
    if (cometdo.cop_nom == 'C' || cometdo.cop_nom == 'P') {
      //thisform.Tag<>'IN' or
      //this.Form.datos_cliente.click(false)
      // desactiva datos de cliente o proveedor
    } // End If 

    m.tdo_tdo = vi_lla1_doc.tdo_tdo
    // asignamos el número de documento para ver
    // esta vista se utilizara para actualizar los datos
    m.ndo_doc = vi_lla1_doc.ndo_doc

    await useNodata('vi_lla1_mov') // use vi_lla1_mov vi_lla1_mov Nodata
    // esta vista se utilizarí¡ para actualizar los datos
    //alias tabla && vista de movimientos

    // CursorSetProp ( "Buffering" , 5 ) 
    // Bloqueo optimista por tabla

    const vi_cap_comemov = await select('vi_cap_comemov')
    // replace suc_pge with sucursal
    // esta vista es para la captura de movimientos

    m.tdo_tdo = this.Form.tdo_tdo.prop.Value
    //   ThisForm.captura_movi.recordsource='vi_cap_comemov'  && asignamos la tabla de captura de movimientos
    // asignamos el valor del documento
    m.ndo_doc = this.Form.ndo_doc.prop.Value
    this.Form.captura_movi.prop.RecordSource = ''
    // USE vi_cap_comemov
    this.Form.requery('vi_cap_comemov')
    const vi_cap_comemov = await select('vi_cap_comemov')


    if (sw_lec) {
      // si fue llamada de solo lectura
      await goto('TOP')

      return

    } // End If 

    this.Form.captura_movi.prop.RecordSource = 'vi_cap_comemov'
    // CursorSetProp ( "Buffering" , 5 ) 
    //   Se quita el 28/01/2020 se necesita para table update
    // Bloqueo optimista por tabla

    this.Form.captura_movi.ulr_act = 0
    // cursorsetprop("FetchAsNeeded",.t.)  && Traerse datos cuando se ocupe
    //   CURSORSETPROP('BatchUpdateCount',4)
    // inicializamos el ultimo rengon que se actualizo
    this.Form.captura_movi.sw_ins = false
    // inicializamos el switch de insercion
    this.Form.prop.key = 0
    // inicializamos en 0 la ultima tecla
    if (await recCount() == 0) {
      // AND NOT sw_lec   && si no tiene ningun registro,inserta
      await this.Form.ins_movimiento()
      this.Form.det_mov = 0
      //        SCATTER memvar
      //  append blank
      this.Form.captura_movi.prop.Disabled = false
      for (let i = 1; i < this.Form.captura_movi.prop.ColumnCount; i++) {
        // Rutinas de validación apagadas
        this.Form.captura_movi.Columns(i).Controls(2).prop.Valid = false
      } // End For; 

    } else {

      let par_sql = vi_cap_comemov.cla_isu + "',?m.tdo_tdo,?m.ndo_doc,'" + vi_lla1_doc.cop_nom + "','NO EXI','" + str(vi_lla1_doc.con_con) + "',null,1"
      switch (true) {
        case Public.value.ndb_emp == 1 || Public.value.ndb_emp == 3:
          // Si es MSSQL o Sybase
          let ins_sql = "exec P_OBT_DAT_ISU_GEN '" + par_sql
          //  ins_sql="exec P_OBT_DAT_ISU_GEN '"+vi_cap_comemov.cla_isu+"',?m.tdo_tdo,?m.ndo_doc,'"+vi_lla1_doc.cop_nom+"','"+IIF(Thisform.cal_exi='SI',vi_lla1_doc.cod_nom,'NO EXI')+"','"+Str(vi_lla1_doc.con_con)+"',null,1"
          break
        case Public.value.ndb_emp == 4:
          // Si PostgreSQL
          ins_sql = "select * from P_OBT_DAT_ISU_GEN ('" + par_sql + ")"
        //  ins_sql="select // from P_OBT_DAT_ISU_GEN ('"+vi_cap_comemov.cla_isu+"',?m.tdo_tdo,?m.ndo_doc,'"+vi_lla1_doc.cop_nom+"','"+   vi_lla1_doc.cod_nom+"','"+Str(vi_lla1_doc.con_con)+"',null,1)"
      } // End case 

      let a = ins_sql
      if (await SQLExec(ins_sql, 'detalle_productos') < 0) {
        err_sql()
        const vi_cap_comemov = await select('vi_cap_comemov')

        return false

      } // End If 

      const vi_cap_comemov = await select('vi_cap_comemov')

      await goto('TOP')
      // asignamos medidas y descuentos a los datos existentes

      // VFP SCAN 
      while (!eof()) {
        m = appendM(m, await scatter())// scatter 
        let can_mov_old = vi_cap_comemov.can_mov      let pve_mov_old = vi_cap_comemov.pve_mov      let des_mov_old = vi_cap_comemov.des_mov      let de1_mov_old = vi_cap_comemov.de1_mov      let de2_mov_old = vi_cap_comemov.de2_mov      let de3_mov_old = vi_cap_comemov.de3_mov      let de4_mov_old = vi_cap_comemov.de4_mov      let de5_mov_old = vi_cap_comemov.de5_mov      let dse_mov_old = vi_cap_comemov.dse_mov      let med_mov_old = vi_cap_comemov.med_mov      let uni_mov_old = vi_cap_comemov.uni_mov      let obs_mov_old = vi_cap_comemov.obs_mov      let tba_tba_old = vi_cap_comemov.tba_tba      let ped_ped_old = vi_cap_comemov.ped_ped      const detalle_productos = await select('detalle_productos')
        // VFP LOCATE For upper(cla_isu)=upper(m.cla_isu)
        result = await locateFor(` upper(cla_isu)=upper(m.cla_isu)`)
        if (!found()) {
          this.Form.MessageBox('Error al tratar de traer el detalle del documento', 16, 'Error', 5000)
          return false

        } // End If 
        m = appendM(m, await scatter())// scatter 
        const vi_cap_comemov = await select('vi_cap_comemov')
        await gatherFrom(m)
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.can_mov=?  where recno=${Recno} `, [can_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pve_mov=?  where recno=${Recno} `, [pve_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [des_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.de1_mov=?  where recno=${Recno} `, [de1_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.de2_mov=?  where recno=${Recno} `, [de2_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.de3_mov=?  where recno=${Recno} `, [de3_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.de4_mov=?  where recno=${Recno} `, [de4_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.de5_mov=?  where recno=${Recno} `, [de5_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.dse_mov=?  where recno=${Recno} `, [dse_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [med_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.uni_mov=?  where recno=${Recno} `, [uni_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.obs_mov=?  where recno=${Recno} `, [obs_mov_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.tba_tba=?  where recno=${Recno} `, [tba_tba_old])
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.ped_ped=?  where recno=${Recno} `, [ped_ped_old])
        this.Form.det_mov = iif(this.Form.det_mov < m.mov_mov, m.mov_mov, this.Form.det_mov)      this.Form.captura_movi.ulr_act = await recNo()      await tableUpdate()
        //           Thisform.obten_precio()   && obtenemos todos los datos para captura
        //  Scatter Memvar Memo
        // inicializamos el ultimo rengon de actualización

        // actualizamos todos los campos
        skip()
      } // End while 

      if (!sw_lec) {
        if (await recCount() > 5) {
          // presenta los 5 ultimos
          await goto(await recCount() - 5)

          await skip(5)

        } else {

          await goto(1)

        } // End If 

        for (i = 1; i < this.Form.captura_movi.prop.ColumnCount; i++) {
          // Rutinas de validación prendidas
          this.Form.captura_movi.Columns(i).Controls(2).prop.Valid = true
        } // End For; 

      } // End If 

    } // End If 

    this.Form.cancela_docto.prop.Disabled = false
    // thisform.captura_movi.recordsource='vi_cap_comemov' && actualiza la tabla en el grid
    this.Form.paridades.prop.Disabled = false
    this.Form.bt_dre_doc.prop.Disabled = false
    this.Form.imprime.prop.Disabled = false
    // thisform.impuestos.enabled=.t.
    if (vi_lla1_doc.sta_doc != 'T') {
      this.Form.carta_porte.prop.Disabled = false
    } // End If 

    this.Form.salir.prop.Disabled = false
    this.Form.d_mov_mov.Refresh
    this.Form.d_exi_pro.Refresh
    return

  }   // Fin Procedure



  // Evento  :grabar
  // Objeto  :come5101
  // Tipo   :Form
  // Comentarios :Graba los datos principales de cada documento
  async grabar(sw_rel: boolean) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    let sw_nue = this.Form.sw_nue
    let vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    // seleccionamos la vista

    if (this.Form.sw_cie_per) {
      // si es un documento anterior al ultimo cierre
      return true

    } // End If 

    m = appendM(m, await scatter())// scatter 

    for (const Control of this.Form.Controls) {
      // si no esta validado y no es de lectura, esta habilitado
      // y esta visible
      if (substr(Control.prop.Name, 4, 1) == '_' && ((Control.prop.BaseClass == 'Textbox' || Control.prop.BaseClass == 'Editbox') && !Control.prop.ReadOnly) && Control.prop.Visible && Control.prop.Visible) {
        if (Control.prop.Valid == false) {
          Control.valid(sw_rel)
          // buscamos controles no validados
          if (Control.prop.Valid == false) {
            // revizamos si es buena la validación
            return false

          } // End If 

        } // End If 

      } // End If 

    } // End For; 

    let sw_gra = true
    // switch de grabación
    if (!this.sw_nue) {
      // si no es un documento nuevo
      vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')

      let est_cam = Getfldstate(-1, 'vi_lla1_doc')
      // obtiene la cadena de estatus de campos
      let est_com = replicateString('1', len(est_cam))
      // estatus a comparar
      if (len(est_cam) == 0 || est_cam == est_com) {
        // si el estatus de todos los campos es = 1
        sw_gra = false
        // apaga switch de grabación
      } // End If 

    } else {

      // asigna el tipo de cliente o proveedor
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.cop_nom=?  where recno=${Recno} `, [cometdo.cop_nom])

    } // End If 

    let sw_asi = false

    //IF sw_gra
    //   replace vi_lla1_doc.sta_doc WITH 'P'
    //endif
    while (sw_gra && ! super.vmo_doc('El documento')) {
      // rutina general de grabación
      if (!this.sw_nue) {
        // si no es nuevo
        const vi_lla1_doc = await select('vi_lla1_doc')

        await tableRevert()

        return false

      } // End If 

      if ((Public.value.num_err == 2601 && (Public.value.ndb_emp == 1 || Public.value.ndb_emp == 3)) || (Public.value.ndb_emp == 4 && Public.value.num_err == 23505)) {
        // si algien lo dio de alta primero

        //  if sw_asi THEN .or. thisform.messagebox("El número de documento alguien ya lo dio de alta. Se asigna un nuevo número de documento ",4+32)=6 then
        if (true) {

          this.Form.MessageBox("El número de documento " + allTrim(str(vi_lla1_doc.ndo_doc)) + " alguien ya lo dio de alta. Se asignara un nuevo número", 64)
          this.Form.ndo_doc.prop.Value = get_con_doc(this.Form.tdo_tdo.prop.Value)
          //   wait window nowait 'Asignando nuevo número'
          // asigna nuevo consecutivo
          this.Form.ndo_doc.Refresh
          const vi_lla1_doc = await select('vi_lla1_doc')
          // seleccionamos la vista

          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set ndo_doc=?  where recno=${Recno} `, [this.Form.ndo_doc.prop.Value])

          sw_asi = true
        } else {

          const vi_lla1_doc = await select('vi_lla1_doc')

          await tableRevert()

          //VFP  

          this.Form.cod_nom.prop.Valid = false
          this.Form.ndo_doc.prop.Valid = false
          return false

        } // End If 

      } else {

        const vi_lla1_doc = await select('vi_lla1_doc')

        await tableRevert()

        if (this.Form.tipoCaptura != 'IN') {
          this.Form.cod_nom.prop.Valid = false
        } // End If 

        this.Form.ndo_doc.prop.Valid = false
        return false

      } // End If 

    } // End while 

    const vi_lla1_nom = await select('vi_lla1_nom')
    // switch de asignación
    //!// do while  sw_gra .and. .not. dodefault('El documento')  && rutina general de grabación
    //!//  if .not. this.sw_nue         && si no es nuevo
    //!//   return .f.
    //!//  endif
    //!//
    //!//  if (num_err=2601 AND (m.ndb_emp=1 or m.ndb_emp=3)) OR (ndb_emp=4 AND num_err=7)&& si algien lo dio de alta primero
    //!//   if sw_asi .or. thisform.messagebox("Documento existente. Se asigna un nuevo número de documento ",4+32)=6 then
    //!//    wait window nowait 'Asignando nuevo número'
    //!//    thisform.ndo_doc.value=get_con_doc(thisform.tdo_tdo.value) && asigna nuevo consecutivo
    //!//    thisform.ndo_doc.refresh
    //!//    select vi_lla1_doc      && seleccionamos la vista
    //!//    replace ndo_doc with thisform.ndo_doc.value
    //!//    sw_asi=.t.
    //!//   else
    //!//    return .f.
    //!//   endif
    //!//  else
    //!//   return .f.
    //!//  endif
    //!// ENDDO

    // Inicio replace VFP
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set cop_nom=? , cod_nom=?  where recno=${Recno} `, [vi_lla1_doc.cop_nom, vi_lla1_doc.cod_nom])

    if (this.Form.tipoCaptura != 'IN') {
      // si no es documento de entrada o salida

      // es cliente de mostrador o proveedor varios
      if (((vi_lla1_doc.cop_nom == 'C' && vi_lla1_doc.cod_nom == Public.value.mos_pge) || (vi_lla1_doc.cop_nom == 'P' && vi_lla1_doc.cod_nom == Public.value.pva_pge) || vi_lla1_tdn.mos_tdn == 1)) {
        m = appendM(m, await scatter())// scatter 

        m.nom_mos = this.Form.d_nom_nom.prop.Value
        m.dir_mos = this.Form.d_dir_nom.prop.Value
        m.col_mos = this.Form.d_col_nom.prop.Value
        m.pob_mos = this.Form.d_pob_nom.prop.Value
        m.cpo_mos = this.Form.d_cpo_nom.prop.Value
        m.ext_mos = this.Form.d_ext_nom.prop.Value
        m.int_mos = this.Form.d_int_nom.prop.Value
        m.edo_edo = this.Form.d_edo_edo.prop.Value
        m.pai_mos = this.Form.d_pai_nom.prop.Value
        m.te1_mos = this.Form.d_te1_nom.prop.Value
        m.rfc_mos = this.Form.d_rfc_nom.prop.Value
        if (this.Form.sw_rfi) {
          m.rfi_mos = this.Form.d_rfi_nom.prop.Value
        } // End If 

        const vi_lla1_mos = await select('vi_lla1_mos')
        // abrimos vista de mostrador

        await requery()

        // nos traemos de nuevo los datos
        if (await recCount() == 0) {
          // si no hay datos de mostrador
          await localAlaSql(`INSERT INTO '+vi_lla1_mos+' FROM ?`, [m])

        } else {

          await gatherFrom(m)
          // graba de variables de memoria

        } // End If 


        super.vmo_doc('Código de mostrador ')
      } // End If 


    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')
    // graba campos xml   && solamente si no es un campo nuevo

    if (!sw_nue && this.Form.sw_xml && await recCount() > 0) {
      // hay campos xml
      this.Form.captura_xml.graba_xml('COMEDOC', vi_lla1_doc.key_pri)
    } // End If 

    return true

  }   // Fin Procedure



  // ----------------------------------------------------------------------------------------------
  //              siavcom software s. de r.l. de c.v.
  // ----------------------------------------------------------------------------------------------
  // autor     : ing. fernando cuadras angulo
  // sistema   : siavcom         version : 6.0  windows
  // programa  : mantenimiento a documentos mnemo   : come5101.scx
  // ult. mod. : fernando cuadras      fecha   : 15/05/99
  //              17/08/2006 fernando cuadras
  //              -- objeto: ndo_doc  evento :valid
  //               permitia cambiar un documento de solo cargo o abono que pertenecia a periodos anteriores
  //              --  21/Feb/2008 Fernando Cuadras     No tomaba la aplicacion del impuesto 3
  //     -- 29 Ags 2022. - Se quita el recorrido de todos los controles y se deja solo el con_con
  // ----------------------------------------------------------------------------------------------
  // tipo de captura
  override async init() {

    const tip_cap = this.Params[0]
    const mod_emp = this.Params[1]
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result

    this.Form.KeyPreview = true
    this.Form.tipoCaptura = tip_cap
    if (this.Form.Params.length == 2) {
      this.Form.mod_emp = mod_emp
    } // End If 

    //this.HelpContextID=iif(this.prop.Valid=='VE',51012,iif(this.prop.Valid=='PC',51013,iif(this.prop.Valid=='PP',51015,iif(this.prop.Valid=='CO',51014,5101))))
    // Open Data &bas_dat Shared 

    //select(0)

    switch (true) {
      case tip_cap == 'VE':
        // ventas
        this.Form.prop.Help_url = 'help/Archivos/Ventas/Mantenimiento/DOCUMENTOS/documentos.html'
        this.Form.prop.Caption = 'Documentos de ventas'
        this.Form.captura_movi.RemoveObject('c_fec_mov')
        // removemos columnas de fecha
        this.Form.captura_movi.RemoveObject('c_fme_mov')
        // de entregas de pedidos
        this.Form.captura_movi.RemoveObject('c_cen_mov')
        // cantidad entregada de pedidos
        this.Form.captura_movi.RemoveObject('c_tba_tba')
        // Trabajador
        await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND cop_nom = 'C' .And.nmo_tdo > 0 AND inv_tdo != 'P' AND ! ( inv_tdo = 'E' AND tra_tdo = 1 ) Order By coa_tdo Desc , des_tdo NOFILTER`)
        //Readwrite

        await localAlaSql(`INSERT INTO comeped select * From vi_cap_cometdo Where cop_nom = 'C' .And.nmo_tdo > 0 AND inv_tdo = 'P' Order By des_tdo`)

        this.Form.cod_nom.prop.InputMask = Public.value.icl_pge
        this.Form.RemoveObject('tba_tba')
        this.Form.RemoveObject('d_nom_tba')
        this.Form.RemoveObject('pga_pga')
        this.Form.ult_ele = 'ale_doc'
        this.Form.captura_movi.ult_campo = 'obs_mov'
        m.cop_nom = 'C'
        break
      case tip_cap == 'CO':
        // compras
        this.Form.prop.Help_url = 'help/Archivos/Compras/Mantenimiento/documentos%20de%20compra/documentos%20compras.html'
        this.Form.Caption = 'Documentos de compras'

        this.Form.captura_movi.RemoveObject('c_fec_mov')
        // removemos columnas de fecha
        this.Form.captura_movi.RemoveObject('c_fme_mov')
        // de entregas de pedidos
        this.Form.captura_movi.RemoveObject('c_cen_mov')
        // cantidad entregada de pedidos
        this.Form.captura_movi.RemoveObject('c_tba_tba')
        // Trabajador

        //  this.Form.datos_cliente.prop.Caption = this.Form.traduce('Datos proveedores')

        this.Form.cod_nom.prop.InputMask = Public.value.ipr_pge
        this.Form.RemoveObject('tba_tba')
        this.Form.RemoveObject('d_nom_tba')
        this.Form.RemoveObject('pga_pga')
        this.Form.ult_ele = 'ped_ped'
        this.Form.captura_movi.ult_campo = 'obs_mov'
        this.Form.ale_doc.style.top = 218
        this.Form.als_doc.style.top = 218
        this.Form.ped_ped.style.top = 218
        await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND cop_nom = 'P' .And.nmo_tdo > 0 AND inv_tdo != 'P' AND ! ( inv_tdo = 'E' AND tra_tdo = 1 ) AND tdo_tdo != 'PT' Order By coa_tdo , des_tdo`)
        //Readwrite

        await localAlaSql(`INSERT INTO comeped select * From vi_cap_cometdo Where cop_nom = 'P' AND nmo_tdo > 0 AND inv_tdo = 'P' Order By des_tdo`)

        m.cop_nom = 'P'
        this.Form.con_con.prop.Caption = 'Recoleción'
        break
      case tip_cap == 'IN' || tip_cap == 'PG':
        // inventario o presupuestos de gasto
        this.Form.prop.Help_url = 'help/Archivos/inventarios/mantenimiento/Entradas%20y%20salidas/ENTRADAS%20Y%20SALIDAS.html'
        this.Form.captura_movi.RemoveObject('c_des_mov')
        // removemos objetos del detalle
        this.Form.captura_movi.RemoveObject('c_fec_mov')
        this.Form.captura_movi.RemoveObject('c_fme_mov')
        this.Form.captura_movi.RemoveObject('c_cen_mov')
        // cantidad entregada de pedidos
        this.Form.captura_movi.RemoveObject('c_obs_mov')
        // Observaciones
        if (tip_cap == 'IN') {
          // removemos todos los datos de los trabajadores
          this.Form.prop.Caption = this.Form.traduce('Entradas y salidas')
          this.Form.prop.Caption = 'Entradas y salidas'
          this.Form.captura_movi.RemoveObject('c_dpe_mov')
          this.Form.captura_movi.RemoveObject('c_npe_mov')
          this.Form.captura_movi.RemoveObject('c_mpe_mov')
          this.Form.captura_movi.RemoveObject('c_tba_tba')
          // Trabajador
          this.Form.RemoveObject('tba_tba')
          this.Form.RemoveObject('d_nom_tba')
          this.Form.RemoveObject('pga_pga')
          this.Form.captura_movi.ult_campo = 'pve_mov'
        } else {

          //  tip_cap='PG'
          this.Form.prop.Caption = this.Form.traduce('Entregas y recepción')
          this.Form.captura_movi.c_dpe_mov.prop.Caption = 'Aut.'
          this.Form.captura_movi.RemoveObject('c_ped_ped')
          // Pedimento
          this.Form.captura_movi.RemoveObject('c_pve_mov')
          // Precio de venta
          this.Form.captura_movi.ult_campo = 'uni_mov'
          // ultimo campo de captura
        } // End If 

        this.Form.RemoveObject('cod_nom')
        // removemos objetos del header
        this.Form.RemoveObject('d_nom_nom')
        this.Form.RemoveObject('con_con')
        this.Form.RemoveObject('d_noc_con')
        this.Form.RemoveObject('d_dir_nom')
        this.Form.RemoveObject('d_ext_nom')
        this.Form.RemoveObject('d_int_nom')
        this.Form.RemoveObject('d_pob_nom')
        this.Form.RemoveObject('d_edo_edo')
        this.Form.RemoveObject('d_col_nom')
        this.Form.RemoveObject('d_pai_nom')
        this.Form.RemoveObject('d_te1_nom')
        this.Form.RemoveObject('d_cpo_nom')
        this.Form.RemoveObject('d_rfc_nom')
        this.Form.RemoveObject('d_des_tdn')
        this.Form.RemoveObject('d_lis_nom')
        this.Form.RemoveObject('fve_doc')
        // Thisform.fve_doc.Visible=.F.


        //  this.Form.RemoveObject('Datos_cliente')

        if (tip_cap == 'PG') {
          this.Form.d_imp_doc.prop.Visible = false
          this.Form.d_im0_doc.prop.Visible = false
          this.Form.d_im1_doc.prop.Visible = false
          this.Form.d_im2_doc.prop.Visible = false
          this.Form.d_im3_doc.prop.Visible = false
          this.Form.d_im4_doc.prop.Visible = false
          this.Form.d_im5_doc.prop.Visible = false
          this.Form.Total.prop.Visible = false
          this.Form.d_tot_doc.prop.Visible = false
          Result = await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND nmo_tdo > 0 AND inv_tdo$'ES' AND pga_tdo = 1 AND ! ( inv_tdo = 'E' AND tra_tdo = 1 ) AND ! cop_nom$'CP' ORDER By des_tdo`)
          //Readwrite

        } else {

          Result = await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND nmo_tdo > 0 AND inv_tdo$'ES' AND ! ( inv_tdo = 'E' AND tra_tdo = 1 ) AND ! cop_nom$'CP' ORDER By des_tdo`)
          // Readwrite

        } // End If 

        if (tip_cap == 'PG') {
          //select(0)

          await useNodata('vi_lla1_tba') // use vi_lla1_tba vi_lla1_tba Nodata
          // tabla de trabajadores

          //select(0)

          await useNodata('vi_lla1_tpe') // use vi_lla1_tpe vi_lla1_tpe Nodata
          // tabla de presupuesto de gasto

          this.Form.ult_ele = 'ale_doc'
        } else {

          this.Form.ult_ele = 'ped_ped'
        } // End If 

        break
      case tip_cap == 'PC':
        // pedidos clientes
        this.Form.prop.Help_url = 'help/Archivos/Ventas/Mantenimiento/PEDIDOS%20DE%20CLIENTES/PEDIDOS%20DE%20CLIENTESS.html'
        this.Form.prop.Caption = this.Form.traduce('Ordenes de compra y pedidos de clientes')

        this.Form.ale_doc.prop.Visible = false
        this.Form.captura_movi.RemoveObject('c_tba_tba')
        // Trabajador
        this.Form.captura_movi.RemoveObject('c_dpe_mov')
        this.Form.captura_movi.RemoveObject('c_npe_mov')
        this.Form.captura_movi.RemoveObject('c_mpe_mov')
        this.Form.captura_movi.RemoveObject('c_ser_mov')
        this.Form.captura_movi.RemoveObject('c_ped_ped')
        this.Form.captura_movi.c_can_mov.prop.Caption = 'Can.Pedida'
        this.Form.captura_movi.c_can_mov.style.width = 75
        this.Form.captura_movi.c_cen_mov.style.width = 75
        await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND cop_nom = 'C' AND nmo_tdo > 0 AND inv_tdo = 'P' Order By des_tdo`)
        //Readwrite

        this.Form.cod_nom.prop.InputMask = Public.value.icl_pge
        this.Form.RemoveObject('tba_tba')
        this.Form.RemoveObject('d_nom_tba')
        this.Form.RemoveObject('pga_pga')
        this.Form.RemoveObject('ped_ped')
        this.Form.ult_ele = 'als_doc'
        this.Form.captura_movi.ult_campo = 'obs_mov'
        // ultimo campo de captura
        break
      case tip_cap == 'PP':
        // pedidos proveedores
        this.Form.prop.Help_url = 'help/Archivos/Compras/Mantenimiento/pedidos%20de%20proveedores/PEDIDOS%20DE%20PROVEEDORES.html'
        this.prop.Caption = this.Form.traduce('Ordenes de compra y pedidos a proveedores')
        this.Form.als_doc.prop.Visible = false
        this.Form.captura_movi.RemoveObject('c_dpe_mov')
        this.Form.captura_movi.RemoveObject('c_npe_mov')
        this.Form.captura_movi.RemoveObject('c_mpe_mov')
        this.Form.captura_movi.RemoveObject('c_ser_mov')
        this.Form.captura_movi.RemoveObject('c_tba_tba')
        // Trabajador
        this.Form.captura_movi.RemoveObject('c_ped_ped')
        this.Form.captura_movi.c_can_mov.header1.prop.Caption = 'Can.Pedida'
        this.Form.captura_movi.c_can_mov.style.width = 75
        this.Form.captura_movi.c_cen_mov.style.width = 75
        await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND cop_nom = 'P' AND nmo_tdo > 0 AND inv_tdo = 'P' Order By des_tdo`)
        //ENE/2022
        //Thisform.la_con_con.Visible=.F.   && deshabilitamos consignatarios
        //Thisform.con_con.Visible=.F.
        //Thisform.d_noc_con.Visible=.F.
        //Readwrite

        this.Form.cod_nom.prop.InputMask = Public.value.ipr_pge
        this.Form.RemoveObject('tba_tba')
        this.Form.RemoveObject('d_nom_tba')
        this.Form.RemoveObject('pga_pga')
        this.Form.RemoveObject('ped_ped')
        this.Form.ult_ele = 'ale_doc'
        this.Form.captura_movi.ult_campo = 'obs_mov'
        // ultimo campo de captura
        //  this.Form.datos_cliente.prop.Caption = this.Form.traduce('Datos proveedores')
        break
      case tip_cap == 'AE':
        // Autorizaciones extraordinarias
        this.Form.prop.Help_url = 'help/Archivos/Ventas/Mantenimiento/PEDIDOS%20DE%20CLIENTES/PEDIDOS%20DE%20CLIENTESS.html'
        // pedidos clientes
        this.prop.Caption = this.Form.traduce('Autorizaciones extraordinarias al presupuestos')
        this.Form.captura_movi.c_dpe_mov.prop.Caption = 'Aut.'
        this.Form.d_imp_doc.prop.Visible = false
        this.Form.d_im0_doc.prop.Visible = false
        this.Form.d_im1_doc.prop.Visible = false
        this.Form.d_im2_doc.prop.Visible = false
        this.Form.d_im3_doc.prop.Visible = false
        this.Form.d_im4_doc.prop.Visible = false
        this.Form.d_im5_doc.prop.Visible = false
        this.Form.Total.prop.Visible = false
        this.Form.d_tot_doc.prop.Visible = false
        this.Form.captura_movi.RemoveObject('c_dpe_mov')
        //    thisform.captura_movi.removeobject('c_tba_tba') && Trabajador
        this.Form.captura_movi.RemoveObject('c_npe_mov')
        this.Form.captura_movi.RemoveObject('c_mpe_mov')
        this.Form.captura_movi.RemoveObject('c_ser_mov')
        this.Form.captura_movi.RemoveObject('c_ped_ped')
        this.Form.captura_movi.c_pve_mov.prop.Visible = false
        this.Form.captura_movi.RemoveObject('c_des_mov')
        this.Form.captura_movi.c_can_mov.header1.prop.Caption = 'Cantidad'
        this.Form.captura_movi.c_can_mov.style.width = 75
        this.Form.captura_movi.c_cen_mov.style.width = 75
        await localAlaSql(`INSERT INTO cometdo select * From vi_cap_cometdo Where sta_tdo = 'A' AND pga_tdo = 1 AND nmo_tdo > 0 AND inv_tdo = 'P' Order By des_tdo`)
        //Readwrite

        this.Form.RemoveObject('cod_nom')
        this.Form.RemoveObject('d_nom_nom')
        this.Form.RemoveObject('con_con')
        this.Form.RemoveObject('d_noc_con')
        this.Form.RemoveObject('d_dir_nom')
        this.Form.RemoveObject('d_ext_nom')
        this.Form.RemoveObject('d_int_nom')
        this.Form.RemoveObject('d_pob_nom')
        this.Form.RemoveObject('d_edo_edo')
        this.Form.RemoveObject('d_col_nom')
        this.Form.RemoveObject('d_pai_nom')
        this.Form.RemoveObject('d_te1_nom')
        this.Form.RemoveObject('d_cpo_nom')
        this.Form.RemoveObject('d_rfc_nom')
        this.Form.RemoveObject('d_des_tdn')
        this.Form.RemoveObject('d_lis_nom')
        this.Form.RemoveObject('fve_doc')
        this.Form.als_doc.prop.Visible = false
        this.Form.ale_doc.prop.Visible = false
        this.Form.ped_ped.prop.Visible = false
        //select(0)

        await useNodata('vi_lla1_tba') // use vi_lla1_tba vi_lla1_tba Nodata
        // tabla de trabajadores

        //select(0)

        await useNodata('vi_lla1_tpe') // use vi_lla1_tpe vi_lla1_tpe Nodata
        // tabla de presupuesto de gasto

        //  this.Form.RemoveObject('Datos_cliente')
        this.Form.ult_ele = 'als_doc'
        this.Form.captura_movi.ult_campo = 'uni_mov'
      // ultimo campo de captura
    } // End case 

    //select(0)

    await useNodata('vi_lla1_seg') // use vi_lla1_seg vi_lla1_seg Nodata
    // tabla de seguridad por grupos

    await rev_seg_doc()
    //////////////////////////////////////////////
    // cambiamos por rutina de seguridad

    const cometdo = await select('cometdo')

    await goto('TOP')

    this.Form.tdo_tdo.prop.Value = cometdo.tdo_tdo
    this.Form.tdo_tdo.prop.Value = 1
    // Set Null Off 

    //select(0)

    await useNodata('vi_lla1_tdo') // use vi_lla1_tdo vi_lla1_tdo Nodata
    // tabla de tipos de documentos

    //select(0)

    await useNodata('vi_lla1_ven') // use vi_lla1_ven vi_lla1_ven Nodata
    // tabla de vendedores

    //select(0)
    //Select 0
    //Use vi_lla1_tca Nodata          && tabla de claves alternas ordenada por codigo

    await useNodata('vi_lla1_mos') // use vi_lla1_mos vi_lla1_mos Nodata
    // tabla de clientes de mostrador

    const cam_arc = afields()

    let sw_mos = ascan(cam_arc, 'EXT_MOS')
    //select(0)

    await useNodata('vi_lla1_nom') // use vi_lla1_nom vi_lla1_nom Nodata
    // tabla de clientes y proveedores


    //------
    if (tip_cap == 'VE' || tip_cap == 'CO' || tip_cap == 'PC' || tip_cap == 'PP') {
      const cam_arc = afields()

      // buscamos si tiene el campo de numero de exterior
      if (ascan(cam_arc, 'EXT_NOM') > 0 && sw_mos > 0) {
        this.fac_ele = true
        // tenemos facturacion electronica
        this.Form.d_dir_nom.style.width = 344
        //193
        this.Form.dir_nom.prop.Caption = 'Calle:'
        //  thisform.dir_nom.visible=.f.
        this.Form.d_ext_nom.prop.Visible = true
        this.Form.d_int_nom.prop.Visible = true
        else {

          this.fac_ele = false
          // tenemos facturacion electronica
          this.Form.RemoveObject('d_ext_nom')
          //  thisform.cal_nom.visible=.f.
          this.Form.RemoveObject('d_int_nom')
          // End If 

          if ((tip_cap == 'PC' || tip_cap == 'VE') && ascan(cam_arc, 'RFI_NOM') == 0) {
            // no tiene campo de regimen fiscal
            this.Form.RemoveObject('d_rfi_nom')
            this.Form.sw_rfi = false
          } else {

            this.Form.sw_rfi = true
          } // End If 

        } // End If 

        //select(0)
        //-----

        await useNodata('vi_lla1_tdn') // use vi_lla1_tdn vi_lla1_tdn Nodata
        // tabla de tipos de clientes y proveedores

        //select(0)

        await useNodata('vi_lla1_unn') // use vi_lla1_unn vi_lla1_unn Nodata
        // tabla de tipos de clientes y proveedores

        //select(0)

        await useNodata('vi_lla1_doc') // use vi_lla1_doc vi_lla1_doc Nodata
        // tabla de documentos para darle mantenimiento

        // CursorSetProp ( "Buffering" , 5 ) 
        // Bloqueo optimista por tabla

        this.Form.sw_dre_doc = true
        // 27/Dic/2021
        //Thisform.tdr_doc.Visible=.F.
        //Thisform.ndr_doc.Visible=.F.
        //select(0)

        this.Form.Use('vi_cap_comemov', 'nodata', 'vi_cap_comemov', 'tdo_tdo=?m.tdo_tdo and ndo_doc=?m.ndo_doc', 'MOV_MOV')
        this.Form.captura_movi.prop.RecordSource = 'vi_cap_comemov'
        //Use vi_cap_comemov  Nodata           && tabla de captura movimientos
        // asignamos la tabla de captura de movimientos
        //select(0)
        // Nos traemos los almacenes que no estan el la tabla comedal (documentos por almacen)

        let ins_sql = 'select *  from man_cometda where not exists(select key_pri from vi_cap_comedal where man_cometda.alm_tda=vi_cap_comedal.alm_tda)'
        if (await SQLExec(ins_sql, 'vi_cap_cometda') < 0) {
          //select(0)

          await use('vi_cap_cometda', m) // use vi_cap_cometda vi_cap_cometda

        } // End If 

        Result = await localAlaSql(`INSERT INTO cometda_ent select * FROM vi_cap_cometda Order By des_tda NOFILTER`)
        // tabla de almacenes

        Result = await localAlaSql(`INSERT INTO cometda_sal select * FROM vi_cap_cometda Order By des_tda NOFILTER`)
        // tabla de almacenes

        this.Form.als_doc.prop.RowSource = 'cometda_sal.des_tda,alm_tda'
        this.Form.als_doc.prop.RowSourceType = 2
        this.Form.als_doc.Refresh
        this.Form.ale_doc.prop.RowSource = 'cometda_ent.des_tda,alm_tda'
        this.Form.ale_doc.prop.RowSourceType = 2
        this.Form.ale_doc.Refresh
        if (Public.value.usu_alm > '  ') {
          this.Form.ale_doc.prop.Value = Public.value.usu_alm
          this.Form.als_doc.prop.Value = Public.value.usu_alm
        } else {

          this.Form.ale_doc.prop.Value = cometda_ent.alm_tda
          this.Form.als_doc.prop.Value = cometda_sal.alm_tda
        } // End If 

        const est_tab = afields()

        // obtiene su estructura y numero de elementos
        if (ascan(est_tab, 'MUB_TDA') > 0) {
          // Si no tiene el campo lo borra de la tabla de captura
          this.Form.MUB_TDA = true
        } // End If 

        //select(0)

        await useNodata('vi_lla1_mov') // use vi_lla1_mov vi_lla1_mov Nodata
        //Alias tabla       && tabla de actualización de movimientos

        //select(0)

        await useNodata('vi_lla1_con') // use vi_lla1_con vi_lla1_con Nodata
        // tabla de consignatarios

        //select(0)

        await useNodata('vi_lla1_isu') // use vi_lla1_isu vi_lla1_isu Nodata
        // tabla de insumos

        const cam_arc = afields()

        // Buscamos campo
        Public.value.sw_imp = true

        await useNodata('vi_lla1_ped') // use vi_lla1_ped vi_lla1_ped Nodata

        await useNodata('vi_lla1_tar') // use vi_lla1_tar vi_lla1_tar Nodata

        await useNodata('vi_cap_comemen') // use vi_cap_comemen vi_cap_comemen Nodata

        await useNodata('vi_ver_npe') // use vi_ver_npe vi_ver_npe Nodata

        await useNodata('vi_lla1_xml') // use vi_lla1_xml vi_lla1_xml Nodata

        await useNodata('vi_lla1_doc', 'ver_documentos') // use vi_lla1_doc vi_lla1_doc Nodata Alias

        await useNodata('vi_lla1_lot') // use vi_lla1_lot vi_lla1_lot Nodata

        await useNodata('vi_cap_comefim') // use vi_cap_comefim vi_cap_comefim Nodata

        await useNodata('vi_cap_cometcd') // use vi_cap_cometcd vi_cap_cometcd Nodata

        await localAlaSql(`INSERT INTO cometcd select * From vi_cap_cometcd`)

        await useNodata('vi_lla1_emb') // use vi_lla1_emb vi_lla1_emb Nodata
        // datos de embarque y recepcion

        await useNodata('vi_lla1_seg') // use vi_lla1_seg vi_lla1_seg Nodata

        if (tip_cap != 'VE' && tip_cap != 'PC') {
          // si no es captura de clientes
          this.Form.RemoveObject('d_nom_ven')
          this.Form.RemoveObject('ven_ven')
          // End If 

          if (tip_cap != 'VE') {
            // removemos los objetos diferentes a ventas de clientes

            this.Form.RemoveObject('uso_sat')
            this.Form.RemoveObject('mpa_sat')
            this.Form.RemoveObject('npa_doc')
            this.Form.RemoveObject('tpa_doc')
            this.Form.RemoveObject('rpa_doc')
            this.Form.RemoveObject('fip_doc')
            this.Form.RemoveObject('fpa_sat')
            this.Form.RemoveObject('tre_sat')
            this.Form.RemoveObject('tdr_doc')
            this.Form.RemoveObject('ndr_doc')
          } else {

            this.Form.RemoveObject('ped_ped')
          } // End If 

          if (tip_cap == 'VE' || tip_cap == 'PC') {
            //select(0)

            m.cam_sat = 'RFI_SAT'
            m.par_sat = '  '
            await use('vi_comesat', m, 'rfi_nom') // use vi_comesat vi_comesat
            m.cam_sat = 'FPA_SAT'
            m.par_sat = '  '
            await use('vi_comesat', m, 'formas_pago') // use vi_comesat vi_comesat
            m.cam_sat = 'MPA_SAT'
            m.par_sat = '  '
            await use('vi_comesat', m, 'metodos_pago') // use vi_comesat vi_comesat
            m.cam_sat = 'USO_SAT'
            m.par_sat = '  '
            await use('vi_comesat', m, 'uso_sat') // use vi_comesat vi_comesat
            m.cam_sat = 'TRE_SAT'
            m.par_sat = '  '
            await use('vi_comesat', m, 'tipo_relacion') // use vi_comesat vi_comesat
            await appendBlank()

            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set des_sat=?  where recno=${Recno} `, ['Ninguna'])

            await goto('BOTTOM')

            //select(0)

            await localAlaSql(`INSERT INTO docto_relacion select tdo_tdo , des_tdo , coa_tdo From cometdo Where cop_nom = 'C' AND coa_tdo = 'C' AND cer_CER > '  '`)

          } else {

            this.Form.RemoveObject('d_rfi_nom')
            this.Form.sw_rfi = false
          } // End If 

          this.Form.captura_movi.c_uni_mov.RemoveObject('uni_mov_ANT')
          //Thisform.captura_movi.c_uni_mov.uni_mov.ControlSource=vi_cap_comemov.med_mov

          ////////// aumentado para generar el documento de un archivos xml
          if (this.prop.Valid == 'CO') {
            //select(0)

            await useNodata('vi_lla4_tca') // use vi_lla4_tca vi_lla4_tca Nodata
            // tabla de claves alternas ordenada por codigo pve. para cargar xml's

          } // End If 

          let nom_cur = 'pgexml'
          //// obtenemos datos xml de comepge
          m.nom_tab = 'COMEPGE'
          m.key_xmd = 1
          if (await select(nom_cur) > 0) {
            await select(nom_cur)

            releaseUse() // use 

          } // End If 

          const vi_lla1_xmd = await select('vi_lla1_xmd')
          //Select vi_lla1_obt_xmd   && obtiene los valores
          // obtiene los valores

          let num_ele = 0
          await requery()

          // lee de la base de datos
          if (await recCount() > 0) {
            if (allTrim(xml_xmd) > ' ') {
              Xmltocursor(xml_xmd, nom_cur)
            } // End If 

          } // End If 

          //select(0)
          ////////// fin de lo aumentado para generar documento desde archivo xml
          // Cambiamos descripciones de las etiquetas de la forma

          m.nom_tab = this.Form.prop.Name
          m.par_dxm = tip_cap
          await use('vi_cap_comedxm', m) // use vi_cap_comedxm vi_cap_comedxm

          for (const nom_con of this.Form.Controls) {
            // busca si el caption de ca/control es diferente segun su tipo de captura
            // 29 Ags 2022. - Se modifica el recorrido de todos los controles

            // ejemplo : SE CAMBIAS LAS ETIQUETSA DE CONSIGANTARIOS
            await goto('TOP')

            // VFP LOCATE For upper(allTrim(nom_con.prop.Name))=upper(allTrim(var_dxm)) && len(allTrim(nom_con.prop.Name))=len(allTrim(var_dxm))
            const result = await locateFor(` upper(allTrim(nom_con.prop.Name))=upper(allTrim(var_dxm)) && len(allTrim(nom_con.prop.Name))=len(allTrim(var_dxm))`)
            const data = await currentValue('vi_cap_comedxm')
            if (found()) {
              nom_con.prop.Caption = data.val_dxm
            } // End If 

          } // End For; 

          await goto('TOP')
          ////////////////////////// lectura de propiedades

          // VFP LOCATE For upper(var_dxm)='DOC_BLO'
          result = await locateFor(` upper(var_dxm)='DOC_BLO'`)

          if (found()) {
            this.Form.doc_blo = allTrim(val_dxm)
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='ASK_CON'
          await locateFor(` upper(var_dxm)='ASK_CON'`)

          if (found()) {
            this.Form.ask_con = iif(allTrim(val_dxm) == '1', true, false)
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='CAL_EXI'
          await locateFor(` upper(var_dxm)='CAL_EXI'`)

          if (found()) {
            this.Form.cal_exi = allTrim(val_dxm)
            // limite inferior
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='EXI_ALM'
          await locateFor(` upper(var_dxm)='EXI_ALM'`)

          if (found()) {
            this.Form.exi_alm = allTrim(val_dxm)
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='DOC_SUR'
          // docto de surtido
          await locateFor(` upper(var_dxm)='DOC_SUR'`)

          if (found()) {
            this.Form.doc_sur = allTrim(val_dxm)
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='MAX_PED'
          // solo permite surtir el maximo del pedido
          await locateFor(` upper(var_dxm)='MAX_PED'`)

          if (found()) {
            this.Form.max_ped = allTrim(val_dxm)
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='DIA_PED'
          // Dias para calculo maximo a pedir SHEL
          await locateFor(` upper(var_dxm)='DIA_PED'`)

          if (found()) {
            this.Form.dia_ped = val(allTrim(val_dxm))
          } // End If 

          await goto('TOP')

          // VFP LOCATE For upper(var_dxm)='DOC_PED'
          // Son los docto de pedidos donde se valida can maxima pedida SHEL
          await locateFor(` upper(var_dxm)='DOC_PED'`)

          if (found()) {
            this.Form.doc_ped = allTrim(val_dxm)
          } // End If 


          // generamos los documentos que se permite surtido
          if (this.prop.Valid == 'CO' || this.prop.Valid == 'VE') {
            await localAlaSql(`INSERT INTO comeped select * From vi_cap_cometdo Where cop_nom = m.cop_nom AND nmo_tdo > 0 AND ( inv_tdo = 'P' OR At ( tdo_tdo , this.Form.doc_sur ) > 0 ) Order By des_tdo`)

          } // End If 

          //select(0)

          await useNodata('vi_lla1_dxm') // use vi_lla1_dxm vi_lla1_dxm Nodata

          // =ini_diccionario(this.Form, 'comedoc') traducion a lenguajesç

        }   // Fin Procedure
      }
    }
  }
  // Inserta un registro en blanco en la tabla en movimeintos
  // Lectura de los datos del insumo
  async lee_isu() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
  }   // Fin Procedure
  /*
    // Obtiene el precio si hay politica de precios
    // Metodo  :obten_precio
    // Pertenece :COME5101
    // Comentarios :obtiene precio de clientes o proveedores
    async obten_precio_old() {
      let m = { ...this.Form.mPublic };  // Inicializamos m
      let Alias = '';   //Inicializamos Alias
      let Recno = 0;   //Inicializamos Recno
      let Result = [];   //Inicializamos Result
      if (this.Form.prop.key == 27) {
        return .T
  
      } // End If 
  
      m.key_pri = vi_cap_comemov.key_pri
      m.cla_isu = vi_cap_comemov.cla_isu
      m.timestamp = vi_cap_comemov.Timestamp
      let can_mov_old = vi_cap_comemov.can_mov
      let pve_mov_old = vi_cap_comemov.pve_mov
      let des_mov_old = vi_cap_comemov.des_mov
      let de1_mov_old = vi_cap_comemov.de1_mov
      let de2_mov_old = vi_cap_comemov.de2_mov
      let de3_mov_old = vi_cap_comemov.de3_mov
      let de4_mov_old = vi_cap_comemov.de4_mov
      let de5_mov_old = vi_cap_comemov.de5_mov
      let dse_mov_old = vi_cap_comemov.dse_mov
      let med_mov_old = vi_cap_comemov.med_mov
      let uni_mov_old = vi_cap_comemov.uni_mov
      let obs_mov_old = vi_cap_comemov.obs_mov
      let tba_tba_old = vi_cap_comemov.tba_tba
      let ped_ped_old = vi_cap_comemov.ped_ped
      const vi_lla1_doc = await select('vi_lla1_doc')
      //vi_ver_npe
  
      m.tdo_tdo = vi_lla1_doc.tdo_tdo
      //se quito el scatter memvar ya que daba problemas actualizando el KEY_PRI de movimientos
      m.ndo_doc = vi_lla1_doc.ndo_doc
      m.fec_mov = vi_lla1_doc.fec_doc
      let par_sql = vi_cap_comemov.cla_isu + "',?m.tdo_tdo,?m.ndo_doc,'" + vi_lla1_doc.cop_nom + "','" + iif(this.Form.cal_exi == 'SI', vi_lla1_doc.cod_nom, 'NO EXI') + "','" + str(vi_lla1_doc.con_con) + "',null,0"
      // exec   P_OBT_DAT_ISU 'NAR-030  ',null,null,'C','001002',0
      switch (true) {
        case Public.value.ndb_emp == 1 || Public.value.ndb_emp == 3:
          // Si es MSSQL o Sybase
          let ins_sql = "exec P_OBT_DAT_ISU_GEN '" + par_sql
          // ins_sql="exec P_OBT_DAT_ISU_GEN '"+vi_cap_comemov.cla_isu+"',?m.tdo_tdo,?m.ndo_doc,'"+vi_lla1_doc.cop_nom+"','"+vi_lla1_doc.cod_nom+"','"+Str(vi_lla1_doc.con_con)+"',null,0"
          break
        case Public.value.ndb_emp == 4:
          // Si PostgreSQL
          ins_sql = "select * from P_OBT_DAT_ISU_GEN ('" + par_sql + ")"
      } // End case 
  
      let a = ins_sql
      if (await SQLExec(ins_sql, 'sqlresult') < 0) {
        err_sql()
        Cancel
        const vi_cap_comemov = await select('vi_cap_comemov')
  
        return false
  
      } // End If 
  
      const sqlresult = await select('sqlresult')
  
      if (await recCount('sqlresult') == 0 || sqlresult.resultado == 0 || isNull(sqlresult.resultado)) {
        return false
        // no hay datos
  
      } // End If 
  
      m = appendM(m, await scatter())// scatter 
      // leelos el resultado de la consulta
  
      if (len(allTrim(m.men_err)) > 0) {
        this.Form.MessageBox(m.men_err, 0, 'Advertencia', 5000)
      } // End If 
  
      const vi_cap_comemov = await select('vi_cap_comemov')
      // regrabamos con los datos nuevos
      // actualizacion de datos en captura de  movimiento
  
      if (await recNo('vi_cap_comemov') < 1 || vi_cap_comemov.cla_isu != await oldValue('vi_cap_comemov.cla_isu')) {
        // si es renglon nuevo o cambio la clave
        m.sw_tca = NVL(m.sw_tca, 0)
        await gatherFrom(m)
        // grabamos todos los datos nuevos
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.sw_tca=?  where recno=${Recno} `, [Nvl(vi_cap_comemov.sw_tca, 0)])
  
  
        // se quito 12/oct/2017
        // replace key_pri WITH m.key_pri
        // replace timestamp WITH m.timestamp
        if (vi_cap_comemov.npe_mov > 0 || (vi_cap_comemov.cla_isu != await oldValue('vi_cap_comemov.cla_isu') && await recNo('vi_cap_comemov') > 0)) {
          // cambio de clave
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.can_mov=?  where recno=${Recno} `, [can_mov_old])
          // regresamos valores viejos
  
          if (vi_cap_comemov.npe_mov > 0) {
            // si viene de un pedido conservamos sus valores
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.pve_mov=?  where recno=${Recno} `, [pve_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.des_mov=?  where recno=${Recno} `, [des_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.de1_mov=?  where recno=${Recno} `, [de1_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.de2_mov=?  where recno=${Recno} `, [de2_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.de3_mov=?  where recno=${Recno} `, [de3_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.de4_mov=?  where recno=${Recno} `, [de4_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.de5_mov=?  where recno=${Recno} `, [de5_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.dse_mov=?  where recno=${Recno} `, [dse_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.med_mov=?  where recno=${Recno} `, [med_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.uni_mov=?  where recno=${Recno} `, [uni_mov_old])
  
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.obs_mov=?  where recno=${Recno} `, [obs_mov_old])
  
            // Inicio replace VFP
            // replace vi_cap_comemov.ped_ped WITH ped_ped_old
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set vi_cap_comemov.tba_tba=?  where recno=${Recno} `, [tba_tba_old])
  
          } // End If 
  
        } // End If 
  
      } else {
        // si hay descripcion de paso
        // If m.dpa_isu=1    &&.And. (Isnull(vi_lla1_isu.dea_isu) .Or. Len(Ltrim(vi_lla1_isu.dea_isu))=0)
        //  Replace vi_cap_comemov.dse_mov With  Rtrim(m.des_isu)
        // Endif
        // Replace vi_cap_comemov.dse_mov With m.dea_isu
  
        // si ya era un dato capturado toma los datos de las variables de memoria
        // Inicio replace VFP
        // remplazo de campos de captura AUXILIARES
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.uni_mov=?  where recno=${Recno} `, [m.uni_mov])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pv1_isu=?  where recno=${Recno} `, [m.pv1_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pv2_isu=?  where recno=${Recno} `, [m.pv2_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pv3_isu=?  where recno=${Recno} `, [m.pv3_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pv4_isu=?  where recno=${Recno} `, [m.pv4_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.pv5_isu=?  where recno=${Recno} `, [m.pv5_isu])
  
        // Inicio replace VFP
        //!//  Replace vi_cap_comemov.mon_isu With m.mon_isu
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.fa2_isu=?  where recno=${Recno} `, [m.fa2_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.fa3_isu=?  where recno=${Recno} `, [m.fa3_isu])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.exi_alm=?  where recno=${Recno} `, [m.exi_alm])
  
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_cap_comemov.uni_mov=?  where recno=${Recno} `, [uni_mov_old])
  
  
        // Select vi_lla1_pro
        if (m.tin_tti == 'P') {
          // si es un producto lee sus datos
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.pes_pro=?  where recno=${Recno} `, [m.pes_pro])
  
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.vol_pro=?  where recno=${Recno} `, [m.vol_pro])
  
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.cst_isu=?  where recno=${Recno} `, [m.cst_isu])
  
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.prr_pro=?  where recno=${Recno} `, [m.prr_pro])
  
          // Inicio replace VFP
          //  Replace vi_cap_comemov.pu1_pro With m.pu1_pro
          //  Replace vi_cap_comemov.mo1_pro With m.mo1_pro
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.pim_pro=?  where recno=${Recno} `, [m.pim_pro])
  
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_cap_comemov.sse_pro=?  where recno=${Recno} `, [m.sse_pro])
  
        } // End If 
  
      } // End If 
  
      this.Form.d_exi_pro.Refresh
      //cal_exi_gen(m.cla_isu,m.fec_mov,m.alm_usu,m.ped_ped,m.ser_mov,m.cod_nom)
      m.exi_pro = m.exi_alm
      //m.alm_tda=m.alm_usu
      if ((m.pre_alm > 0 && m.pre_alm >= m.exi_pro) || (m.min_alm > 0 && m.min_alm <= m.exi_pro)) {
        this.Form.MessageBox('Producto con poca existencia. Favor de resurtir', 0, 'Advertencia', 5000)
      } // End If 
  
      if (m.dst_isu > ' ') {
        // mensaje que esta en registro de comeisu
        this.Form.MessageBox(m.dst_isu, 0, '', 5000)
      } // End If 
  
      if (at(allTrim(vi_lla1_doc.tdo_tdo), this.Form.exi_alm) > 0) {
        // busca si el documento tiene calculo de existencias
        if (vi_cap_comemov.tin_tti == 'P') {
          const router = useRouter();
          router.push({ name: 'formas\exi_alm', params: { Param1: vi_cap_comemov.cla_isu, Param2: vi_cap_comemov.des_isu, Param3: vi_cap_comemov.fec_mov } })
  
        } // End If 
  
      } // End If 
  
      const vi_cap_comemov = await select('vi_cap_comemov')
  
      return true
  
    }   // Fin Procedure
  
  */

  // Reviza los permisos que tiene los grupos de usuarios en uno de los objetos

  // Metodo  :rev_per
  // Pertenece :COME5101
  // Comentarios :
  async rev_per(nom_cam, sw_mov) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.Params.length == 1) {
      let sw_mov = false
    } // End If 

    if (this.Form.sw_cie_per && nom_cam != 'IPR') {
      // si es un documento que es anterior al cierre y no es una impresión
      return false

    } // End If 


    // si es el adminstrador o se dio password de autorización
    if (Public.value.log_usu == 'ADMIN' || this.Form.sw_aut) {
      return true

    } // End If 

    let pos = ascan(this.Form.nom_obj, upper(Left(nom_cam, 3)))
    // busca el nombre del objeto en el arreglo nom_cam
    if (pos > 0) {
      // si encuentra el campo
      if (this.Form.nom_obj(pos + 1) == '1' || this.Form.nom_obj(pos + 1) == '3') {
        // permite Modifica o Captura y modifica
        return true

      } // End If 

      // reviza si se permite la captura
      if (this.Form.nom_obj(pos + 1) >= '2' && ((!sw_mov && this.Form.sw_nue) || (sw_mov && await recNo('vi_cap_comemov') < 0))) {
        return true

      } // End If 


      // si permite la captura es impresión pero no se a impreso
      if (this.Form.nom_obj(pos + 1) == '2' && nom_cam == 'IPR' && vi_lla1_doc.sta_doc != 'I' && vi_lla1_doc.sta_doc != 'T') {
        return true

      } // End If 

    } // End If 

    return false

  }   // Fin Procedure

  async obtInsumo(d_cla_isu: string) {
    const cla_isu = d_cla_isu.trim()
    if (this.dat_isu[cla_isu]) {
      console.log('1) OBT_DAT_ISU_GEN this.dat_isu=', this.dat_isu[cla_isu])
      return this.dat_isu[cla_isu]
    }

    const mem = {
      cla_isu: cla_isu,
      cod_nom: this.cod_nom.prop.Value,
      tip_tdn: this.tip_tdn,
      cop_nom: 'C',
      con_con: null
    }

    //  const med_mov = await this.Sql.localAlaSql(`select med_mov from vi_cap_comecpy where recno = ${this.Recno}`)
    //   const med_mov = await this.Sql.scatter(  ['med_mov'], 'vi_cap_comecpy')


    const par_sql = ` '${mem.cla_isu}',null,null,'${mem.cop_nom}','${mem.cod_nom}',${mem.con_con},'${mem.tip_tdn}',0 `
    let data = []

    // console.log('1) OBT_DAT_ISU_GEN sql=', `exec P_OBT_DAT_ISU_GEN ${par_sql}`)

    if (this.Sql.session.dialect == 'mssql')
      data = await SQLExec(`exec P_OBT_DAT_ISU_GEN ${par_sql}`)
    else
      data = await SQLExec(`select * from P_OBT_DAT_ISU_GEN(${par_sql})`)

    console.log('1) OBT_DAT_ISU_GEN data=', data)
    if (data[0].resultado == 0)
      return data[0]


    const dat_isu = await objToLowerCase(data[0])
    dat_isu['fvi_tca'] = "1900-01-01";
    dat_isu['ppa_tca'] = 0


    const Pub = this.mPublic

    const m = { ...dat_isu, ...Pub }

    /************************************* */

    const fac_isu = [0, 0, 0, 0]
    fac_isu[1] = 1
    fac_isu[2] = m.fa2_isu
    fac_isu[3] = m.fa3_isu

    const uni_isu1 = [0, 0, 0, 0]
    uni_isu1[1] = m.un1_isu
    uni_isu1[2] = m.un2_isu
    uni_isu1[3] = m.un3_isu

    const pve_isu = [0, 0, 0, 0, 0, 0]
    // asignamos precios de venta
    pve_isu[1] = m.pv1_isu
    pve_isu[2] = m.pv2_isu
    pve_isu[3] = m.pv3_isu
    pve_isu[4] = m.pv4_isu
    pve_isu[5] = m.pv5_isu

    const vmo_pge = [0, 0, 0, 0, 0, 0]

    vmo_pge[1] = 1
    vmo_pge[2] = m.va2_pge
    vmo_pge[3] = m.va3_pge
    vmo_pge[4] = m.va4_pge
    vmo_pge[5] = m.va5_pge


    const d = await this.Sql.scatter(['mco_pry'], 'vi_cap_comepry')

    for (let pre = 1; pre <= 5; pre++) {
      pve_isu[pre] = pve_isu[pre] * vmo_pge[m.mon_isu] / vmo_pge[d.mco_pry] // precio a moneda de cotizacion del proyecto
      //  console.log("2) obtInsumo pre=", pre, pve_isu[pre])
    }

    dat_isu.pv1_isu = pve_isu[1]
    dat_isu.pv2_isu = pve_isu[2]
    dat_isu.pv3_isu = pve_isu[3]
    dat_isu.pv4_isu = pve_isu[4]
    dat_isu.pv5_isu = pve_isu[5]

    if (dat_isu.sw_tca == 1) {  // busca en la tabla de tca el precio pactado
      const res = await SQLExec(`select cast(getdate() as date) as fpo_pge,fvi_tca,ppa_tca from  man_cometca where cla_tca ='${m.cla_isu}' \
        and cop_nom='${m.cop_nom}' and cod_nom='${m.cod_nom}' and fpo_pge<=fvi_tca `)
      console.log("2) obtInsumo res=", res)
      if (res[0].length > 0 && res[0].fvi_tca) {
        dat_isu['fvi_tca'] = res[0]['fvi_tca']
        dat_isu['ppa_tca'] = res[0]['ppa_tca']
      } else
        dat_isu.sw_tca == 0
    }

    dat_isu.pve_mov = m.pve_mov  // * (vmo_pge[m.mon_isu] / vmo_pge[d.mco_pry])
    dat_isu.prr_pro = m.prr_pro / vmo_pge[m.mon_isu]  //*  (vmo_pge[m.mon_isu] / vmo_pge[d.mco_pry])  // actualizamos el precio de reposicion segun su medida
    dat_isu.cst_isu = m.cst_isu / vmo_pge[m.mon_isu] //* (vmo_pge[m.mon_isu] / vmo_pge[d.mco_pry])

    this.dat_isu[cla_isu] = dat_isu

    return dat_isu

  }



  //metodo
}

