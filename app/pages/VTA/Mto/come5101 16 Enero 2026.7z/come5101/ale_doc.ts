//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : ale_doc
// Description : Componente ale_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////

export class ale_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";
    this.prop.Caption = "Almacén de entrada";
    this.prop.Caption = "Almacen donde entra la mercancia";
    this.prop.Multiselect = false;
    this.prop.BoundColumn = 2;
    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "200,20";
    this.prop.ControlSource = "vi_lla1_doc.ale_doc";
    this.prop.RowSource = "cometda_ent.des_tda,alm_tda";
    this.prop.RowSourceType = 2;
    this.prop.Style = 2;
    this.prop.TabIndex = 39;
    this.prop.ToolTipText = "Entra al almacen";
    this.prop.Value = '  ';
    this.style.width = '156px';

    //propiedades
  }

  // Evento   :init
  // Objeto  :ale_doc
  // Tipo   :ComboBox
  // Comentarios :Dependiendo de la versión deshabilita el control
  override async init() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.tip_ver == 'L') {
      this.prop.Visible = false
    } // End If 
  }   // Fin Procedure

  // Evento   :lostFocus
  // Objeto  :ale_doc
  // Tipo   :ComboBox
  // Comentarios :
  //if .not. thisform.ped_ped.visible
  async lostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when
    } // End If 

  }   // Fin Procedure

  // Evento   :Valid
  // Objeto  :ale_doc
  // Tipo   :ComboBox
  // Comentarios :
  override async valid(sw_rel: boolean) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const cometdo = seletArea('cometdo')
    if (cometdo.tra_tdo == 1 && this.Form.als_doc.prop.Value == this.prop.Value && (this.Form.mub_tda == false || cometda_ent.mub_tda == 0)) {
      MessageBox('No se permite que un traspaso tenga el mismo almacen de entrada y salida')
      return false
    } // End If 

    return true
  }   // Fin Procedure

  // Evento   :When
  // Objeto  :ale_doc
  // Tipo   :ComboBox
  // Comentarios :Compone la la llave principal
  // si es documento de entrada o es un traspaso o es un pedido de provedor
  // y esta habilitado
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const cometdo = currentValue('*', 'cometdo')
    if ((cometdo.inv_tdo == 'E' || cometdo.tra_tdo == 1 || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'P')) && this.prop.Visible) {
      if (await this.Form.rev_per(this.prop.Name)) {
        // manda revizar permisos
        return true

      } else {

        this.valid()

        return false

      } // End If 

    } // End If 

    this.prop.Valid = true
    this.Form.captura_movi.when()
    return false

  }   // Fin Procedure

  //metodo
}