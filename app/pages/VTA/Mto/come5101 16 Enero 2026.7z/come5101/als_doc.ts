//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : als_doc
// Description : Componente als_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class als_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";
    this.prop.Name = "Almacen de salida";
    this.prop.Caption = "Almacen donde sale la mercancia";
    this.prop.Multiselect = false;
    this.prop.BoundColumn = 2;
    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "200,20";
    this.prop.ControlSource = "vi_lla1_doc.als_doc";
    this.prop.RowSource = "cometda_sal.des_tda,alm_tda";
    this.prop.RowSourceType = 2;
    this.prop.Style = 2;
    this.prop.TabIndex = 38;
    this.prop.ToolTipText = "Sale del almacen";
    this.style.width = '156px';

    //propiedades
  }
  // Evento   :init
  // Objeto  :als_doc
  // Tipo   :ComboBox
  // Comentarios :Dependiendo de la versión deshabilita el control
  override async init() {
    if (this.Form.tip_ver == 'L') {
      this.prop.Visible = false
    } // End If 

  }   // Fin Procedure

  // Evento   :lostFocus
  // Objeto  :als_doc
  // Tipo   :ComboBox
  // Comentarios :
  // si continua la captura ejecuta detalle
  //if .not. thisform.ale_doc.visible .and. .not. thisform.ped_ped.visible  
  //
  async lostFocus() {
    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when
    } // End If 

  }   // Fin Procedure

  // Evento   :Valid
  // Objeto  :als_doc
  // Tipo   :ComboBox
  // Comentarios :Compone la la llave principal
  override async valid(sw_rel: boolean) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const cometda_sal = currentValue('*', 'cometda_sal')
    if (this.prop.Value.trim().length == 0) {
      this.prop.Value = cometda_sal.alm_tda
    } // End If 
    return true

  }   // Fin Procedure


  // Evento   :When
  // Objeto  :als_doc
  // Tipo   :ComboBox
  // Comentarios :Compone la la llave principal
  // si es documento de salida o es un pedido de clientes
  override async when() {
    const cometdo = currentValue('*', 'cometdo')
    if (cometdo.inv_tdo == 'S' || (cometdo.inv_tdo == 'P' && cometdo.cop_nom == 'C') || (cometdo.inv_tdo == 'P' && cometdo.pga_tdo == 1)) {
      if (await this.Form.rev_per(this.prop.Name)) {
        // manda revizar permisos
        return true

      } // End If 

      this.valid
    } // End If 

    if (cometdo.cop_nom == 'C' && cometdo.inv_tdo == 'N') {
      this.Form.captura_movi.when
    } // End If 

    return false

  }   // Fin Procedure

  //metodo
}