//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : Cancela_docto
// Description : Componente Cancela_docto
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class bt_cancela_docto extends IMGBUTTON {
  //public
  constructor() {
    super();

    this.prop.Caption = "Solicitud Cancelación";
    this.prop.Position = 'footer'

    //Left=161;
    this.prop.Image = distribuidoras\imagenesdist\png48x48\delete.png;
    this.style.width = '72px';

    //propiedades
  }

  // evento   :click
  // objeto  :cancela_docto
  // tipo   :buttom
  // comentarios :
  override async click() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await select('vi_lla1_doc')

    m = appendM(m, await scatter())// scatter 

    let status_doc = vi_lla1_doc.sta_doc
    if (await this.Form.rev_per('ndo_doc') && await recNo() > 0) {

      let res = 0
      if (m.sta_doc == 'T') {
        res = this.Form.MessageBox("Seguro que deseaa solicitar la CANCELACION de este CFDI ante el SAT", 4 + 32)
      } else {

        res = this.Form.MessageBox("Seguro que desea cancelar este documento", 4 + 32)
      } // End If 

      if (res != 6) {
        return

      } // End If 

      let are_tra = await select()

      let ins_sql = "select CAST(max(key_pri) as int) as key_pri from man_comepag where tia_pag='" + m.tdo_tdo + "' and nua_pag=" + str(m.ndo_doc)
      if (await SQLExec(ins_sql, 'resultado') < 0) {
        err_sql()
        return

      } // End If 

      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // Sqlcommit ( Public.value.num_dbs ) 

        await SQLExec("commit work;")

      } // End If 

      if (!isNull(key_pri) && await recCount() > 0) {
        this.Form.MessageBox("Tiene pagos asignados. No se puede dar de baja", 16, 'Error')
        releaseUse() // use 

        await select(are_tra)

        return

      } // End If 

      releaseUse() // use 

      let pge_xml = this.Form.captura_xml.obt_val('COMEPGE', 1, 'PGEXML')
      // obtiene campos xml
      await select(are_tra)

      if (!can_doc(m.tdo_tdo, m.ndo_doc)) {
        // procedimiento para cancelar documentos
        this.Form.MessageBox('No se pudo dar de baja documento. Favor de revisar ', 16, 'Error')
        return

      } // End If 

      const vi_lla1_doc = await select('vi_lla1_doc')

      await useNodata('vi_lla1_doc') // use vi_lla1_doc vi_lla1_doc Nodata

      this.Form.otro.click
    } // End If 

  }   // Fin Procedure



  // Evento   :keyPress
  // Objeto  :Cancela_docto
  // Tipo   :Buttom
  // Comentarios :
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    switch (true) {
      case (String.fromCharCode(nkeycode) == 'M' || String.fromCharCode(nkeycode) == 'm'):
        this.Form.captura_movi.columns(1).setFocus()
        break
      case (String.fromCharCode(nkeycode) == 'S' || String.fromCharCode(nkeycode) == 's'):
        this.Form.salir.click
    } // End case 

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :Cancela_docto
  // Tipo   :Buttom
  // Comentarios :
  // Modifi.  : 29/Jul/2004   Fernando Cuadras
  //                -Permitia cancelacion de documentos a pesar de no tener
  //                 habilitada la funcion
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (Public.value.log_usu == ('ADMIN     ')) {
      // si es el administrador
      return true
      // permite

    } // End If 

    let pos = ascan(this.Form.nom_obj, 'NDO')
    // si permite captura o modificacion
    if (pos > 0 && (this.Form.nom_obj(pos + 1) == '1' || this.Form.nom_obj(pos + 1) == '3')) {
      if (await this.Form.rev_per('CNC')) {
        // manda revizar permisos de cancelacion
        return true

      } // End If 

      return false

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}