//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : imgButton
// Class : dre_doc
// Description : Componente dre_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { IMGBUTTON } from "@/classes/imgButton";

import { IMGBUTTON } from "@/classes/imgButton";
//imports

export class bt_dre_doc extends IMGBUTTON {
  //public
  constructor() {
    super();


    this.prop.Caption = "Documentos relacionados ";
    this.prop.Position = 'footer'
    this.style.fontSize = '9px';
    this.style.height = '38px';
    //Left=526;
    this.style.width = '84px';

    //propiedades
  }

  // Evento   :Click
  // Objeto  :dre_doc
  // Tipo   :Buttom
  // Comentarios :
  //m.dre_doc=NVL(vi_lla1_doc.dre_doc,'')
  override async click() {

    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let result = [];   //Inicializamos Result
    const cometdo = await currentValue('*', 'cometdo')

    if (cometdo.coa_tdo == 'A' || cometdo.tip_cfd != 'I') {
      if (this.Form.MessageBox('Este documento comunmente se relaciona en el proceso de asignacion de pagos en cargos y abonos de cuentas por cobrar. Quieres relacionarlo aquÃ­?', 4 + 32) != 6) {
        return

      } // End If 

    } // End If 

    const tab_xml = await select('tab_xml')

    // VFP LOCATE FOR upper(var_dxm)='DRE_DOC'
    const tab_xml = await locateFor(` upper(var_dxm)='DRE_DOC'`)

    if (len(allTrim(tab_xml.val_dxm)) > 10) {
      m.dre_doc = tab_xml.val_dxm
      m.dre_doc = Strconv(m.dre_doc, 14)
    } else {

      await appendBlank()

      m.dre_doc = ''
      //   replace tab_xml.
    } // End If 

    m.doc_ant = m.dre_doc
    const router = useRouter();
    router.push({ name: 'formas/doc_rel', params: { Param1: m.dre_doc, Param2: vi_lla1_doc.cop_nom, Param3: vi_lla1_doc.cod_nom } })// tom.dre_doc

    if (m.dre_doc > '  ' || m.dre_doc != m.doc_ant) {
      if (len(allTrim(m.dre_doc)) > 10 || len(m.doc_ant) > 10) {
        const tab_xml = await select('tab_xml')

        // VFP LOCATE FOR upper(var_dxm)='DRE_DOC'
        result = await locateFor(` upper(var_dxm)='DRE_DOC'`)

        if (len(allTrim(m.dre_doc)) > 10) {
          if (!found()) {
            await appendBlank()

            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set ord_dxm=? , var_dxm=? , des_dxm=?  where recno=${Recno} `, [999, 'dre_doc', 'Documentos relacionados'])

          } // End If 

          m.dre_doc = Strconv(m.dre_doc, 13)
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set tab_xml.val_dxm=?  where recno=${Recno} `, [m.dre_doc])

        } else {

          if (found()) {
            // Inicio replace VFP
            Recno = await recNo()
            Alias = await alias()
            await localAlaSql(`update ${Alias} set tab_xml.val_dxm=?  where recno=${Recno} `, ["X"])

          } // End If 

        } // End If 

      } // End If 

      this.Form.sw_xml = true
      //   replace docxml.dre_doc WITH m.dre_doc
      //   SELECT vi_lla1_doc
      //   replace vi_lla1_doc.dre_doc WITH m.dre_doc
      this.Form.grabar()
    } // End If 

    return

  }   // Fin Procedure


  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.Cancela_docto.keyPress(nKeyCode, nShiftAltCtrl)
  }   // Fin Procedure



  // Evento   :When
  // Objeto  :Paridades
  // Tipo   :Buttom
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true

    // si no hay relacion, esta cancelado o timbado
    if (vi_lla1_doc.cop_nom != 'C' || len(allTrim(vi_lla1_doc.tre_sat)) == 0 || vi_lla1_doc.sta_doc == 'C' || vi_lla1_doc.sta_doc == 'T' || vi_lla1_doc.sta_doc == 'X') {
      return false

    } // End If 

    if (!this.Form.rev_per('TRE')) {
      // manda revizar permisos
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}