//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_cen_mov
// Description : Componente c_cen_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_cen_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_cap_comemov.cen_mov";
    this.prop.Value = 0;
    this.prop.ColumnTextLabel = "Can.Entregada";
    //propiedades
  }
  override async init() {
    this.prop.InputMask = ('9999,999.' + replicateString('9', Public.value.dci_pge));
    this.prop.Decimals = Public.value.dci_pge;
  }

  override async when() {
    if (await this.Form.rev_per(this.prop.Name, true)) {
      return true

    } // End If 

    this.prop.Valid = true

    return false

  }   // Fin Procedure


  //metodo
}