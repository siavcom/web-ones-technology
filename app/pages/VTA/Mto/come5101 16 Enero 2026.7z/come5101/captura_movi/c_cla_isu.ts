//////////////////////////////////////////////
// This class COMPONENT was generated automatically by web-ones-technology
// BaseClass : Component
// Class : cla_isu
// Description : CLAVE DEL INSUMO
// Author : El Fer Blocks
// Creation : 2024-03-21
// Update Date  : 
/////////////////////////////////////////////
///////////////////////////////////////
// base class
///////////////////////////////////////

import { COLUMN } from '@/classes/Column'
import { help } from '@/classes/Siavcom/help/cla_isu/help'
import { des_isu } from './c_des_isu'
//import { modal_com } from './detail_compra/modal_com'

export class c_cla_isu extends COLUMN {
  public help = new help()
  public des_isu = new des_isu()
  cla_isu: string = ''

  constructor() {
    super()

    this.prop.ColumnTextLabel = 'Insumo '
    this.prop.ControlSource = 'vi_cap_comemov.cla_isu'
    this.prop.MaxLength = 30
    this.prop.Help = true;
    this.prop.Capture = true
    this.prop.ErrorMessage = 'No existe la clave del insumo'
    this.inputStyle.width = "128px"// "218px" // Son 30 puntos del icono de ayuda
    this.style.width = "max-content"
    this.asignaRecno()
  }

  override async init() {
    this.prop.InputMask = this.Form.mPublic.ima_pge.trim()
  }


  override async when() {
    await super.when()
    if (this.cla_isu.trim() == '')
      this.cla_isu = this.prop.Value

    if (this.prop.ReadOnly) {
      return false
    }

    this.old_value = this.prop.Value
    //////////////////////////////////////
    let m = { ...this.Form.mPublic };  // Inicializamos m
    const vi_cap_comemov = await currentValue('*', 'vi_cap_comemov')

    if (this.Form.tipoCaptura == 'C0' || this.Form.tipoCaptura == 'VE') {
      this.Form.captura_movi.c_npe_mov.npe_mov.prop.Valid = true
      this.Form.captura_movi.c_mpe_mov.mpe_mov.prop.Valid = true
      this.Form.captura_movi.c_dpe_mov.dpe_mov.prop.Valid = true
    } // End If 

    if (await this.Form.rev_per(this.prop.Name, true)) {
      // manda revizar permisos
      return true

    } else

      this.gotFocus()
    this.prop.Valid = true
    return false

    //////////////


  }   // Fin Procedure

  override async valid(old_data?: {}) {
    let sw_old = false
    if (old_data)
      sw_old = true


    if (this.old_value > ' ' && this.old_value == this.prop.Value)
      return true

    const cla_isu = this.prop.Value


    if (this.Parent.isi_cpy.prop.Value != 'S') {
      this.prop.Valid = true
      return true
    }
    if (cla_isu.length == 0) {
      return false
    }
    //    if (this.cla_isu.trim() == this.prop.Value.trim())
    //      return true


    const res = await this.Form.obtInsumo(cla_isu)

    if (res.resultado == 0) {
      return false
    }

    this.prop.Valid = true
    /*
        if (res.dea_isu.trim().length > 10) {
          this.des_isu.prop.Value = res.dea_isu
          this.Parent.detail_vta.modal_vta.des_isu.prop.Value = res.dea_isu
        }
        else {
          this.des_isu.prop.Value = res.des_isu
          this.Parent.detail_vta.modal_vta.des_isu.prop.Value = res.des_isu
        }
    */
    // actualizamos vista de actualizacion
    if (this.cla_isu != cla_isu) {// Si es otra clave o clave nueva

      const ins_sql = `update vi_cap_comecpy set cla_tca='${res.cla_tca}',dea_tca='${res.dea_tca}',\
       ppa_tca=${res.ppa_tca},fvi_tca='${res.fvi_tca}',un1_isu='${res.un1_isu}',\
       un2_isu='${res.un2_isu}',un3_isu='${res.un3_isu}',fa1_isu=1,fa2_isu=${res.fa2_isu},\
       fa3_isu=${res.fa3_isu} , pv1_isu=${res.pv1_isu},pv2_isu=${res.pv2_isu},pv3_isu=${res.pv3_isu},\
       pv4_isu=${res.pv4_isu},pv5_isu=${res.pv5_isu},prr_pro=${res.prr_pro},uni_mov='${res.un1_isu}', \
       med_mov=1,pve_mov=${res.pve_mov},mon_mov=${res.mon_isu} \
       where recno = ${this.Recno}`


      await this.Sql.localAlaSql(ins_sql)


      if (!old_data)
        old_data = {
          med_mov: 1,
          mon_mov: res.mon_isu,
          pve_mov: res.pve_mov
        }


    }

    const med_mov = ['', '', '', '']
    med_mov[1] = res.un1_isu
    med_mov[2] = res.un2_isu
    med_mov[3] = res.un3_isu

    const new_data = await this.Sql.scatter(['med_mov', 'mon_mov', 'pve_mov'], 'vi_cap_comecpy')

    if (!old_data)
      old_data = new_data

    const fac_isu = [0, 0, 0, 0]
    fac_isu[1] = 1
    fac_isu[2] = res.fa2_isu
    fac_isu[3] = res.fa3_isu

    const vmo_pge = [0, 0, 0, 0, 0, 0]
    vmo_pge[1] = 1
    vmo_pge[2] = this.Form.mPublic.va2_pge
    vmo_pge[3] = this.Form.mPublic.va3_pge
    vmo_pge[4] = this.Form.mPublic.va4_pge
    vmo_pge[5] = this.Form.mPublic.va5_pge

    // pasamos a la moneda del precio de venta que tiene el insumo
    if (old_data.pve_mov == 0) {
      old_data.pve_mov = res.pve_mov
      old_data.mon_mov = res.mon_isu
      new_data.mon_mov = res.mon_isu
    }
    let pve_mov = old_data.pve_mov

    if (old_data.mon_mov != new_data.mon_mov)
      pve_mov = old_data.pve_mov * vmo_pge[old_data.mon_mov] / vmo_pge[new_data.mon_mov]
    // pasamos el precio de venta a la unidad principal

    if (old_data.med_mov != new_data.med_mov)
      pve_mov = pve_mov / fac_isu[old_data.med_mov] * fac_isu[new_data.med_mov]

    pve_mov = await roundTo(pve_mov, this.Form.mPublic.dcp_pge)

    this.Form.grid_comecpy.med_mov.when() // = new_data.mon_mov
    await this.Sql.localAlaSql(`update vi_cap_comecpy set pve_mov=${pve_mov},mon_mov=${new_data.mon_mov} where recno = ${this.Recno}`)


    ///////////////////  Original
    //// Revisar si cuando viende ya de un pedido y se cambio la clave, revisar la funcion oldval
    // si cambio de clave
    const vi_cap_comemov = await currentValue('*', 'vi_cap_comemov')
    if (await recNo('vi_cap_comemov') < 1 || vi_cap_comemov.cla_isu != await oldValue('vi_cap_comemov.cla_isu')) {
      this.prop.Valid = false
      // apagamos validaciones
      //this.Form.tipoCaptura ->this.Form.tipoCaptura
      if (this.Form.tipoCaptura != 'PC' && this.Form.tipoCaptura != 'PP' && this.Form.tipoCaptura != 'PG') {
        this.Parent.c_ser_mov.ser_mov.prop.Valid = false
        this.Parent.c_ped_ped.ped_ped.prop.Valid = false
      } // End If 

      this.Parent.c_can_mov.can_mov.prop.Valid = false
      this.Parent.c_uni_mov.uni_mov.prop.Valid = false
      this.Parent.c_pve_mov.pve_mov.prop.Valid = false
      if (this.Form.tipoCaptura != 'IN') {
        this.Parent.Parent.c_des_mov.des_mov.prop.Valid = false
      } // End If 

      if (!this.Form.obten_precio()) {
        // obtiene el precio del cliente o proveedor
        this.Form.MessageBox('No existe la clave', 16, '', 5000)
        return false

      } // End If 

      let sw_sal = true
      if (await recNo('vi_cap_comemov') > 0) {
        // si no es un registro nuevo
        if (this.Form.tipoCaptura != 'PC' && this.Form.tipoCaptura != 'PP' && this.Form.tipoCaptura != 'PG') {
          sw_sal = this.Parent.Parent.c_ser_mov.ser_mov.valid()
          sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_ped_ped.ped_ped.valid())
        } // End If 

        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_can_mov.can_mov.valid())
        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_uni_mov.uni_mov.valid())
        sw_sal = iif(sw_sal == false, false, this.Parent.Parent.c_pve_mov.pve_mov.valid())
      } // End If 

      if (!sw_sal) {
        return false

      } // End If 

    } // End If 

    this.prop.Valid = true
    return true








    ///////////////////////
    if (!sw_old) {

      // this.Parent.detail_vta.modal_vta.pve_mov.prop.Value = res.pve_mov
      //this.Parent.detail_vta.modal_vta.med_mov.prop.Value = res.uni_mov
      //this.Parent.detail_vta.modal_vta.mon_mov.prop.Value = res.mon_isu

    }
    /*
        if (this.Parent.detail_vta.modal_vta.cla_isu.prop.Value != this.prop.Value)
          this.Parent.detail_vta.modal_vta.cla_isu.prop.Value = this.prop.Value
        if (this.Parent.detail_com.modal_com.cla_isu.prop.Value != this.prop.Value)
          this.Parent.detail_com.modal_com.cla_isu.prop.Value = this.prop.Value
    */



    return true
  }

}


