//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_fec_mov
// Description : Componente c_fec_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_fec_mov extends COLUMN {
  //public
  constructor() {
    super();

    this.prop.Type = 'date';
    this.prop.ControlSource = "vi_cap_comemov.fec_mov";
    this.prop.ColumnTextLabel = "Fecha Entrega";

    //propiedades
  }

  // evento   :valid
  // objeto  :pve_mov
  // tipo   :cuadro de texto
  // comentarios :se utilizan dos variables para la medida del producto
  override async valid(par_val) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const fac_isu = new Array(3)
    const pve_isu = new Array(5)
    const uni_isu1 = new Array(3)
    //,vmo_doc1(5)  && asignamos valores de las monedas
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      Return.T.
  } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    this.prop.Valid = false
    // busca si es un documento donde se valida cantidad pedida SHEL
    if (at(allTrim(vi_lla1_doc.tdo_tdo), this.Form.DOC_PED) == 0) {
      this.prop.Valid = true
      return true

    } // End If 

    if (this.prop.Value < vi_lla1_doc.fec_doc) {
      this.Form.MessageBox('La fecha no puede ser menor a la fecha del documento', 16, 'Error', 50000)
      return false

    } // End If 

    if (at(allTrim(vi_lla1_doc.tdo_tdo), this.Form.doc_ped) == 0 || this.Form.dia_ped == 0) {
      // SHEL
      this.prop.Valid = true
      return

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')
    // si no cambio de valor

    m = appendM(m, await scatter())// scatter 

    DIMENSIONfac_isu(3)
    fac_isu(1) = 1
    // asignamos factores de unidades
    fac_isu(2) = m.fa2_isu
    fac_isu(3) = m.fa3_isu
    m.fec_mov = this.prop.Value
    m.cla_isu = vi_cap_comemov.cla_isu
    m.alm_tda = vi_cap_comemov.alm_tda
    m.num_dias = this.Form.dia_ped
    m.can_mov = vi_cap_comemov.can_mov * fac_isu(vi_cap_comemov.med_mov)
    let ins_sql = ' select dbo.f_val_reo(?m.cla_isu,?m.fec_mov,?m.alm_tda,?m.num_dias,?can_mov) as men_err '
    // SHEL
    if (await SQLExec(ins_sql, 'val_reo') < 0) {
      err_sql()
      const vi_cap_comemov = await select('vi_cap_comemov')

      return false

    } // End If 

    let a = ins_sql
    const val_reo = await select('val_reo')

    m.men_err = val_reo.men_err
    if (len(allTrim(m.men_err)) > 1) {
      this.Form.MessageBox(m.men_err, 16, 'Error', 50000)
      return false



      this.prop.Valid = true
      return true

    }   // Fin Procedure



  // Evento   :When
  // Objeto  :fec_mov
  // Tipo   :Cuadro de texto
  // Comentarios :
override async when(){
      let m = { ...this.Form.mPublic };  // Inicializamos m
      let Alias = '';   //Inicializamos Alias
      let Recno = 0;   //Inicializamos Recno
      let Result = [];   //Inicializamos Result
      const vi_cap_comemov = await select('vi_cap_comemov')

      this.refresh
      if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
        return false
        //!//     IF key<>15
        //!//        KEYBOARD '{BACKTAB}'
        //!//     endif

      } // End If 

    }   // Fin Procedure


    //metodo
  }