//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : header
// Class : c_fme_mov
// Description : Componente c_fme_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_fme_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.Type = 'date';
    this.prop.ControlSource = "vi_cap_comemov.fme_mov";
    this.prop.ColumnTextLabel = "Limite de entrega";

    //propiedades
  }

  // Evento   :valid
  // Objeto  :fme_mov
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 


    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 

    if (this.prop.Value < this.Parent.c_fec_mov.fec_mov.prop.Value) {
      this.Form.MessageBox('Fecha maxima de entrega menor a fecha de entrega')
      this.prop.Valid = false
      return false

    } // End If 

    this.prop.Valid = true
    this.Parent.parent.rev_val()
    return true

    cedure



  // Evento   :When
  // Objeto  :fme_mov
  // Tipo   :Cuadro de texto
  // Comentarios :
override async when(){
      let m = { ...this.Form.mPublic };  // Inicializamos m
      let Alias = '';   //Inicializamos Alias
      let Recno = 0;   //Inicializamos Recno
      let Result = [];   //Inicializamos Result
      const vi_cap_comemov = await select('vi_cap_comemov')

      this.refresh
      if (this.Parent.c_cla_isu.cla_isu.prop.Valid != '1') {
        return false
        //!//     IF key<>15
        //!//        KEYBOARD '{BACKTAB}'
        //!//     endif

      } // End If 


      // en caso de que este valor sea menor al la fecha de entrega
      if (this.prop.Value < vi_cap_comemov.fec_mov) {
        this.prop.Value = vi_cap_comemov.fec_mov
      } // End If 

    }   // Fin Procedure


    //metodo
  }