//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_npe_mov
// Description : Componente c_npe_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_npe_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.ColumnTextLabel = "Número";
    this.prop.ControlSource = "vi_cap_comemov.npe_mov";
    this.prop.Max = "999999999";
    this.prop.Decimals = 0;
  }


  // evento   :valid
  // objeto  :npe_mov
  // tipo   :cuadro de texto
  // comentarios :verifica si existe el documento de pedido
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      return.t.
    } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 


    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name) && this.Parent.c_dpe_mov.dpe_mov.prop.Value != '  ') {
      return true

    } // End If 

    if (this.prop.Value == 0) {
      // si el valor es igual a cero limpia dcto del pedido
      this.Parent.c_dpe_mov.dpe_mov.prop.Value = '  '
    } // End If 


    // si tiene todos los valores de pedido
    if (vi_cap_comemov.dpe_mov != '  ' && this.prop.Value != 0) {

      // si tiene el valor del movimiento del pedido
      if (vi_cap_comemov.mpe_mov != 0) {

        // va ha validar el pedido completo
        if (this.Parent.c_mpe_mov.mpe_mov.valid()) {
          this.Parent.parent.rev_val()
          return true

        } else {

          return false

        } // End If 

      } // End If 

      m.tdo_tdo = vi_cap_comemov.dpe_mov
      m.ndo_doc = this.prop.Value
      const ver_documentos = await select('ver_documentos')
      // si no tiene valor el movimiento del pedido
      // selecciona pedido para revizar que pertenesca al mismo

      await use('vi_lla1_docaliasver_documentos', m) // use vi_lla1_doc vi_lla1_doc
      // codigo de cliente o proveedor y consignatario

      const vi_cap_comemov = await select('vi_cap_comemov')

      if (await recCount('ver_documentos') == 0) {
        this.Form.MessageBox('No existe el número de pedido')
        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.npe_mov')
        } // End If 

        this.prop.Valid = false
        return falseó

      } // End If 

      if (this.Form.tipoCaptura != 'PG' && allTrim(this.Form.cod_nom.prop.Value) != allTrim(ver_documentos.cod_nom)) {
        this.Form.MessageBox('Código de cliente o proveedor diferente')
        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.npe_mov')
        } // End If ó

        this.prop.Valid = false
        return false

      } else {

        if (vi_lla1_doc.pga_pga != ver_documentos.pga_pga) {
          this.Form.MessageBox('La partida presupuestal es diferente a la de la autorización', 16, 'Error', 3600)
          this.prop.Valid = false
          return false

        } // End If 

      } // End If 

      if (this.Form.tipoCaptura != 'PG' && this.Form.con_con.prop.Value != ver_documentos.con_con) {
        this.Form.MessageBox('Código de consignatario diferente')
        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('vi_cap_comemov.npe_mov')
        } // End If 

        this.prop.Valid = false
        return false

      } // End If 

    } // End If 

    this.Form.npe_mov = this.prop.Value
    this.Parent.parent.rev_val()
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :npe_doc
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')


    this.Form.prop.key = 0

    //!// if this.readonly
    //!//  return .f.
    //!// endif
    if (len(allTrim(this.Parent.c_dpe_mov.dpe_mov.prop.Value)) == 0) {
      this.prop.Valid = true
      return false

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    if (await recNo() < 0 && this.prop.Value == 0) {
      // si es un movimiento nuevo
      this.prop.Value = this.Form.npe_mov
    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}