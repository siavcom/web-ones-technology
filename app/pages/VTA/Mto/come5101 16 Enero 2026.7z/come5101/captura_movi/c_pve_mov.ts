//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_pve_mov
// Description : Componente c_pve_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_pve_mov extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "t_textbox";


    this.style.backgroundColor = '234,234,234';
    this.prop.ColumnTextLabel = "Precio";
    this.style.fontSize = '8px';
    this.prop.Name = "c_pve_mov";

    this.style.alignment = '1';
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_cap_comemov.pve_mov";
    this.prop.Format = "K";
    this.prop.InputMask = ('99,999,999.' + replicateString('9', Public.value.dcp_pge));
    //Left=36;
    this.Seconds = 0;
    this.style.top = '38px';
    this.prop.Value = 0;

    //propiedades
  }

  // evento   :keypress
  // objeto  :pve_mov
  // tipo   :cuadro de texto
  // comentarios :
  override async keyPress(nkeycode, nshiftaltctrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const fac_isu = new Array(3)
    const pve_isu = new Array(5)
    //,vmo_doc1(5)  && asignamos valores de las monedas
    this.Form.prop.key = 0
    this.Form.prop.key = nkeycode
    if (!between(this.Form.prop.key, 65, 71) && !between(this.Form.prop.key, 65 + 32, 71 + 32)) {
      return

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    m = appendM(m, await scatter())// scatter 

    if (cometdo.cop_nom != 'C' && cometdo.cop_nom != 'P') {
      // si no afecta clientes se sale
    } // End If 
    // return

    fac_isu(1) = 1
    // obtiene familia de descuento
    //!//   if m.fde_pge>0 .and. cometdo.cop_nom='C' .and. (cometdo.inv_tdo='P' .or. this.parent.parent.c_npe_mov.npe_mov.value=0)
    //!//      pos_ini=iif(m.fde_pge=1,1,at('-',m.cla_isu,m.fde_pge-1)+1)
    //!//      pos_fin=at('-',m.cla_isu,m.fde_pge)-1
    //!//      if pos_fin<0
    //!//         pos_fin=len(rtrim(m.cla_isu))
    //!//       endif
    //!//      fam_isu=subs(m.cla_isu,pos_ini,pos_fin-pos_ini+1)
    //!//   endif
    fac_isu(2) = m.fa2_isu
    fac_isu(3) = m.fa3_isu
    pve_isu(1) = m.pv1_isu
    //!//   uni_isu1(1)=m.un1_isuó
    //!//   uni_isu1(2)=m.un2_isu
    //!//   uni_isu1(3)=m.un3_isuó
    // asignamos precios de venta
    pve_isu(2) = m.pv2_isu
    pve_isu(3) = m.pv3_isu
    pve_isu(4) = m.pv4_isu
    pve_isu(5) = m.pv5_isu
    let num_pre = nkeycode
    //  for pre=1 to 5   && no es un producto
    //     pve_isu(pre)=round(pve_isu(pre),m.dcp_pge)
    //  endfor
    if (num_pre > 70) {
      // si oprimio minusculas
      num_pre = num_pre - 32
    } // End If 

    if (String.fromCharCode(num_pre) > Public.value.pmv_pge) {
      // es mayor al precio minimo de venta
      return
      // no asigna precio de venta

    } // End If 

    if (num_pre < 70) {
      // si es un precio base
      this.prop.Value = pve_isu(num_pre - 64) * fac_isu(vi_cap_comemov.med_mov)
    } else {

      // consulta de precio reposición
      if (vi_cap_comemov.tin_tti == 'P') {
        // si es un producto
        this.Form.MessageBox('Precio reposición :' + transform(m.prr_pro, '$999,999,999.99999') + String.fromCharCode(13) + 'Costo estandar    :' + transform(m.cst_isu, '$999,999,999.99999'))
        if (cometdo.cop_nom == 'P') {
          this.prop.Value = pre_rep
          // asigna precio de reposicion
        } // End If 

      } // End If 

    } // End If 

    return

  }   // Fin Procedure



  // evento   :valid
  // objeto  :pve_mov
  // tipo   :cuadro de texto
  // comentarios :se utilizan dos variables para la medida del producto
  //
  // Gova 23/Ags/2021 PE 34
  // Cuando la lista de precio esta en cero pero hay precio de reposicion, No permitir precios menor
  // a reposicion
  override async valid(par_val) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const fac_isu = new Array(3)
    const pve_isu = new Array(5)
    const uni_isu1 = new Array(3)
    //,vmo_doc1(5)  && asignamos valores de las monedas
    const vi_cap_comemov = await select('vi_cap_comemov')

    let res = super.vmo_doc(true)
    if (res == 0) {
      // si se oprime tecla hacia arriba y es registro nuevo
      Return.T.
  } // End If 

    if (res == -1) {
      // si da tecla hacia abajo y es registro nuevo
      return false

    } // End If 

    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      // si no cambio el valor
      return true

    } // End If 


    // si el documento afecta clientes
    // y es un producto y no tiene autorizacion de modificacion
    if (cometdo.cop_nom == 'C' && ((Public.value.pmv_pge >= 'A' && Public.value.pmv_pge <= 'E') || Public.value.pmv_pge == 'S' || Public.value.pmv_pge == 'R') && vi_cap_comemov.tin_tti == 'P' && !this.Form.sw_aut) {
      const vi_cap_comemov = await select('vi_cap_comemov')

      m = appendM(m, await scatter())// scatter 

      fac_isu(1) = 1
      fac_isu(2) = m.fa2_isu
      fac_isu(3) = m.fa3_isu
      uni_isu1(1) = m.un1_isu
      uni_isu1(2) = m.un2_isu
      uni_isu1(3) = m.un3_isu
      pve_isu(1) = m.pv1_isu
      // asignamos precios de venta
      pve_isu(2) = m.pv2_isu
      pve_isu(3) = m.pv3_isu
      pve_isu(4) = m.pv4_isu
      pve_isu(5) = m.pv5_isu
      m.prr_pro = m.prr_pro * fac_isu(vi_cap_comemov.med_mov)
      // actualizamos el precio de reposicion segun su medida
      for (let pre = 1; pre < 5; pre++) {
        // calculamos precios de ventaó
        // si la politica de ventas es diferente a factor de ganancia o
        // no es un producto
        pve_isu(pre) = pve_isu(pre) * fac_isu(vi_cap_comemov.med_mov)
        // el precio ya viene convertido a la monedadel documento
        //     if m.pol_pge#'F' .or. m.tin_tti$'SE'
        //        pve_isu(pre)=pve_isu(pre)//vmo_doc1(m.mon_isu)/vmo_doc1(vi_lla1_doc.mon_doc)
        //     endif
        // actualizamos el precio segun su medida
        pve_isu(pre) = Round(pve_isu(pre), Public.value.dcp_pge)
        if (m.prr_pro > 0 && pve_isu(pre) == 0) {
          // si el precio de reposicion es mayor que cero y el precio de venta es = 0
          pve_isu(pre) = m.prr_pro
        } // End If 

      } // End For; 


      // reviza si hay precio minimo de venta y no es un precio por contrato
      // 26/10/2009 se aumenta    AND m.pmv_pge<='E'
      //  if (reccount('vi_lla1_tca')=0 or vi_lla1_tca.cla_isu#vi_cap_comemov.cla_isu  or 
      //vi_lla1_tca.ppa_tca=0 or vi_lla1_tca.fvi_tca<thisform.fec_doc.value) AND 
      //m.pmv_pge<='E'
      //  if (m.sw_tca=0 or vi_lla1_tca.cla_isu#vi_cap_comemov.cla_isu  or 
      //vi_lla1_tca.ppa_tca=0 or vi_lla1_tca.fvi_tca<thisform.fec_doc.value) AND 
      //m.pmv_pge<='E'
      // se quita ya que si sw_tca=1 tiene en precio pactado y no debe de validar
      //!//  if (vi_cap_comemov.sw_tca=1  and  (vi_cap_comemov.ppa_tca=0 or vi_cap_comemov.fvi_tca<thisform.fec_doc.value) AND 
      //                                   m.pmv_pge<='E'  )   OR 
      //
      if (vi_cap_comemov.sw_tca != 1 && (Public.value.pmv_pge <= 'E' || Public.value.pmv_pge == 'R')) {
        // no tiene claves alternas y el precio de ventas es menor al E
        if (Public.value.pmv_pge <= 'E' && this.prop.Value < pve_isu(asc(Public.value.pmv_pge) - 64) && pve_isu(asc(Public.value.pmv_pge) - 64) > 0) {
          this.Form.MessageBox('Precio no valido. precio minimo permitido :' + Transform(pve_isu(asc(Public.value.pmv_pge) - 64), "$###,###.#####"))
          if (await recNo('vi_cap_comemov') > 0) {
            // es un dato viejo
            await tableRevert()

          } else {

            this.prop.Value = pve_isu(asc(Public.value.pmv_pge) - 64)
          } // End If 

          return false

        } // End If 

        if (Public.value.pmv_pge == 'R' && (this.prop.Value < M.PRR_PRO || this.prop.Value == 0)) {
          // se aumenta que el precio no debe ser 0
          this.Form.MessageBox('Precio no valido. precio minimo permitido :' + Transform(M.PRR_PRO, "$###,###.#####"))
          if (await recNo('vi_cap_comemov') > 0) {
            // es un dato viejo
            await tableRevert()

          } else {

            this.prop.Value = m.prr_pro
          } // End If 

          return false

        } // End If 

      } // End If 
      //*************************************


      // si es un precio por contrato da la validacion como buena
      //   if reccount('vi_lla1_tca')>0  &&and vi_lla1_tca.ppa_tca>0 and vi_lla1_tca.fvi_tca>=thisform.fec_doc.value 
      //
      if (m.sw_tca == 1) {
        //and vi_lla1_tca.ppa_tca>0 and vi_lla1_tca.fvi_tca>=thisform.fec_doc.value 
        //
        this.prop.Valid = true
        // and this.value=vi_lla1_tca.ppa_tca
        this.Parent.Parent.rev_val()
        return true

      } // End If 


      // si hay politica de precios minimo de venta y el precio
      // minimo es igual a cero
      // 26/10/2009
      //02/9/2020 se comenta la siguiente linea ya que el precio ya viene convertido a la moneda
      // m.prr_pro=m.prr_pro/vi_lla1_doc.vmo_doc && convertimos el valor reposicion al valor de la moneda
      // si viene de un pedido no reviza el precio minimo de venta
      //  if vi_cap_comemov.dpe_mov<'  ' and  pve_isu(asc(m.pmv_pge)-64)>=1 .and. pve_isu(asc(m.pmv_pge)-64)<=5 .and. m.prr_pro>=this.value
      if (m.prr_pro >= this.prop.Value || m.prr_pro == 0) {
        this.Form.MessageBox('El precio de venta es menor o igual precio de reposición ')
        // de'+TRANSFORM(m.prr_pro,'$###,###,###.##'))
        if (m.prr_pro == 0) {
          return false

        } // End If 

      } // End If 

      if (m.prr_pro > this.prop.Value && Public.value.pmv_pge != 'N') {
        // si esta dentro del minimo permitido
        if (await recNo('vi_cap_comemov') > 0) {
          // es un dato viejo
          await tableRevert()

        } else {

          this.prop.Value = pve_isu(1)
          //    pve_isu(asc(m.pmv_pge)-64)
        } // End If 

        return false

      } // End If 

      if (m.cst_isu > this.prop.Value && Public.value.pmv_pge == 'S') {
        this.Form.MessageBox('El precio de venta es menor al costo estandar ')
        // de'+TRANSFORM(m.prr_pro,'$###,###,###.##'))
        if (await recNo('vi_cap_comemov') > 0) {
          // es un dato viejo
          await tableRevert()

        } else {

          this.prop.Value = pve_isu(1)
          //    pve_isu(asc(m.pmv_pge)-64)
        } // End If 

        return false

      } // End If 

    } // End If 

    this.prop.Valid = true
    this.Parent.Parent.rev_val()
    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :pve_mov
  // tipo   :cuadro de texto
  // modificacion : 30/ags/2004 -permitia captura de precios aun cuando se habia espesificado una politica
  //                                  por contrato
  // comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')



    //!//if this.parent.parent.c_cla_isu.cla_isu.tag#'1'
    //!//     IF key<>15
    //!//        KEYBOARD '{BACKTAB}'
    //!//     endif
    //!//  return .f.
    //!// endif
    // reviza si es un precio por contrato si existe en claves alternas y
    // tiene un precio por contrato vigente
    // si ya es un producto ya capturado anteriormente revizamos precios por contrato
    // 21/may/2007 if recno('vi_cap_comemov')>0 and (recno('vi_lla1_tca')<1 or vi_lla1_tca.cla_isu<>vi_cap_comemov.cla_isu) and (m.cop_nom='c' or m.cop_nom='p')
    //!//if (m.cop_nom='C' or m.cop_nom='P') and recno('vi_cap_comemov')>0 and recno('vi_lla1_tca')>0 and vi_lla1_tca.cla_isu<>vi_cap_comemov.cla_isu
    //!// //!//    thisform.obten_precio
    //!// //!//    select vi_lla1_tca
    //!// //!//    scatter MEMVAR memo
    //!//endif
    // y tambien reviza si es un precio por contrato  no permite la captura del precio
    //if reccount('vi_lla1_tca')>0  &&and vi_lla1_tca.ppa_tca>0 and vi_lla1_tca.fvi_tca>=thisform.fec_doc.value
    // 12/Jun/2014
    //if reccount('vi_lla1_tca')>0 AND RECCOUNT('vi_cap_comemov')<0
    if (vi_cap_comemov.sw_tca == 1 && !this.Form.sw_aut) {
      // AND RECCOUNT('vi_cap_comemov')<0
      this.valid
      //  this.gotfocus
      return false
      //  return .f.     && anterior .t. 27/abr/2007. si tiene un precio por contrato, no pregunta precio
      //  2/Sep/2020. si tiene un precio por contrato, no pregunta precio

    } // End If 


    // manda revizar permisos
    if (await this.Form.rev_per(this.prop.Name, true)) {
      return true

    } // End If 

    this.valid
    //  this.gotfocus
    return false

  }   // Fin Procedure


  //metodo
}