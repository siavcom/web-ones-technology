//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : t_textbox
// Class : c_ser_mov
// Description : Componente c_ser_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { help } from '@/classes/Siavcom/help/ser_mov/help'
import { COLUMN } from "@/classes/Column";
//imports

export class c_ser_mov extends COLUMN {
  //public
  public help = new help()

  constructor() {
    super();
    this.prop.ColumnTextLabel = "Serie o lote";
    this.prop.ControlSource = "vi_cap_comemov.ser_mov";
    this.style.fontSize = '8px';
    //propiedades
  }
  override async init() {
    this.prop.InputMask = (replicateString('X', len(vi_cap_comemov.ser_mov)));
  }
  // Evento   :keyPress
  // Objeto  :ser_mov
  // Tipo   :text
  // Comentarios :Busca los lotes o series existentes de un producto
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeyCode
    if (this.Form.prop.key > 0 && String.fromCharCode(this.Form.prop.key) == '?') {
      // consulta series o lotes activos
      //VFP  "" "" clear

      this.prop.Value = con_exi_ser(vi_cap_comemov.cla_isu, vi_cap_comemov.fec_mov, vi_cap_comemov.alm_tda)
    } // End If 
    // this.keypress(0)
    // keyboard '' clear          && limpia el teclado

  }   // Fin Procedure



  // evento   :valid
  // objeto  :ser_mov
  // tipo   :cuadro de texto
  // comentarios :verifica si existe el número de serie o lote
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await select('vi_cap_comemov')

    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 


    //if .not. (vi_lla1_pro.sse_pro$'SL') && 24/Abr/2015 se cambia
    if (!('SL'.indexOf(vi_cap_comemov.sse_pro))) {
      this.prop.Valid = true
      return true
    } // End If 

    m = appendM(m, await scatter())// scatter 

    this.prop.Valid = false
    if (len(lTrim(this.prop.Value)) == 0) {
      this.Form.MessageBox('Debe capturar la serie o lote del producto')
      return false

    } // End If 

    //select(0)

    let fec_con = m.fec_mov
    // fecha de consulta+"'"
    m.ser_mov = iif(vi_cap_comemov.sse_pro$'SL', vi_cap_comemov.ser_mov, 'null')
    //m.ser_mov=iif(vi_lla1_pro.sse_pro$'SL',vi_cap_comemov.ser_mov,'null')  && 24/Abr/2015 se cambia
    m.ped_ped = 'null'
    // pedimento
    m.alm_mov = iif(cometdo.inv_tdo == 'S' || vi_cap_comemov.sse_pro == 'L', vi_cap_comemov.alm_tda, 'null')
    // almacen
    m.cod_nom = iif(cometdo.cop_nom == 'C'.and.cometdo.inv_tdo == 'S', vi_lla1_doc.cod_nom, 'null')
    m.exi_pro = cal_exi_gen(m.cla_isu, m.fec_mov, m.alm_mov, m.ped_ped, m.ser_mov, m.cod_nom)
    // calcula existencia por serie
    if (cometdo.inv_tdo == 'E') {
      // si es una entrada
      const vi_cap_comemov = await select('vi_cap_comemov')
      // si ya tiene existencia y control por no serie
      // y es diferente su valor anterior de serie


      // if m.exi_pro>0 .and. vi_cap_comemov.sse_pro='E' .and. (rtrim(this.value)#rtrim(oldval('ser_mov')) or 
      //
      if (m.exi_pro > 0 && vi_cap_comemov.sse_pro == 'S' && (rTrim(this.prop.Value) != rTrim(await oldValue('ser_mov')) || isNull(await oldValue('ser_mov')))) {
        this.Form.MessageBox('No se puede dar entrada a un producto que ya existe')
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('ser_mov')
        } // End If 

        return false

      } // End If 

      if (vi_cap_comemov.sse_pro == 'L') {
        // manejo por lotes
        m.ser_mov = this.prop.Value
        const vi_lla1_lot = await select('vi_lla1_lot')

        await use('vi_lla1_lot', m) // use vi_lla1_lot vi_lla1_lot

        if (await recCount() == 0) {
          this.Form.MessageBox('No existe el lote ')
          if (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) {
            return false

          } // End If 

        } // End If 

      } // End If ó

    } else {

      if (m.exi_pro <= 0) {
        this.Form.MessageBox('No hay series o lotes para asignar')
        const vi_cap_comemov = await select('vi_cap_comemov')

        if (await recNo() > 0) {
          // si no es un registro nuevo
          this.prop.Value = await oldValue('ser_mov')
        } // End If 

        if (this.Form.prop.key == 13 || this.Form.prop.key == 9 || this.Form.prop.key == 19) {
          return false

        } // End If 

        return true

      } // End If 

    } // End If 

    this.prop.Valid = true
    if (vi_cap_comemov.sse_pro == 'S') {
      // si es manejo por serie unicamente permite 1
      this.Parent.c_can_mov.can_mov.prop.Value = 1
    } // End If 

    this.Form.d_exi_pro.prop.Value = m.exi_pro
    if (vi_cap_comemov.pim_pro == 1 && cometdo.inv_tdo == 'S') {
      // si es un producto importado y una salida
      let ins_sql = upper("select ped_ped from man_comemov JOIN man_COMETDO ON man_COMETDO.TDO_TDO=MAN_COMEMOV.TDO_TDO where cla_isu='" + m.cla_isu + "' and ser_mov='" + vi_cap_comemov.ser_mov + "' AND PED_PED>' ' AND SPI_MOV<>'D' AND man_COMETDO.INV_TDO='E' AND ALM_TDA='" + vi_cap_comemov.alm_tda + "'  ORDER BY FEC_MOV  ")
      // busca su pedimento
      if (await SQLExec(ins_sql, 'resultado') > 0) {
        // ejecuta instrucción sql
        if (await recNo() > 0) {
          const resultado = await select('resultado')

          m = appendM(m, await scatter())// scatter 

          releaseUse() // use 

          const vi_cap_comemov = await select('vi_cap_comemov')

        } else {

          m.exi_tot = 0
        } // End If 

      } else {

        err_sql()
        const vi_cap_comemov = await select('vi_cap_comemov')

        return false

      } // End If 

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_cap_comemov.ped_ped=?  where recno=${Recno} `, [m.ped_ped])

      if (Public.value.ndb_emp == 2) {
        // si es interbase
        // sqlcommit ( Public.value.num_dbs ) 

      } // End If 

    } // End If 

    const vi_cap_comemov = await select('vi_cap_comemov')

    this.prop.Valid = true
    this.Parent.parent.rev_val()
    // Inicio replace VFP
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set vi_cap_comemov.exi_alm=?  where recno=${Recno} `, [m.exi_pro])

    return true

  }   // Fin Procedure



  // evento   :when
  // objeto  :ser_mov
  // tipo   :cuadro de texto
  // comentarios :si es un producto con número de serie y es una entrada o salida
  // si no ha leido los datos del insumo los lee
  override async when() {

    const vi_cap_comemov = await currentValue('m', 'vi_cap_comemov')
    const cometdo = await currentValue('m', 'cometdo')

    if (this.Parent.c_cla_isu.cla_isu.prop.Valid != true) {
      return false

    } // End If 

    if (vi_cap_comemov.tin_tti != 'P') {
      // si no es un producto
      this.prop.Valid = true
      return false

    } // End If 


    // si es un producto y lleva número de serie y no es un producto
    // de importacion y es una etrada o salida
    if (vi_cap_comemov.tin_tti == 'P' && (vi_cap_comemov.sse_pro == 'S' || vi_cap_comemov.sse_pro == 'L') && cometdo.inv_tdo$'ES') {
      if (await this.Form.rev_per(this.prop.Name, true)) {
        // manda revizar permisos
        return true

      }

    } // End If 

    this.prop.Valid = true
    return false

  }   // Fin Procedure

  //metodo
}