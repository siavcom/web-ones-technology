//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : editBox
// Class : c_tba_tba
// Description : Componente c_tba_tba
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COLUMN } from "@/classes/Column";

import { COLUMN } from "@/classes/Column";
//imports

export class c_tba_tba extends COLUMN {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "editBox";

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_cap_comemov.tba_tba";
    this.prop.Help = true
    //Left=52;
    //propiedades
  }

  // evento   :valid
  // objeto  :tba_tab
  // tipo   :cuadro de texto
  // comentarios :es la validación de codigo del cliente o proveedor
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno

    // si no cambio de valor
    if (this.prop.Valid == true && this.prop.Value == await oldValue(this.prop.Name)) {
      return true

    } // End If 

    if (this.prop.Value == space(12)) {
      // si pidio ayuda
      this.prop.Valid = true
      return true
    } // End If 

    m.tba_tba = this.prop.Value
    // lee los datos generales del trabajador

    await use('vi_lla1_tba', m)

    if (await recCount() == 0) {
      this.Form.MessageBox('No existe trabajador', 16, 'Error', 3000)
      return false

    } // End If 

    m = appendM(m, await scatter())// scatter 
    const vi_lla1_tba = await currentValue('m', 'vi_lla1_tba')

    MessageBox(m.nom_tba)

    m.pga_pga = this.Form.pga_pga.prop.Value.allTrim()
    // si cambio de codigo o es un codigo nuevo o es un documento que tiene
    if (this.Form.tba_tba.prop.Value != this.prop.Value) {
      // si es entrga no es  a un supervisor
      if (left(vi_lla1_tba.pga_pga, len(allTrim(m.pga_pga))) != m.pga_pga) {
        this.Form.MessageBox('Trabajador fuera de area', 16, 'Error', 3000)
        return false

      } // End If 

    } // End If 

    m.cop_nom = 'T'
    m.cod_nom = this.prop.Value
    await use('vi_cap_comemen', m)
    // lee mensajes del trabajador
    // VFP SCAN 

    while (!eof('vi_cap_comemen')) {
      const vi_cap_comemen = await currentValue('*', 'vi_cap_comemen')
      this.Form.MessageBox('Mensaje No ' + str(vi_cap_comemen.num_men, 2) + ' :' + vi_cap_comemen.men_men)
      await skip()
    } // End while 

    await goto('TOP')

    if (m.est_tba == 'B') {
      let men_blo = 'Trabajador bloqueado, ' + String.fromCharCode(13)
      this.Form.MessageBox(men_blo)
      this.prop.Valid = false
      return false

    } // End If 

    if (this.Form.tba_tba.prop.Value != this.prop.Value) {
      // si no es entrga a un supervisor pone le presupuesto de gasto de trabajador
      m.pga_pga = vi_lla1_tba.pga_pga
    } // End If 

    select('vi_cap_comemov')

    // Inicio replace VFP
    //replace pga_pga WITH m.pga_pga
    Recno = await recNo()
    Alias = await alias()
    await localAlaSql(`update ${Alias} set pga_pga=?  where recno=${Recno} `, [m.pga_pga])

    this.prop.Valid = true
    // damos por bueno el dato
    return true

  }   // Fin Procedure

  // Evento   :When
  // Objeto  :tba_tba
  // Tipo   :Cuadro de texto
  // Comentarios :
  // si proviene de una autorización
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_cap_comemov = await currentValue('*', 'vi_cap_comemov')
    if (vi_cap_comemov.dpe_mov > '   ') {
      this.valid
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}