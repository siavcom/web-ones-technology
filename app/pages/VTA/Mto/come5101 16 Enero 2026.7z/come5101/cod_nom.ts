//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : cod_nom
// Description : Componente cod_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

//imports

export class cod_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_doc.cod_nom";
    this.prop.Format = "R";
    this.style.height = '22px';
    this.prop.InputMask = "";
    //Left=51;
    this.prop.ToolTipText = "Codigo del cliente o proveedor";
    this.style.width = '120px';

    //propiedades
  }

  // Evento   :DblClick
  // Objeto  :busqueda
  // Tipo   :TexBox
  // Comentarios :
  async Dblclick() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const router = useRouter();
    router.push({ name: 'formas\con_nom', params: { Param1: cometdo.cop_nom, Param2: 'cod_nom' } })// tom.cod_nom

    //VFP  m.cod_nom m.cod_nom

  }   // Fin Procedure



  // Evento   :KeyPress
  // Objeto  :busqueda
  // Tipo   :TexBox
  // Comentarios :
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeycode
    let nkeycode = 0
    if (nkeycode == 27) {
      // si da un "ESC" se va al procedimiento de salida
      return

    } // End If 


    // m.cla_isu=0
    if ((this.Form.prop.key > 0 && String.fromCharCode(this.Form.prop.key) == '?') || ((this.Form.prop.key == 13 || this.Form.prop.key == 9) && this.prop.Value == '      ')) {
      // consulta de nombres
      //VFP  "" "" clear

      const router = useRouter();
      router.push({ name: 'formas\con_nom', params: { Param1: cometdo.cop_nom, Param2: 'cod_nom' } })// tom.cod_nom

      //VFP  m.cod_nom m.cod_nom

    } // End If 

    if (this.Form.prop.key > 0 && String.fromCharCode(this.Form.prop.key) == '&' && (this.Form.tipoCaptura == 'CO' || this.Form.tipoCaptura == 'VE')) {
      // consulta de Pedidos
      const router = useRouter();
      router.push({ name: 'formas\con_pedidos', params: { Param1: cometdo.cop_nom } })

      const ver_documentos = await select('ver_documentos')

      if (await recCount() > 0) {
        m = appendM(m, await scatter())// scatter 
        // asignamos los campos del pedido a surtir

        this.Form.ref_doc.prop.Value = m.ref_doc
        this.Form.cod_nom.prop.Value = m.cod_nom
        this.Form.con_con.prop.Value = m.con_con
        this.Form.mon_doc.prop.Value = m.mon_doc
        if (this.Form.tipoCaptura == 'VE') {
          this.Form.ven_ven.prop.Value = m.ven_ven
          this.Form.als_doc.prop.Value = m.als_doc
        } // End If 

        if (this.Form.tipoCaptura == 'CO') {
          this.Form.ale_doc.prop.Value = m.ale_docó
        } // End If 

        this.Form.dpe_mov = m.tdo_tdo
        this.Form.npe_mov = m.ndo_doc
        let vi_lla1_doc = let com_doc = m.com_doc
        //VFP  m.cod_nom m.cod_nom

      } else {

        this.Form.npe_mov = '  '
        this.Form.mpe_mov = 0
        this.prop.Value = '      '
      } // End If 

    } // End If 

    return

  }   // Fin Procedure



  // evento   :valid
  // objeto  :cod_nom
  // tipo   :cuadro de texto
  // comentarios :es la validación de codigo del cliente o proveedor
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.Form.prop.key == 27) {
      return true

    } // End If 

    if (String.fromCharCode(this.Form.prop.key) == '?' || len(allTrim(this.prop.Value)) == 0) {
      // si pidio ayuda
      this.prop.Valid = false
      return true

    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    m = appendM(m, await scatter())// scatter 
    // rellenamos con ceros a la izquierda

    m.cop_nom = cometdo.cop_nom
    // asignamos si es cliente o proveedor
    m.cod_nom = jus_cer(this.prop.Value, cometdo.cop_nom)
    if (allTrim(this.prop.Value) != allTrim(m.cod_nom)) {

      this.prop.Value = m.cod_nom
    } // End If 

    if (cometdo.cop_nom == 'C') {
      // si es un cliente        && seleccionamos los almacenes que no son propiedad
      let ins_fox = "set filter to ave_tda=1 and (.not. alc_tda=1 .or. cod_nom='" + this.prop.Value + "')"
      // de clientes o los que pertenecen a este cliente
      const cometda_ent = await select('cometda_ent')

        & ins_fox
      if (alc_tda == 1 && cod_nom != this.prop.Value) {
        await goto('TOP')

      } // End If 

      const cometda_sal = await select('cometda_sal')

        & ins_fox
      if (alc_tda == 1 && cod_nom != this.prop.Value) {
        await goto('TOP')

      } // End If 

      const vi_lla1_doc = await select('vi_lla1_doc')

    } // End If óó


    // si cambio de codigo o es un codigo nuevo o es un documento que tiene
    // importes en cero
    if (this.Form.sw_nue || this.prop.Value != vi_lla1_doc.cod_nom || isNull(vi_lla1_doc.mpa_sat) || isNull(vi_lla1_doc.uso_sat) || isNull(vi_lla1_doc.fpa_sat) || isNull(await oldValue('vi_lla1_doc.cod_nom')) || allTrim(this.prop.Value) != allTrim(await oldValue('vi_lla1_doc.cod_nom'))) {

      //   or 
      //(vi_lla1_doc.imp_doc=0 and vi_lla1_doc.im1_doc=0 and vi_lla1_doc.im2_doc=0 and vi_lla1_doc.im3_doc=0)
      if (!this.Form.sw_nue && vi_lla1_doc.tre_sat > ' ' && await oldValue('vi_lla1_doc.cod_nom') != vi_lla1_doc.cod_nom) {
        this.Form.MessageBox('No se puede cambiar el codigo del cliente mientras exista algun documento relacionado', 16, 'Error de validación', 5000)
        this.prop.Value = await oldValue('vi_lla1_doc.cod_nom')
        return false

      } // End If 

      this.Form.d_dir_nom.prop.Value = ''
      this.Form.d_ext_nom.prop.Value = ''
      this.Form.d_int_nom.prop.Value = ''
      this.Form.d_col_nom.prop.Value = ''
      this.Form.d_pob_nom.prop.Value = ''
      this.Form.d_cpo_nom.prop.Value = ''
      this.Form.d_te1_nom.prop.Value = ''
      this.Form.d_rfc_nom.prop.Value = ''
      if (this.Form.sw_rfi) {
        this.Form.d_rfi_nom.prop.Value = ''
      } // End If 

      this.Form.d_edo_edo.prop.Value = ''
      this.Form.d_pai_nom.prop.Value = ''
      const vi_lla1_nom = await select('vi_lla1_nom')

      await use('vi_lla1_nom', m) // use vi_lla1_nom vi_lla1_nom

      if (await recCount() < 1) {
        // no existe el cliente o proveedor
        this.prop.Valid = false
        this.Form.MessageBox('No existe este código de cliente o proveedor', 16, 'Error de validación', 3000)
        return false

      } // End If 

      m = appendM(m, await scatter())// scatter 
      //thisform.con_con.value=0    && actualizamos consignatario

      this.Form.d_nom_nom.Refresh
      if (allTrim(this.prop.Value) != allTrim(m.cod_nom)) {
        this.prop.Value = m.cod_nom
      } // End If 


      // This.Value=m.cod_nom
      // seguridad por sucursales
      // si no tiene sucursal el cliente o proveedor
      // si no tiene sucirsal el usuario
      // o es diferente la sucursal del cliente o proveedor
      // a la del usuario
      if (Public.value.sucursal != '   ' && Public.value.sucursal != Public.value.suc_pge && Public.value.suc_pge != '   ') {

        this.Form.MessageBox('Cliente de otra sucursal')
        return false

      } // End If 

      this.Form.d_nom_nom.prop.ReadOnly = true

      // si es nuevo o no tiene importes
      if (this.Form.sw_nue) {
        //.Or. (vi_lla1_doc.imp_doc=0 And vi_lla1_doc.im0_doc=0 And vi_lla1_doc.im1_doc=0 And vi_lla1_doc.im2_doc=0 And vi_lla1_doc.im3_doc=0 And vi_lla1_doc.im4_doc=0 And vi_lla1_doc.im5_doc=0)
        if (vi_lla1_nom.mcr_nom == 0) {
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_nom.mcr_nom=?  where recno=${Recno} `, [1])

        } // End If 

        this.Form.mon_doc.prop.Value = vi_lla1_nom.mcr_nom
        // asigna moneda de documentos
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.mon_doc=?  where recno=${Recno} `, [vi_lla1_nom.mcr_nom])

        this.Form.vmo_doc.prop.Value = Public.value.val_mon1(vi_lla1_nom.mcr_nom)
        this.Form.fve_doc.prop.Value = this.Form.fec_doc.prop.Value
      } // End If 


      //11/Ene/2017
      if ((m.cop_nom + cometdo.coa_tdo == 'CC' || m.cop_nom + cometdo.coa_tdo == 'PA' || m.cop_nom + cometdo.coa_tdo == 'CN' || m.cop_nom + cometdo.coa_tdo == 'PN')) {
        this.Form.fve_doc.prop.Value = vi_lla1_doc.fec_doc + vi_lla1_nom.dcr_nom
        if ((m.cop_nom + cometdo.coa_tdo == 'CC')) {
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.fip_doc=?  where recno=${Recno} `, [vi_lla1_doc.fve_doc])

        } // End If 

      } // End If 

      if (m.cop_nom == 'C' && await recCount('ver_documentos') == 0) {
        // si es de un cliente asigna el vendedor default
        this.Form.ven_ven.prop.Value = ven_ven
        // asigna vendedor
      } // End If 

      // Inicio replace VFP
      //  IF thisform.sw_nue
      // endif          && asignamos fecha de vencimiento del documento si
      // es nuevo o ha cambiado el código
      //11/Ene/2017
      //!//  If Thisform.sw_nue
      //!//      IF (m.cop_nom+cometdo.coa_tdo='CC' .Or. m.cop_nom+cometdo.coa_tdo='PA' Or m.cop_nom+cometdo.coa_tdo='CN' .Or. m.cop_nom+cometdo.coa_tdo='PN' )
      //!//      Thisform.fve_doc.Value=vi_lla1_doc.fec_doc+vi_lla1_nom.dcr_nom
      //!//         ENDIF
      //!//         IF m.cop_nom='C' AND Reccount('pedidos')=0  && si es de un cliente asigna el vendedor default
      //!//       Thisform.ven_ven.Value=ven_ven  && asigna vendedor
      //!//   Endif
      //!//
      //!//  Endif
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.uso_sat=?  where recno=${Recno} `, [vi_lla1_nom.uso_sat])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.mpa_sat=?  where recno=${Recno} `, [vi_lla1_nom.mpa_sat])

      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()óó
      await localAlaSql(`update ${Alias} set vi_lla1_doc.fpa_sat=?  where recno=${Recno} `, [vi_lla1_nom.fpa_sat])

      if (isNull(vi_lla1_doc.npa_doc)) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.npa_doc=?  where recno=${Recno} `, [1])

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.tpa_doc=?  where recno=${Recno} `, ['M'])

      } // End If 

      if (isNull(vi_lla1_doc.rpa_doc)) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.rpa_doc=?  where recno=${Recno} `, [1])

      } // End If 

      if (isNull(vi_lla1_doc.tre_sat)) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.tre_sat=?  where recno=${Recno} `, [''])

      } // End If 

      if (isNull(vi_lla1_doc.tdr_doc)) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.tdr_doc=?  where recno=${Recno} `, [''])

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.ndr_doc=?  where recno=${Recno} `, [0])

      } // End If 

      this.Form.d_nom_nom.Refresh
      this.Form.mon_doc.Refresh
      this.Form.fve_doc.Refresh
      if ((m.cop_nom + cometdo.coa_tdo == 'CC') && this.Form.tipoCaptura == 'VE') {
        this.Form.fip_doc.Refresh
        this.Form.uso_sat.Refresh
        this.Form.mpa_sat.Refresh
        this.Form.fpa_sat.Refresh
      } // End If 

    } else {

      const vi_lla1_nom = await select('vi_lla1_nom')

      await use('vi_lla1_nom', m) // use vi_lla1_nom vi_lla1_nom
      // lee los datos generales de clientes

      if (await recCount() < 1) {
        // no existe el cliente o proveedor
        this.prop.Valid = false
        this.Form.MessageBox('No existe este código de cliente o proveedor, o pertenece a otra sucursal', 16, 'Error de validación', 3000)
        return false

      } // End If 

      m = appendM(m, await scatter())// scatter 

    } // End If 


    // reviza seguridad por sucursal
    // si no tiene sucursal el cliente o proveedor
    // si no tiene sucirsal el usuario
    // o es diferente la sucursal del cliente o proveedor
    // a la del usuario
    if (!(Public.value.suc_pge == '   ' || Public.value.sucursal == '   ' || isNull(Public.value.suc_pge)) && Public.value.sucursal != Public.value.suc_pge) {
      this.Form.MessageBox('Cliente de otra sucursal')
      return false

    } // End If 

    if (m.cop_nom == 'C' && this.Form.ven_ven.prop.Value != 0) {
      this.Form.ven_ven.valid
      // mandamos validar vendedor
    } // End If 

    m = appendM(m, await scatter())// scatter 
    // leemos variables de memoria

    const vi_cap_comemen = await select('vi_cap_comemen')
    //select vi_lla1_men
    //m.num_men=1
    //use vi_lla1_men
    //if reccount()>0
    //   thisform.messagebox(men_men)
    //endif

    await requery()

    // lee mensajes de clientes o proveedores
    // VFP SCAN 
    while (!eof()) {
      if (con_con == 0) {
        this.Form.MessageBox('Mensaje No ' + str(num_men, 2) + ' :' + men_men)
      } // End If 

      skip()
    } // End while 

    await goto('TOP')

    const vi_lla1_tdn = await select('vi_lla1_tdn')
    // tabla tipos de clientes

    await use('vi_lla1_tdn', m) // use vi_lla1_tdn vi_lla1_tdn

    if (vi_lla1_doc.tip_tdn == '  ') {
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.tip_tdn=?  where recno=${Recno} `, [vi_lla1_nom.tip_tdn])

    } // End If 


    ////////////////////////////////////////
    if ((m.sta_nom == 'B' || m.ecc_nom == 'B')) {
      // cliente bloqueado
      let men_blo = 'Cliente bloqueado, ' + String.fromCharCode(13)
      if (m.dst_nom != space(30)) {
        men_blo = men_blo + m.dst_nom + String.fromCharCode(13)
      } // End If 

      if (m.ecc_nom == 'B') {
        men_blo = men_blo + 'Revise estado de cuenta de este cliente'
      } // End If 

      this.Form.MessageBox(men_blo)
      this.prop.Valid = false
      return false

    } // End If 

    this.prop.Valid = true
    // damos por bueno el dato

    //select vi_cap_comemen        && lee mensajes de clientes o proveedores
    //scan
    // thisform.messagebox('Mensaje no '+str(num_men,2)+' :'+men_men)
    //endscan
    // es un cliente de mostrador o proveedor varios
    if (cometdo.dba_tdo != 'CG4' && ((m.cop_nom == 'C' && allTrim(m.cod_nom) ==== allTrim(Public.value.mos_pge)) || (m.cop_nom == 'P' && allTrim(m.cod_nom) ==== allTrim(Public.value.pva_pge)) || vi_lla1_tdn.mos_tdn == 1)) {
      const vi_lla1_mos = await select('vi_lla1_mos')
      //m.cop_nom+m.cod_nom='C'+m.mos_pge .or. m.cop_nom+m.cod_nom='P'+m.pva_pge

      await use('vi_lla1_mos', m) // use vi_lla1_mos vi_lla1_mos

      if (await recCount() > 0) {
        // si hay datos de mostrador
        m.rfi_mos = ''
        m = appendM(m, await scatter())// scatter 
        // asignamos datos

        const vi_lla1_nom = await select('vi_lla1_nom')

        this.Form.d_nom_nom.prop.Value = m.nom_mos
        this.Form.d_dir_nom.prop.Value = m.dir_mos
        if (this.Form.fac_ele) {
          this.Form.d_ext_nom.prop.Value = m.ext_mos
          this.Form.d_int_nom.prop.Value = m.int_mos
        } // End If 

        this.Form.d_col_nom.prop.Value = m.col_mos
        this.Form.d_pob_nom.prop.Value = m.pob_mos
        this.Form.d_cpo_nom.prop.Value = m.cpo_mos
        this.Form.d_te1_nom.prop.Value = m.te1_mos
        this.Form.d_rfc_nom.prop.Value = m.rfc_mos
        if (this.Form.sw_rfi) {
          this.Form.d_rfi_nom.prop.Value = m.rfi_mos
        } // End If 

        this.Form.d_edo_edo.prop.Value = m.edo_edo
        this.Form.d_pai_nom.prop.Value = m.pai_mos
      } else {

        this.Form.d_nom_nom.prop.Value = m.nom_nom
        //// Thisform.d_nom_nom.Value=Space(Len(This.Value)) && ponemos en blanco el nombre
        this.Form.d_rfc_nom.prop.Value = 'XAXX010101000'
        // ponemos el RFC Generico
      } // End If 

      this.Form.d_nom_nom.prop.ReadOnly = false
      // habilitamos captura de datos
      this.Form.d_dir_nom.prop.ReadOnly = false
      this.Form.d_col_nom.prop.ReadOnly = false
      if (this.Form.fac_ele) {
        this.Form.d_ext_nom.prop.ReadOnly = falseó
        this.Form.d_int_nom.prop.ReadOnly = false
      } // End If 

      this.Form.d_pob_nom.prop.ReadOnly = false
      this.Form.d_edo_edo.prop.ReadOnly = false
      this.Form.d_pai_nom.prop.ReadOnly = false
      this.Form.d_cpo_nom.prop.ReadOnly = false
      this.Form.d_te1_nom.prop.ReadOnly = false
      this.Form.d_rfc_nom.prop.ReadOnly = false
      if (this.Form.sw_rfi) {
        this.Form.d_rfi_nom.prop.Disabled = false
      } // End If 

      this.Form.con_con.prop.ReadOnly = true
      // deshabilitamos consignatario
    } else {

      this.Form.d_nom_nom.prop.ReadOnly = true
      // deshabilitamos captura
      this.Form.d_dir_nom.prop.ReadOnly = true
      this.Form.d_col_nom.prop.ReadOnly = true
      if (this.Form.fac_ele) {
        this.Form.d_ext_nom.prop.ReadOnly = true
        this.Form.d_int_nom.prop.ReadOnly = true
      } // End If 

      this.Form.d_pob_nom.prop.ReadOnly = true
      this.Form.d_edo_edo.prop.ReadOnly = true
      this.Form.d_pai_nom.prop.ReadOnly = true
      this.Form.d_cpo_nom.prop.ReadOnly = true
      this.Form.d_rfc_nom.prop.ReadOnly = true
      if (this.Form.sw_rfi) {
        this.Form.d_rfi_nom.prop.Disabled = true
      } // End If 

      this.Form.con_con.prop.ReadOnly = false
      // habilitamos consignatario
    } // End If 

    if (vi_lla1_doc.con_con == 0) {
      // reviza si tiene consignatrios
      switch (true) {
        case Public.value.ndb_emp == 1:
          // si es mssql
          let ins_sql = upper("select top 1 key_pri from man_comecon where cod_nom='" + this.prop.Value + "'")
          break
        case Public.value.ndb_emp == 3:
          // si es Sybase
          ins_sql = upper("SET ROWCOUNT 1 select key_pri from comecon where cod_nom='" + this.prop.Value + "' SET ROWCOUNT 0")
          break
        case Public.value.ndb_emp == 2:
          // si es interbase
          ins_sql = "select max(key_pri) from comecon where cod_nom='" + this.prop.Value + "'"
          break
        case Public.value.ndb_emp == 4:
          // PostgreSQL
          ins_sql = upper("select key_pri from man_comecon where cod_nom='" + this.prop.Value + "' LIMIT 1")
      } // End case 

      =iif(await SQLExec(ins_sql) > 0, 0, err_sql())
      // ejecuta instruccion sql
      if (await recCount() == 0) {
        // si el cliente no tiene cosignatarios
        this.Form.con_con.prop.ReadOnly = true
        // deshabilitamos consignatario
      } // End If 

    } // End If 

    if (Public.value.ndb_emp == 2) {
      // si es interbase
      // Sqlcommit ( Public.value.num_dbs ) 

      await SQLExec("commit work;")

    } // End If 

    this.Form.Refresh
    const vi_lla1_doc = await select('vi_lla1_doc')

    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :cod_nom
  // Tipo   :Cuadro de texto
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly) {
      return false

    } // End If 

    this.Form.tdo_tdo.prop.Disabled = false
    this.Form.ndo_doc.prop.ReadOnly = false
    const ver_documentos = await select('ver_documentos')

    await useNodata('vi_lla1_doc', 'ver_documentos') // use vi_lla1_doc vi_lla1_doc Nodata Alias

    if (this.Form.sw_mov) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos

      // si es un cargo o abono y ya esta impreso o timbrado no permite cambio de código
      if ((cometdo.coa_tdo == 'C' || cometdo.coa_tdo == 'A') && (vi_lla1_doc.sta_doc == 'I' || vi_lla1_doc.sta_doc == 'T' || vi_lla1_doc.sta_doc == 'X')) {
        return false

      } // End If 

      if (cometdo.cop_nom == 'P') {
        // si se trata de un proveedor, activa modulo de cargar xml
        this.Form.carga_xml.prop.Visible = true
        this.Form.carga_xml.prop.Disabled = false
      } // End If 

      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}