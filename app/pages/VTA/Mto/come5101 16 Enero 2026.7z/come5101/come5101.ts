  override export async function keyPress(nKeyCode,nShiftAltCtrl){     let m = {...this.Form.mPublic} ;  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.Cancela_docto.keyPress(nKeyCode,nShiftAltCtrl)
  }   // Fin Procedure
//procedure