//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : con_con
// Description : Componente con_con
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class con_con extends COMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Component";
    this.prop.Type = "number";
    this.prop.Caption = "Consignatario/Sucursal";
    this.prop.ControlSource = "vi_lla1_doc.con_con";

    this.prop.InputMask = "9999999";
    //Left=64;
    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "Número de consignatario/Sucursal";

    //propiedades
  }

  // Evento   :KeyPress
  // Objeto  :con_con
  // Tipo   :Text
  override async keyPress(nKeyCode, nShiftAltCtrl) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.Form.prop.key = nkeycode
    m.con_con = 0
    if (String.fromCharCode(this.Form.prop.key) == '?') {
      // busca nombres
      //VFP  "" "" clear

      const router = useRouter();
      router.push({ name: 'formas\con_con', params: { Param1: this.Form.cod_nom.prop.Value } })// tom.con_con

      //VFP  Str Str ( m.con_con )

    } // End If 
    //this.Value=m.con_con

    return

  }   // Fin Procedure



  // Evento   :lostFocus
  // Objeto  :con_conó
  // Tipo   :Cuadro de texto
  // Comentarios :
  async lostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (String.fromCharCode(this.Form.prop.key) == '?') {
      return

    } // End If 

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :con_con
  // Tipo   :Cuadro de texto
  // Comentarios :Es la validación del consignatario
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (isNull(this.prop.Value)) {
      this.prop.Value = 0
    } // End If 

    if (this.prop.Value == 0) {
      // no hay consignatario
      this.prop.Valid = true
      return true

    } // End If 

    if (String.fromCharCode(this.Form.prop.key) == '?') {
      return

    } // End If 

    const vi_lla1_con = await select('vi_lla1_con')

    m.cop_nom = cometdo.cop_nom
    // seleccionamos consignatarios
    m.cod_nom = vi_lla1_doc.cod_nom
    m.con_con = this.prop.Value
    await use('vi_lla1_con', m) // use vi_lla1_con vi_lla1_con

    const cam_arc = afields()

    if (await recCount() == 0) {
      this.Form.MessageBox('No existe consignatario')
      this.prop.Valid = false
      return false

    } // End If 

    if (Public.value.sucursal != '   ' && Public.value.sucursal != Public.value.suc_pge && Public.value.suc_pge != '   ') {
      this.Form.MessageBox('Cliente de otra sucursal')
      return false

    } // End If 

    this.Form.d_noc_con.Refresh
    m.con_con = this.Form.con_con.prop.Value
    //// muestra mensajes de consignatario en caso de tenerlos
    const vi_cap_comemen = await select('vi_cap_comemen')

    await requery()

    // lee mensajes de clientes o proveedores
    // VFP SCAN 
    while (!eof()) {
      if (con_con == m.con_con) {
        this.Form.MessageBox('Mensaje No ' + str(num_men, 2) + ' :' + men_men)
      } // End If 

      skip()
    } // End while 

    const vi_lla1_doc = await select('vi_lla1_doc')

    if (this.Form.sw_nue || this.prop.Value != await oldValue('vi_lla1_doc.con_con')) {
      if (vi_lla1_con.ven_ven >= 1) {
        this.Form.ven_ven.prop.Value = vi_lla1_con.ven_ven
        this.Form.ven_ven.valid
      } // End If 

      if (ascan(cam_arc, 'MON_CON') > 0 && (this.Form.sw_nue || !this.Form.sw_mov)) {
        if (Nvl(vi_lla1_con.mon_con, 0) > 0 && vi_lla1_con.mon_con > 0) {
          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.mon_doc=?  where recno=${Recno} `, [vi_lla1_con.mon_con])

        } else {

          // Inicio replace VFP
          Recno = await recNo()
          Alias = await alias()
          await localAlaSql(`update ${Alias} set vi_lla1_doc.mon_doc=?  where recno=${Recno} `, [vi_lla1_nom.mcr_nom])

        } // End If 

        this.Form.mon_doc.Refresh
        this.Form.mon_doc.valid
      } // End If 

    } // End If 

    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :when
  // Objeto  :con_con
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (await this.Form.rev_per(this.prop.Name) && this.prop.ReadOnly == false) {
      // manda revizar permisos
      return true
      //  this.Comment=str(vi_lla1_doc.con_con)

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}