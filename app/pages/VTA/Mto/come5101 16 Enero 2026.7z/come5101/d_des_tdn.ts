//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_des_tdn
// Description : Componente d_des_tdn
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_des_tdn extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_tdn.des_tdn";
    this.prop.Caption = "Tipo de cliente o proveedor";

    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Tipo de cliente o proveedor";
    this.style.width = '130px';

    //propiedades
  }


  //metodo
}