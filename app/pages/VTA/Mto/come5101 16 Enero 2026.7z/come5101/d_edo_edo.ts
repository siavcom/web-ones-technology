//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_edo_edo
// Description : Componente d_edo_edo
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_edo_edo extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_nom.edo_edo";
    this.prop.Caption = "Estado";

    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Estado";
    this.style.width = '156px';

    //propiedades
  }


  // Evento   :when
  // Objeto  :d_cop_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}