//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_exi_pro
// Description : Componente d_exi_pro
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

//imports

export class d_exi_pro extends COMPONENT {
    //public
    constructor() {
        super();
        this.prop.Type = 'number';
        this.prop.ControlSource = "vi_cap_comemov.exi_alm";
        //Left=101;
        this.prop.Name = "d_exi_pro";
        this.prop.ReadOnly = true;
        this.prop.TabIndex = 107;
        this.style.top = '431px';
        this.prop.Value = 0;
        this.prop.Visible = true;
        this.style.width = '99px';

        //propiedades
    }

    override async init() {
        this.prop.InputMask = ('9,999,999.' + replicateString('9', Public.value.dci_pge));
    }
    //metodo
}