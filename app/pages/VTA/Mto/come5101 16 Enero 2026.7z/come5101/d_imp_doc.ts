//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_imp_doc
// Description : Componente d_imp_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class d_imp_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'number';
    this.prop.ControlSource = "vi_lla1_doc.imp_doc";
    this.style.fontSize = '17px';
    this.prop.ReadOnly = true;
    this.style.width = '107px';


    //propiedades
  }



  override async init() {
    this.prop.Caption = 'Subtotal'
    this.prop.Decimals = Public.value.dcp_pge;
    if (this.prop.Caption.trim().length == 0) {
      this.prop.Visible = false
    } // End If 

  }   // Fin Procedure


  // Evento   :Valid
  // Objeto  :d_imp_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Calcula el total del documento
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await select('vi_lla1_doc')

    this.Form.d_tot_doc.prop.Value = imp_doc + im0_doc + im1_doc + im2_doc + im3_doc + iif(Public.value.sw_imp, im4_doc + im5_doc, 0)
    this.Form.d_tot_doc.refresh
  }   // Fin Procedure


  //metodo
}