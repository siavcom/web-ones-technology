//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_lis_nom
// Description : Componente d_lis_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class d_lis_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Lista de precios";

    this.prop.ControlSource = "vi_lla1_nom.lis_nom";
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Lista de precios";
    this.style.width = '24px';

    //propiedades
  }



  //metodo
}