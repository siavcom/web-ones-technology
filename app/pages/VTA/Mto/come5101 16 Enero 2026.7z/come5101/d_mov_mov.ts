//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_mov_mov
// Description : Componente d_mov_mov
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class d_mov_mov extends COMPONENT {
    //public
    constructor() {
        super();
        this.prop.Caption = 'Número de movimiento';


        this.prop.Type = 'number';
        this.prop.ControlSource = "vi_cap_comemov.mov_mov";
        this.style.height = '22px';
        //Left=102;
        this.prop.ReadOnly = true;
        this.style.width = '35px';
        this.prop.Decimals = 0
        //propiedades
    }
    //metodo
}