//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_noc_con
// Description : Componente d_noc_con
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { COMPONENT } from "@/classes/Component";
//imports

export class d_noc_con extends COMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Component";

    this.prop.Type = 'text';
    this.style.backgroundColor = '255,255,255';
    this.prop.ControlSource = "vi_lla1_con.noc_con";
    this.DisabledBackColor = 234, 234, 234;
    this.prop.Format = "K";
    this.style.height = '22px';
    //Left=123;
    this.prop.Name = "d_noc_con";
    this.prop.ReadOnly = true;
    this.prop.TabIndex = 49;
    this.style.top = '101px';
    this.style.width = '704px';
    this.style.zIndex = '95';

    //propiedades
  }
  override async salir() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.MaxLength = len(this.prop.Value)
  }   // Fin Procedure



  // Evento   :when
  // Objeto  :d_noc_con
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (this.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}