//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_nom_tba
// Description : Componente d_nom_tba
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_nom_tba extends CAPTURECOMPONENT {
    //public
    constructor() {
        super();

        this.prop.Type = 'text';
        this.prop.ControlSource = 'vi_cap_cometba.nom_tba';
        this.prop.ReadOnly = true;
        this.style.width = '229px';
        //propiedades
    }
    //metodo
}