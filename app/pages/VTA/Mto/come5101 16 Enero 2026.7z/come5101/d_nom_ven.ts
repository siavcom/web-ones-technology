//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_nom_ven
// Description : Componente d_nom_ven
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class d_nom_ven extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_ven.nom_ven";
    this.prop.ReadOnly = true;
    this.style.width = '306px';

    //propiedades
  }
  //metodo
}