//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_rfc_nom
// Description : Componente d_rfc_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class d_rfc_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_nom.rfc_nom";
    this.prop.Caption = "RFC ";

    this.prop.InputMask = "!!!!9999!!!!!";
    //Left=48;
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "RFC ";
    this.style.width = '133px';

    //propiedades
  }


  // Evento   :when
  // Objeto  :d_rfc_nom
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    if (await this.Form.rev_per('rfc_nom')) {
      // manda revizar permisos
      return true

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}