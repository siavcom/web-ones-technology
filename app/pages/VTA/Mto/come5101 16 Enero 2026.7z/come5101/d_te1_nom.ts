//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : d_te1_nom
// Description : Componente d_te1_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class d_te1_nom extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Teléfono";

    this.prop.ControlSource = "vi_lla1_nom.te1_nom";
    this.prop.InputMask = "XXXXXXXXXXXXXXXXXXXXXX";
    //Left=750;
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Teléfono";

    this.style.width = '258px';

    //propiedades
  }



  // Evento   :when
  // Objeto  :d_te1_nom
  // objeto  :d_pai_nom
  // tipo   :cuadro de texto
  // comentarios :
  override async when() {
    if (this.prop.ReadOnly == true || this.Form.d_nom_nom.prop.ReadOnly == true) {
      return false

    } // End If 

    return true

  }   // Fin Procedure


  //metodo
}