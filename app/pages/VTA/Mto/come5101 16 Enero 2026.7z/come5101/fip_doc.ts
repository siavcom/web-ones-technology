//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : fip_doc
// Description : Componente fip_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class fip_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = 'Fecha primer pago';
    this.prop.ControlSource = "vi_lla1_doc.fip_doc";
    this.prop.ToolTipText = "Fecha primer pago";
    this.style.width = '99px';

    //propiedades
  }
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos mó
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    if (this.prop.Value < vi_lla1_doc.fec_doc) {
      MessageBox('No puede ser menor a la fecha de expedición del documento', 16, 'Error', 50000)
      return false

    } // End If 

    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :fip_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    const cometdo = await currentValue('*', 'cometdo')
    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}