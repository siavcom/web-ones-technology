//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : coboboxsat
// Class : fpa_sat
// Description : Componente fpa_sat
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COBOBOXSAT } from "@/classes/coboboxsat";

import { COBOBOXSAT } from "@/classes/Siavcom/coboboxsat";
import { currentValue } from "~/composables/0_SqlDb";
//imports

export class fpa_sat extends COBOBOXSAT {
  //public
  constructor() {
    super();
    this.prop.Caption = "Forma de pago";

    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "200,30";
    this.prop.ControlSource = "vi_lla1_doc.fpa_sat";
    this.prop.RowSource = "formas_pago.des_sat,cla_sat";
    this.prop.Style = 2;
    this.prop.TabIndex = 34;
    this.prop.ToolTipText = "Forma de pago";
    this.prop.Value = (formas_pago.cla_sat);
    this.style.width = '183px';

    //propiedades
  }


  // Evento   :When
  // Objeto  :fpa_sat
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await currentValue('*', "vi_lla1_doc");
    const cometdo = await currentValue('*', "cometdo");
    this.prop.Valid = true
    if (vi_lla1_doc.sta_doc == 'X') {
      return false

    } // End If 

    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}