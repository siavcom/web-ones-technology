//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : textLabel
// Class : la_lis_nom
// Description : Componente la_lis_nom
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { TEXTLABEL } from "@/classes/textLabel";

import { TEXTLABEL } from "@/classes/textLabel";
//imports

export class la_lis_nom extends TEXTLABEL {
    //public
    constructor() {
        super();
        this.prop.BaseClass = "textLabel";


        this.style.backgroundColor = '255,255,255';
        this.prop.Caption = "Lis.Precios";
        this.style.height = '17px';
        //Left=537;
        this.prop.Name = "la_lis_nom";
        this.prop.TabIndex = 99;
        this.style.top = '177px';
        this.style.width = '55px';
        this.style.zIndex = '54';

        //propiedades
    }
    //metodo
}