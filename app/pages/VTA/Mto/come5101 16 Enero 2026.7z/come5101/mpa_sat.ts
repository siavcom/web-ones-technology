//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : coboboxsat
// Class : mpa_sat
// Description : Componente mpa_sat
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COBOBOXSAT } from "@/classes/coboboxsat";

import { COBOBOXSAT } from "@/classes/Siavcom/coboboxsat";
//imports

export class mpa_sat extends COBOBOXSAT {
  //public
  constructor() {
    super();
    this.prop.Caption = "Metodo de pago";

    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "200,30";
    this.prop.ControlSource = "vi_lla1_doc.mpa_sat";
    this.prop.RowSource = "metodos_pago.des_sat,cla_sat";
    this.prop.ToolTipText = "Metodo de pago";
    this.style.top = '218px';
    this.prop.Value = (metodos_pago.cla_sat);
    this.style.width = '183px';
    this.style.zIndex = '119';

    //propiedades
  }

  // Evento   :When
  // Objeto  :mpa_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {

    this.prop.Valid = true
    if (this.Form.vi_lla1_doc.sta_doc == 'X') {
      return false

    } // End If 

    if (this.Form.cometdo.tip_cfd == 'NA' || this.prop.ReadOnly) {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure

  //metodo
}