//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : NDR_DOC
// Description : Componente NDR_DOC
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";



export class ndr_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Component";
    this.prop.Caption = "Número de documento origen";

    this.prop.Type = 'text';

    this.prop.ControlSource = "vi_lla1_doc.ndr_doc";
    this.prop.Disabled = true;
    this.prop.InputMask = "99,999,999";
    this.prop.Decimal = 0
    //Left=312;

    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "Número de documento origen";

    this.style.width = '64px';


    //propiedades
  }

  // Evento   :lostFocus
  // Objeto  :ndr_doc_ped
  // Tipo   :TextBox
  // Comentarios :
  async lostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result

    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when
    } // End If 

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :vmo_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Es la validación del valor de la moneda
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    if (vi_lla1_doc.tre_sat.alltrim().length == 0) {
      this.prop.Valid = true
      this.Form.tdr_doc.prop.Valid = true
      this.Form.ndr_doc.prop.Valid = true
      return true

    } // End If 

    this.prop.Valid = false

    m.tdo_tdo = vi_lla1_doc.tdr_doc
    m.ndo_doc = vi_lla1_doc.ndr_doc
    await use('vi_lla1_xml', m) // use vi_lla1_xml vi_lla1_xml
    const vi_lla1_xml = await currentValue('*', 'vi_lla1_xml')
    if (await recCount() == 0 || vi_lla1_xml.uuid == '    ') {
      MessageBox('Este documento no esta timbrado. No se puede relacionar', 16, 'Error', 5000)
      return false

    } // End If 


    Aqui quede

    if (Result = await localAlaSql(`select ('doc_rel') = 0`)
    ) {
      //select(0)

    } else {

      const doc_rel = await select('doc_rel')

    } // End If 

    await use('vi_lla1_docaliasdoc_rel', m) // use vi_lla1_doc vi_lla1_doc

    if (doc_rel.cod_nom != vi_lla1_doc.cod_nom) {
      this.Form.MessageBox('Este documento pertenece a otro cliente. No se puede relacionar', 16, 'Error', 5000)
      return false

    } // End If 

    const vi_lla1_doc = await select('vi_lla1_doc')

    this.Form.tdr_doc.prop.Valid = true
    this.Form.ndr_doc.prop.Valid = true
    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :ndr_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (vi_lla1_doc.tre_sat == '   ' || this.prop.ReadOnly || this.Form.sw_dre_doc) {
      this.prop.Valid = true
      return false

    } // End If 

    if (await this.Form.rev_per(this.Form.tdr_doc.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}