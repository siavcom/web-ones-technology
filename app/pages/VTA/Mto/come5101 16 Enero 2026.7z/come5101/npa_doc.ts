//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : npa_doc
// Description : Componente npa_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

export class npa_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'text';
    this.prop.Caption = "Numero de parcialidades";

    this.prop.ControlSource = "vi_lla1_doc.npa_doc";
    this.prop.InputMask = "999";
    //Left=290;
    this.prop.ReadOnly = false;
    this.prop.ToolTipText = "Numero de parcialidades";
    this.style.width = '39px';

    //propiedades
  }



  // Evento   :When
  // Objeto  :mon_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    this.prop.Valid = true
    const cometdo = await currentValue('*', 'cometdo')
    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly || vi_lla1_doc.mpa_sat == 'PUE') {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}