//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : ped_ped
// Description : Componente ped_ped
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";

import { currentValue } from "~/composables/0_SqlDb";

export class ped_ped extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.Type = 'text';
    this.prop.Caption = "Pdimento aduanal";
    this.prop.ControlSource = "vi_lla1_doc.ped_ped";
    this.prop.ToolTipText = "Pedimento aduanal";
    this.style.width = '146px';
    //propiedades
  }

  // Evento   :lostFocus
  // Objeto  :ped_ped
  // Tipo   :TextBox
  // Comentarios :
  async lostFocus() {
    if (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24) {
      // si continua la captura ejecuta detalle
      this.Form.captura_movi.when
    } // End If 

  }   // Fin Procedure



  // Evento   :valid
  // Objeto  :ped_ped
  // Tipo   :TextBox
  // Comentarios : Solo se pregunta si es un documento de entrada de importación
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const cometdo = await currentValue('*', 'cometdo')
    if (cometdo.afi_tdo == 0 && this.prop.Value.allTrim() == '') {
      return true

    } // End If 

    m.ped_ped = this.prop.Value
    await use('vi_lla1_ped', m) // use vi_lla1_ped vi_lla1_ped
    const vi_lla1_ped = await currentValue('*', 'vi_lla1_ped')

    if (await recCount('vi_lla1_ped') > 0 && this.prop.Value.allTrim().length > 1) {
      // si existe pedimento

      // este pedimento no esta asignado a ningun documento
      if (vi_lla1_ped.tdo_tdo == '  ') {

        return true

      } // End If 


      // este pedimento esta asignado a este documento
      if (vi_lla1_ped.tdo_tdo == this.Form.tdo_tdo.prop.Value && vi_lla1_ped.ndo_doc == this.Form.ndo_doc.prop.Value) {

        return true
      } // End If 


      // este pedimento es de un traspaso que pertenece a este pedimento
      if (vi_lla1_ped.tdo_tdo == cometdo.ptr_tdo && vi_lla1_ped.ndo_doc == this.Form.ndo_doc.prop.Value) {
        return true

      } // End If 

      if (this.Form.MessageBox('Ya esta asignado el pedimento a otro ducumento. Â¿Lo asignamos a este documento también?', 4) == 6) {

        return true

      } // End If 


      return false

    } // End If 

    this.Form.MessageBox('No existe el pedimento o pedimento en blanco')

    return false

  }   // Fin Procedure



  // Evento   :when
  // Objeto  :ped_ped
  // Tipo   :TextBox
  // Comentarios : Solo se pregunta si es un documento de entrada de importación
  // si es un documento de entrada y afecta importaciones
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    const cometdo = await currentValue('*', 'cometdo')
    if ((cometdo.inv_tdo == 'E' && cometdo.afi_tdo == 1 && cometdo.cop_nom != 'C')) {
      if (await this.Form.rev_per(this.prop.Name)) {
        // manda revizar permisos
        return true

      } else {

        return false

      } // End If 

    } // End If 


    // si es un documento de salida y es un traspaso
    if ((cometdo.inv_tdo == 'S' && cometdo.tra_tdo == 1)) {
      m.tdo_tdo = cometdo.ptr_tdo
      await use('vi_lla1_tdo', m) // use vi_lla1_tdo vi_lla1_tdo
      const vi_lla1_tdo = await currentValue('*', 'vi_lla1_tdo')
      // si su documento de entrada es un documento de importación

      if (await recCount('vi_lla1_tdo') > 0 && vi_lla1_tdo.afi_tdo == 1) {
        if (await this.Form.rev_per(this.prop.Name)) {
          // manda revizar permisos
          return true

        } else {

          this.prop.Valid = true
          return false

        } // End If 

      } // End If 

    } // End If 
    this.prop.Valid = true
    await this.Form.captura_movi.when()
    return false

  }   // Fin Procedure


  //metodo
}