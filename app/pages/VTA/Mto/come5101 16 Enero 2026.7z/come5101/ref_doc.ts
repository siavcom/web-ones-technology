//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : ref_doc
// Description : Componente ref_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class ref_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();


    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_doc.ref_doc";
    this.prop.Name = "ref_doc";
    this.prop.ReadOnly = false;
    this.prop.TabIndex = 4;
    this.style.width = '286px';
    this.prop.Caption = 'Referencia';
    //propiedades
  }

  //!// if thisform.rev_per(this.name)   && manda revizar permisos
  //!//    return .t.
  //!// else
  //!//   this.gotfocus
  //!//   this.valid
  //!//   return .f.
  //!// endiflostFocus
  overlostFocusc salir() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.MaxLength = len(this.prop.Value)
  }   // Fin Procedure



  // Evento   :LostFocus
  // Objeto  :ref_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  async LostFocus() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if ((this.Form.ale_doc.prop.Visible == false && this.Form.als_doc.prop.Visible == false && (this.Form.tipoCaptura == 'IN' || this.Form.tipoCaptura == 'PG' || this.Form.tipoCaptura == 'AE' || this.Form.con_con.prop.ReadOnly) && this.Form.prop.key != 27)) {
    } // End If 

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :ref_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid(sw_rel) {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :ref_doc
  // Tipo   :Cuadro de texto
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}