//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : rpa_doc
// Description : Componente rpa_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class rpa_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Rango de la parcilidad ";
    this.prop.ControlSource = "vi_lla1_doc.rpa_doc";
    this.prop.ReadOnly = false;
    this.prop.TabIndex = 32;
    this.prop.ToolTipText = "Rango de la parcilidad ";
    this.style.top = '218px';
    this.prop.Value = 0;
    this.style.width = '39px';
    this.style.zIndex = '87';

    //propiedades
  }


  // Evento   :When
  // Objeto  :rpa_doc
  // Tipo   :ComboBox
  // Comentarios :Reviza si el grupo de trabajo se le permite la captura o modificacion del campo
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    const cometdo = await currentValue('*', 'cometdo')
    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly || vi_lla1_doc.mpa_sat == 'PUE') {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      if (vi_lla1_doc.tpa_doc == 'D' && vi_lla1_doc.mpa_sat != 'PUE') {
        return true

      } // End If 

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}