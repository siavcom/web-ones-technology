//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : tba_tba
// Description : Componente tba_tba
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";
// SE DEBE DE GENERAR EL HELP

export class tba_tba extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "Component";
    this.prop.Caption = "Supervisor";

    this.prop.Type = 'text';
    this.prop.ControlSource = "vi_lla1_doc.tba_tba";
    this.prop.ToolTipText = "Supervisor";
    this.style.width = '109px';
    //propiedades
  }


  // evento   :valid
  // objeto  :tba_tab
  // tipo   :cuadro de texto
  // comentarios :es la validación de codigo del cliente o proveedor
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m

    m.tba_tba = this.prop.Value
    m.pga_act = this.Form.pga_pga.prop.Value
    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    // si cambio de codigo o es un codigo nuevo o es un documento que tiene
    // importes en cero

    if (this.Form.sw_nue || this.prop.Value != vi_lla1_doc.tba_tba || this.prop.Value != await oldValue('vi_lla1_doc.tba_tba')) {
      await use('vi_lla1_tba')

      if (await recCount() < 1) {
        // no existe del trabajador

        return false

      } // End If 

    }
    // lee los datos generales del trabajador
    await use('vi_lla1_tba')


    const vi_lla1_tba = await currentValue('*', 'vi_lla1_tba')

    m = { ...vi_lla1_tba }// scatter 

    this.Form.d_nom_tba.prop.Value = vi_lla1_tba.nom_tba
    this.Form.d_nom_tba.refresh
    m.cop_nom = 'T'
    m.cod_nom = this.prop.Value
    await use('vi_cap_comemen')

    // lee mensajes del trabajador
    // VFP SCAN
    await goto(1, 'vi_cap_comemen')
    while (!eof('vi_cap_comemen')) {
      const data = await currentValue('*', 'vi_cap_comemen')
      this.Form.MessageBox(`Mensaje No ${data.num_men}  : ${data.men_men}`)
      await skip('vi_cap_comemen')
    } // End while 

    await goto('TOP')

    if (m.aug_tba != 'S') {
      this.Form.MessageBox('No se permite a este trabajador autorizaciones', 16, 'Error', 3000)
      return false

    } // End If 

    if (m.est_tba == 'B') {
      let men_blo = 'Trabajador bloqueado, '
      this.Form.MessageBox(men_blo)

      return false

    } // End If 


    return true
    //thisform.pga_pga.Value=m.pga_pga

  }   // Fin Procedure

  //metodo
}