//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : comboBox
// Class : TDR_DOC
// Description : Componente TDR_DOC
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////


export class tdr_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "comboBox";
    this.prop.Caption = "Tipo de documento origen";

    this.prop.BoundColumn = 2;
    this.prop.ColumnCount = 2;
    this.prop.ColumnWidths = "200,30";
    this.prop.ControlSource = "vi_lla1_doc.TDR_DOC";
    this.prop.Disabled = true;
    this.prop.RowSource = "docto_relacion.des_tdo,tdo_tdo";
    this.prop.RowSourceType = 2;
    this.prop.Style = 2;
    this.prop.ToolTipText = "Tipo de documento origen";
    this.style.width = '100px';

    //propiedades
  }
  override async valid() {
    if (this.prop.Value != await oldValue('vi_lla1_doc.tdr_doc')) {
      this.Form.ndr_doc.prop.Value = 0
      this.Form.ndr_doc.prop.Valid = false
    } // End If 
    return true
  }   // Fin Procedure


  // Evento   :When
  // Objeto  :tdr_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno

    const vi_lla1_doc = await currentValue('*', 'vi_lla1_doc')
    if (vi_lla1_doc.tdr_doc != '   ' && vi_lla1_doc.ndr_doc > 0) {
      this.Form.tdr_doc.prop.Valid = true
      this.Form.ndr_doc.prop.Valid = true
      return false

    } // End If 

    if ((this.prop.ReadOnly || vi_lla1_doc.tre_sat == '01' || vi_lla1_doc.tre_sat < '0' || this.Form.sw_dre_doc)) {
      this.Form.tdr_doc.prop.Valid = true
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.tdr_doc=?  where recno=${Recno} `, [''])

      this.Form.ndr_doc.prop.Valid = true
      // Inicio replace VFP
      Recno = await recNo()
      Alias = await alias()
      await localAlaSql(`update ${Alias} set vi_lla1_doc.ndr_doc=?  where recno=${Recno} `, [0])

      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } else {

      this.gotFocus()
      this.valid
      return false

    } // End If 

  }   // Fin Procedure


  //metodo
}