//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : coboboxsat
// Class : tpa_doc
// Description : Componente tpa_doc
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COBOBOXSAT } from "@/classes/coboboxsat";

export class tpa_doc extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();
    this.prop.BaseClass = "cobobox";
    this.prop.Caption = "Tipo de parcialidad";
    this.prop.ColumnCount = 2;
    this.prop.ColumnWidths = "200,30";
    this.prop.ControlSource = "vi_lla1_doc.tpa_doc";
    this.prop.RowSource = "Dias,D,Semanal,S,Quincenal,Q,Mensual,M,Anual,A";
    this.prop.RowSourceType = 1;
    this.prop.Style = 2;
    this.prop.TabIndex = 31;
    this.prop.ToolTipText = "Tipo de parcialidad";
    this.prop.Value = ('D');
    this.style.width = '95px';

    //propiedades
  }



  // Evento   :When
  // Objeto  :mpa_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Result
    this.prop.Valid = true
    const cometdo = await currentValue('*', 'cometdo')
    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly || this.Form.vi_lla1_doc.mpa_sat == 'PUE') {
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 

    return false

  }   // Fin Procedure


  //metodo
}