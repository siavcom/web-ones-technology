//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : coboboxsat
// Class : tre_sat
// Description : Componente tre_sat
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COBOBOXSAT } from "@/classes/coboboxsat";

import { COBOBOXSAT } from "@/classes/Siavcom/coboboxsat";
//imports

export class tre_sat extends COBOBOXSAT {
  //public
  constructor() {
    super();
    this.prop.Caption = "Tipo de relación";
    this.prop.ColumnCount = 2;
    this.prop.ColumnLines = false;
    this.prop.ColumnWidths = "300,30";
    this.prop.ControlSource = "vi_lla1_doc.tre_sat";
    this.DisabledBackColor = 234, 234, 234;
    this.style.height = '22px';
    //Left=56;
    this.prop.Name = "tre_sat";
    this.prop.RowSource = "tipo_relacion.des_sat,cla_sat";
    this.prop.ToolTipText = "Relacion del cfdi con otros CFDI";
    this.prop.Value = (tipo_relacion.cla_sat);
    this.style.width = '148px';

    //propiedades
  }

  // Evento   :lostFocus
  // Objeto  :TRE_SAT
  // Tipo   :ComboBox
  // Comentarios :
  //if .not. thisform.ped_ped.visible
  async lostFocus() {
    if (this.prop.Name == this.Form.ult_ele && (this.Form.prop.key == 9 || this.Form.prop.key == 13 || this.Form.prop.key == 24)) {
      this.Form.captura_movi.when()
    } // End If 

  }   // Fin Procedure



  // Evento   :Valid
  // Objeto  :tre_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    let Alias = '';   //Inicializamos Alias
    let Recno = 0;   //Inicializamos Recno
    let Result = [];   //Inicializamos Resultó
    if (this.Form.sw_dre_doc) {
      this.Form.tdr_doc.prop.Valid = true
      this.Form.ndr_doc.prop.Valid = true
      this.Form.dre_doc.prop.Valid = false
    } else {

      this.Form.tdr_doc.prop.Valid = false
      this.Form.ndr_doc.prop.Valid = false
      this.Form.dre_doc.prop.Valid = true
    } // End If 

    const vi_lla1_doc = await areaSekect('vi_lla1_doc');
    if (allTrim(vi_lla1_doc.tre_sat) === '') {
      if ((vi_lla1_doc.tdr_doc > ' ') && this.Form.MessageBox('Seguro que quiere quitar la relación de los documentos', 32 + 4, 'Pregunta') == 6) {
        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.tdr_doc=?  where recno=${Recno} `, ['   '])

        // Inicio replace VFP
        Recno = await recNo()
        Alias = await alias()
        await localAlaSql(`update ${Alias} set vi_lla1_doc.ndr_doc=?  where recno=${Recno} `, [0])

        this.Form.tdr_doc.prop.Valid = true
        this.Form.ndr_doc.prop.Valid = true
        this.Form.dre_doc.prop.Valid = true
      } // End If 

    } // End If 


    return true

  }   // Fin Procedure



  // Evento   :When
  // Objeto  :mpa_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    this.prop.Valid = true
    const cometdo = await areaSekect('cometdo');
    if (cometdo.tip_cfd == 'NA' || this.prop.ReadOnly || vi_lla1_doc.sta_doc == 'T' || vi_lla1_doc.sta_doc == 'X' || vi_lla1_doc.tdr_doc != '   ') {
      this.lostFocus
      return false

    } // End If 

    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } // End If 


    return false

  }   // Fin Procedure


  //metodo
}