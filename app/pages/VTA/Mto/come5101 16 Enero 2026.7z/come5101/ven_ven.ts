//////////////////////////////////////////////
// This Form was generated automatically for web-ones-technology
// BaseClass : Component
// Class : ven_ven
// Description : Componente ven_ven
// Author : El Fer Blocks (Fernando Cuadras)
// Creation : 12/01/26
// Update Date  :
/////////////////////////////////////////////
// import { COMPONENT } from "@/classes/Component";


export class ven_ven extends CAPTURECOMPONENT {
  //public
  constructor() {
    super();

    this.prop.Type = 'text';
    this.prop.Caption = "Vendedor";

    this.prop.Type = 'number'
    this.prop.ControlSource = "vi_lla1_doc.ven_ven";
    this.prop.Decimals = 0;
    this.prop.InputMask = "9999";
    //Left=678;
    this.prop.ReadOnly = true;
    this.prop.ToolTipText = "Número de vendedor";
    this.style.width = '33px';

    //propiedades
  }



  // Evento   :Valid
  // Objeto  :ref_doc
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async valid() {
    let m = { ...this.Form.mPublic };  // Inicializamos m
    if (this.prop.Value == 0) {
      this.prop.Valid = true
      return true

    } // End If 

    m.ven_ven = this.prop.Value

    await use('vi_lla1_ven', m) // use vi_lla1_ven vi_lla1_ven

    if (await recCount('vi_lla1_ven') == 0) {
      this.Form.MessageBox('No existe venderor')
      return false

    } // End If 

    return true

  }   // Fin Procedure



  // Evento   :when
  // Objeto  :ven_ven
  // Tipo   :Cuadro de texto
  // Comentarios :
  override async when() {
    if (await this.Form.rev_per(this.prop.Name)) {
      // manda revizar permisos
      return true

    } else {

      await this.gotFocus()
      return false
    } // End If 

  }   // Fin Procedure
  //metodo
}