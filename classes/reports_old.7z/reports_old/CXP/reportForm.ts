//////////////////////////////////////////////
// Clase : Forma para generar reportes
// Author : Fernando Cuadras Angulo
// Creacion : Marzo/2023
// Ult.Mod  : 25/Mayo/2023
/////////////////////////////////////////////
//import { COMPONENT } from './Component'
import { reportForm } from "@/classes/reportForm/"
import { alm_rep } from "./alm_rep";

export class reportInv extends reportForm {

  public alm_rep= new alm_rep()

}
